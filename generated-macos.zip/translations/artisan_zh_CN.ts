<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN" sourcelanguage="en_US">
<context>
    <name>About</name>
    <message>
        <location filename="../artisanlib/main.py" line="5035" />
        <source>Release Sponsor</source>
        <translation>发布赞助商</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24402" />
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24420" />
        <source>Core Developers</source>
        <translation>核心开发人员</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24423" />
        <source>License</source>
        <translation>版权</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24444" />
        <source>There was a problem retrieving the latest version information.  Please check your Internet connection, try again later, or check manually.</source>
        <translation>检索最新版本时出现问题。请检查你的网络连接，稍后再试，或者手动检查更新。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24458" />
        <source>A new release is available.</source>
        <translation>有新版本可用。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24460" />
        <source>Show Change list</source>
        <translation>显示改变列表</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24462" />
        <source>Download Release</source>
        <translation>下载最新版本</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24464" />
        <source>You are using the latest release.</source>
        <translation>您正在使用最新版本。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24466" />
        <source>You are using a beta continuous build.</source>
        <translation>你正在使用一个自动编译的测试版本.</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24467" />
        <source>You will see a notice here once a new official release is available.</source>
        <translation>当有一个新官方版本可用时，这里会显示通知。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24482" />
        <source>Update status</source>
        <translation>更新状态</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="9994" />
        <source>sponsored by {}</source>
        <translation>由{}赞助</translation>
    </message>
</context><context>
    <name>AddlInfo</name>
    <message>
        <location filename="../artisanlib/canvas.py" line="12662" />
        <location filename="../artisanlib/statistics.py" line="198" />
        <source>Roast of the Day</source>
        <translation>当日烘焙序号</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12739" />
        <location filename="../artisanlib/statistics.py" line="203" />
        <source>Screen Size</source>
        <translation>生豆目数</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="204" />
        <source>Density Green</source>
        <translation>生豆密度</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="205" />
        <source>Moisture Green</source>
        <translation>生豆含水量</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12757" />
        <location filename="../artisanlib/statistics.py" line="206" />
        <source>Batch Size</source>
        <translation>批次大小</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12765" />
        <location filename="../artisanlib/statistics.py" line="207" />
        <source>Density Roasted</source>
        <translation>熟豆密度</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12769" />
        <location filename="../artisanlib/statistics.py" line="208" />
        <source>Moisture Roasted</source>
        <translation>熟豆含水量</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12773" />
        <location filename="../artisanlib/statistics.py" line="209" />
        <source>Ground Color</source>
        <translation>咖啡粉色值</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12777" />
        <location filename="../artisanlib/statistics.py" line="210" />
        <source>Energy</source>
        <translation>能源</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12783" />
        <location filename="../artisanlib/statistics.py" line="211" />
        <source>CO2</source>
        <translation>二氧化碳</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12815" />
        <location filename="../artisanlib/statistics.py" line="217" />
        <source>Weight Roasted</source>
        <translation>烘焙后重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12819" />
        <location filename="../artisanlib/statistics.py" line="218" />
        <source>Weight Loss</source>
        <translation>失重</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12702" />
        <source>From</source>
        <translation>来自</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12703" />
        <source>Bottom</source>
        <translation>底部</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12788" />
        <source>AUC</source>
        <translation>曲线下面积（AUC）</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12876" />
        <source>Defects Weight</source>
        <translation>缺陷重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12881" />
        <source>Defects Loss</source>
        <translation>缺陷损失</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12886" />
        <source>Yield</source>
        <translation>产量</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12892" />
        <source>Total Loss</source>
        <translation>烘焙总损失</translation>
    </message>
</context><context>
    <name>Button</name>
    <message>
        <location filename="../artisanlib/colors.py" line="567" />
        <location filename="../artisanlib/designer.py" line="244" />
        <location filename="../artisanlib/phases.py" line="119" />
        <location filename="../artisanlib/roast_properties.py" line="4166" />
        <location filename="../artisanlib/roast_properties.py" line="2974" />
        <location filename="../artisanlib/roast_properties.py" line="2972" />
        <location filename="../artisanlib/roast_properties.py" line="2940" />
        <location filename="../artisanlib/wheels.py" line="49" />
        <location filename="../artisanlib/axis.py" line="328" />
        <source>Restore Defaults</source>
        <translation>恢复默认</translation>
    </message>
    <message>
        <location filename="../artisanlib/designer.py" line="239" />
        <location filename="../artisanlib/wheels.py" line="135" />
        <location filename="../artisanlib/wheels.py" line="50" />
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="89" />
        <source>Line Color</source>
        <translation>线条颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="92" />
        <source>Text Color</source>
        <translation>文字颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/cup_profile.py" line="95" />
        <location filename="../artisanlib/devices.py" line="270" />
        <location filename="../artisanlib/alarms.py" line="79" />
        <location filename="../artisanlib/dialogs.py" line="614" />
        <location filename="../artisanlib/statistics.py" line="284" />
        <location filename="../artisanlib/roast_properties.py" line="803" />
        <location filename="../artisanlib/events.py" line="692" />
        <location filename="../artisanlib/comparator.py" line="985" />
        <location filename="../artisanlib/wheels.py" line="102" />
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="114" />
        <source>Save File</source>
        <translation>保存文件</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="119" />
        <source>Save Img</source>
        <translation>保存图像</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="136" />
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="292" />
        <location filename="../artisanlib/alarms.py" line="90" />
        <location filename="../artisanlib/dialogs.py" line="616" />
        <location filename="../artisanlib/statistics.py" line="289" />
        <location filename="../artisanlib/curves.py" line="1374" />
        <location filename="../artisanlib/roast_properties.py" line="808" />
        <location filename="../artisanlib/background.py" line="85" />
        <location filename="../artisanlib/events.py" line="697" />
        <location filename="../artisanlib/comparator.py" line="988" />
        <location filename="../artisanlib/wheels.py" line="434" />
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3537" />
        <location filename="../artisanlib/wheels.py" line="437" />
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="161" />
        <location filename="../artisanlib/devices.py" line="146" />
        <location filename="../artisanlib/wheels.py" line="439" />
        <source>Select</source>
        <translation>选择</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="462" />
        <source>Set Color</source>
        <translation>设定颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1215" />
        <location filename="../artisanlib/pid_dialogs.py" line="4689" />
        <location filename="../artisanlib/pid_dialogs.py" line="3151" />
        <location filename="../artisanlib/pid_dialogs.py" line="3149" />
        <location filename="../artisanlib/pid_dialogs.py" line="2672" />
        <location filename="../artisanlib/pid_dialogs.py" line="2029" />
        <location filename="../artisanlib/pid_dialogs.py" line="2027" />
        <location filename="../artisanlib/pid_dialogs.py" line="450" />
        <location filename="../artisanlib/pid_dialogs.py" line="299" />
        <source>Set</source>
        <translation>设定</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="100" />
        <location filename="../artisanlib/curves.py" line="1372" />
        <location filename="../artisanlib/background.py" line="83" />
        <location filename="../artisanlib/events.py" line="748" />
        <location filename="../artisanlib/pid_dialogs.py" line="2797" />
        <location filename="../artisanlib/pid_dialogs.py" line="899" />
        <source>Load</source>
        <translation>载入</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="104" />
        <location filename="../artisanlib/events.py" line="746" />
        <location filename="../artisanlib/pid_dialogs.py" line="2799" />
        <location filename="../artisanlib/pid_dialogs.py" line="903" />
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../plus/login.py" line="73" />
        <location filename="../artisanlib/dialogs.py" line="623" />
        <location filename="../artisanlib/dialogs.py" line="87" />
        <location filename="../artisanlib/comm.py" line="200" />
        <location filename="../artisanlib/pid_dialogs.py" line="2813" />
        <location filename="../artisanlib/pid_dialogs.py" line="1942" />
        <location filename="../artisanlib/pid_dialogs.py" line="923" />
        <source>OK</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="925" />
        <source>On</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="929" />
        <source>Off</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1063" />
        <source>RS</source>
        <translation>RS</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1931" />
        <source>Read Ra/So values</source>
        <translation>读取Ra/So值</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2809" />
        <location filename="../artisanlib/pid_dialogs.py" line="1933" />
        <source>RampSoak ON</source>
        <translation>缓升恒温 打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2811" />
        <location filename="../artisanlib/pid_dialogs.py" line="1935" />
        <source>RampSoak OFF</source>
        <translation>缓升恒温 关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2814" />
        <location filename="../artisanlib/pid_dialogs.py" line="1937" />
        <source>PID OFF</source>
        <translation>PID关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2816" />
        <location filename="../artisanlib/pid_dialogs.py" line="1939" />
        <source>PID ON</source>
        <translation>PID打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1953" />
        <source>Write SV</source>
        <translation>写入SV</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1964" />
        <source>Read SV</source>
        <translation>读取SV</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1979" />
        <source>Set p</source>
        <translation>设定p</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1981" />
        <source>Set i</source>
        <translation>设定i</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1983" />
        <source>Set d</source>
        <translation>设定d</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3097" />
        <location filename="../artisanlib/pid_dialogs.py" line="1997" />
        <source>Autotune ON</source>
        <translation>自动调整打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3099" />
        <location filename="../artisanlib/pid_dialogs.py" line="1999" />
        <source>Autotune OFF</source>
        <translation>自动调整关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2001" />
        <source>Read PID Values</source>
        <translation>读取PID值</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4766" />
        <location filename="../artisanlib/pid_dialogs.py" line="3155" />
        <location filename="../artisanlib/pid_dialogs.py" line="3153" />
        <location filename="../artisanlib/pid_dialogs.py" line="2033" />
        <location filename="../artisanlib/pid_dialogs.py" line="2031" />
        <source>Read</source>
        <translation>读取</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3165" />
        <location filename="../artisanlib/pid_dialogs.py" line="2043" />
        <source>Set ET PID to 1 decimal point</source>
        <translation>设定 ET PID保留1位小数</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3167" />
        <location filename="../artisanlib/pid_dialogs.py" line="2045" />
        <source>Set BT PID to 1 decimal point</source>
        <translation>设定 BT PID保留1位小数</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2801" />
        <source>Write All</source>
        <translation>全部写入</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2805" />
        <source>Read RS values</source>
        <translation>读取RS值</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2807" />
        <source>Write RS values</source>
        <translation>写入RS值</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2884" />
        <source>Write SV1</source>
        <translation>写入SV1</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2886" />
        <source>Write SV2</source>
        <translation>写入SV2</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2888" />
        <source>Write SV3</source>
        <translation>写入SV3</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2890" />
        <source>Write SV4</source>
        <translation>写入SV4</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2892" />
        <source>Write SV5</source>
        <translation>写入SV5</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2894" />
        <source>Write SV6</source>
        <translation>写入SV6</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2896" />
        <source>Write SV7</source>
        <translation>写入SV7</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2975" />
        <source>Read SV (7-0)</source>
        <translation>读取SV (7-0)</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2977" />
        <source>Write SV (7-0)</source>
        <translation>写入SV(7-0)</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3079" />
        <source>pid 1</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3081" />
        <source>pid 2</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3083" />
        <source>pid 3</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3085" />
        <source>pid 4</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3087" />
        <source>pid 5</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3089" />
        <source>pid 6</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3091" />
        <source>pid 7</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3093" />
        <source>Read PIDs</source>
        <translation>读取PIDs</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3095" />
        <source>Write PIDs</source>
        <translation>写入PIDs</translation>
    </message>
    <message>
        <location filename="../plus/login.py" line="78" />
        <location filename="../artisanlib/dialogs.py" line="624" />
        <location filename="../artisanlib/dialogs.py" line="88" />
        <location filename="../artisanlib/comm.py" line="201" />
        <location filename="../artisanlib/pid_dialogs.py" line="3101" />
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3169" />
        <source>Set ET PID to MM:SS time units</source>
        <translation>设定ET PID时间格式为MM:SS</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4767" />
        <source>Write</source>
        <translation>写入</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="137" />
        <location filename="../artisanlib/devices.py" line="288" />
        <location filename="../artisanlib/devices.py" line="257" />
        <location filename="../artisanlib/devices.py" line="158" />
        <location filename="../artisanlib/devices.py" line="156" />
        <location filename="../artisanlib/alarms.py" line="116" />
        <location filename="../artisanlib/curves.py" line="857" />
        <location filename="../artisanlib/roast_properties.py" line="2897" />
        <location filename="../artisanlib/ports.py" line="781" />
        <location filename="../artisanlib/events.py" line="1000" />
        <location filename="../artisanlib/events.py" line="712" />
        <location filename="../artisanlib/events.py" line="261" />
        <location filename="../artisanlib/autosave.py" line="93" />
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="102" />
        <location filename="../artisanlib/autosave.py" line="96" />
        <source>Path</source>
        <translation>路径</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="266" />
        <location filename="../artisanlib/alarms.py" line="95" />
        <location filename="../artisanlib/statistics.py" line="300" />
        <location filename="../artisanlib/statistics.py" line="280" />
        <location filename="../artisanlib/curves.py" line="73" />
        <location filename="../artisanlib/roast_properties.py" line="2905" />
        <location filename="../artisanlib/roast_properties.py" line="823" />
        <location filename="../artisanlib/roast_properties.py" line="813" />
        <location filename="../artisanlib/background.py" line="189" />
        <location filename="../artisanlib/background.py" line="179" />
        <location filename="../artisanlib/events.py" line="688" />
        <source>Copy Table</source>
        <translation>复制表</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="84" />
        <location filename="../artisanlib/statistics.py" line="294" />
        <location filename="../artisanlib/events.py" line="702" />
        <source>Insert</source>
        <translation>插入</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="725" />
        <source>&lt;&lt; Store Palette</source>
        <translation>&lt;&lt; 存储调色</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="727" />
        <source>Activate Palette &gt;&gt;</source>
        <translation>激活调色板 &gt;&gt;</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="131" />
        <location filename="../artisanlib/designer.py" line="241" />
        <location filename="../artisanlib/events.py" line="1190" />
        <source>Apply</source>
        <translation>应用</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="275" />
        <location filename="../artisanlib/ports.py" line="99" />
        <source>Start</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1664" />
        <location filename="../artisanlib/devices.py" line="1593" />
        <location filename="../artisanlib/ports.py" line="946" />
        <location filename="../artisanlib/ports.py" line="758" />
        <source>Scan</source>
        <translation>扫描</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="92" />
        <source>Align</source>
        <translation>对齐</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="154" />
        <source>Up</source>
        <translation>上</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="156" />
        <source>Down</source>
        <translation>下</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="158" />
        <source>Left</source>
        <translation>左</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="160" />
        <source>Right</source>
        <translation>右</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="124" />
        <source>unit</source>
        <translation>单位</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1230" />
        <location filename="../artisanlib/roast_properties.py" line="178" />
        <source>in</source>
        <translation>进</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1241" />
        <location filename="../artisanlib/roast_properties.py" line="251" />
        <source>out</source>
        <translation>出</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="783" />
        <source>Cluster</source>
        <translation>群组</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="121" />
        <location filename="../artisanlib/roast_properties.py" line="788" />
        <source>Clear</source>
        <translation>清除</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="793" />
        <source>Create Alarms</source>
        <translation>创建警报</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="798" />
        <source>Order</source>
        <translation>排序</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1725" />
        <location filename="../artisanlib/roast_properties.py" line="1255" />
        <source>defects</source>
        <translation>缺陷</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1725" />
        <location filename="../artisanlib/roast_properties.py" line="1255" />
        <source>yield</source>
        <translation>产量</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1267" />
        <source>update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="4159" />
        <location filename="../artisanlib/roast_properties.py" line="2971" />
        <location filename="../artisanlib/roast_properties.py" line="2932" />
        <source>Save Defaults</source>
        <translation>保存默认</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="814" />
        <location filename="../artisanlib/curves.py" line="811" />
        <location filename="../artisanlib/curves.py" line="808" />
        <location filename="../artisanlib/curves.py" line="805" />
        <location filename="../artisanlib/curves.py" line="802" />
        <location filename="../artisanlib/curves.py" line="799" />
        <location filename="../artisanlib/curves.py" line="796" />
        <location filename="../artisanlib/curves.py" line="793" />
        <location filename="../artisanlib/curves.py" line="790" />
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="836" />
        <source>Plot</source>
        <translation>绘制</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="839" />
        <source>Data</source>
        <translation>数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="349" />
        <location filename="../artisanlib/colors.py" line="346" />
        <location filename="../artisanlib/colors.py" line="343" />
        <location filename="../artisanlib/colors.py" line="340" />
        <location filename="../artisanlib/colors.py" line="337" />
        <location filename="../artisanlib/colors.py" line="334" />
        <location filename="../artisanlib/colors.py" line="331" />
        <location filename="../artisanlib/colors.py" line="328" />
        <location filename="../artisanlib/colors.py" line="125" />
        <location filename="../artisanlib/curves.py" line="843" />
        <source>Background</source>
        <translation>背景曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/cup_profile.py" line="101" />
        <location filename="../artisanlib/curves.py" line="849" />
        <source>Save Image</source>
        <translation>保存图像</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="939" />
        <source>Info</source>
        <translation>信息</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1018" />
        <source>Create Background Curve</source>
        <translation>创建背景曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1724" />
        <source>ET/BT</source>
        <translation>ET/BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1727" />
        <source>Create Virtual
Extra Device</source>
        <translation>创建虚拟
额外设备</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="304" />
        <source>Defaults</source>
        <translation>默认</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="73" />
        <source>All On</source>
        <translation>打开所有</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="76" />
        <source>All Off</source>
        <translation>关闭所有</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="185" />
        <source>&lt;&lt; Store Alarm Set</source>
        <translation>&lt;&lt; 保存报警表</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="187" />
        <source>Activate Alarm Set &gt;&gt;</source>
        <translation>激活警报设置 &gt;&gt;</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="180" />
        <location filename="../artisanlib/main.py" line="2403" />
        <source>Text</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="14454" />
        <location filename="../artisanlib/canvas.py" line="8299" />
        <location filename="../artisanlib/main.py" line="3191" />
        <source>ON</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15177" />
        <location filename="../artisanlib/canvas.py" line="12701" />
        <location filename="../artisanlib/canvas.py" line="8304" />
        <location filename="../artisanlib/main.py" line="3205" />
        <source>START</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3220" />
        <source>FC
START</source>
        <translation>一爆
开始</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3224" />
        <source>FC
END</source>
        <translation>一爆
结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3228" />
        <source>SC
START</source>
        <translation>二爆
开始</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3232" />
        <source>SC
END</source>
        <translation>二爆
结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3237" />
        <source>RESET</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3249" />
        <source>CHARGE</source>
        <translation>投豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3254" />
        <source>DROP</source>
        <translation>排豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3259" />
        <source>CONTROL</source>
        <translation>控制</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3272" />
        <source>EVENT</source>
        <translation>事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3277" />
        <source>SV +5</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3286" />
        <source>SV +10</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3295" />
        <source>SV +20</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3304" />
        <source>SV -20</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3313" />
        <source>SV -10</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3322" />
        <source>SV -5</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3333" />
        <source>DRY
END</source>
        <translation>脱水结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3338" />
        <source>COOL
END</source>
        <translation>冷却结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="134" />
        <location filename="../artisanlib/devices.py" line="283" />
        <location filename="../artisanlib/devices.py" line="281" />
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1455" />
        <location filename="../artisanlib/devices.py" line="297" />
        <source>Update Profile</source>
        <translation>更新配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1675" />
        <location filename="../artisanlib/devices.py" line="1604" />
        <source>Tare</source>
        <translation>皮重</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="160" />
        <location filename="../artisanlib/canvas.py" line="12845" />
        <source>Finishing Phase</source>
        <translation>完成阶段</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="155" />
        <location filename="../artisanlib/canvas.py" line="12853" />
        <source>Maillard Phase</source>
        <translation>美拉德反应阶段</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="150" />
        <location filename="../artisanlib/canvas.py" line="12860" />
        <source>Drying Phase</source>
        <translation>脱水阶段</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15079" />
        <location filename="../artisanlib/canvas.py" line="14303" />
        <source>OFF</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="88" />
        <location filename="../artisanlib/colors.py" line="78" />
        <location filename="../artisanlib/colors.py" line="67" />
        <location filename="../artisanlib/colors.py" line="57" />
        <source>ET</source>
        <translation>ET</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="93" />
        <location filename="../artisanlib/colors.py" line="83" />
        <location filename="../artisanlib/colors.py" line="72" />
        <location filename="../artisanlib/colors.py" line="62" />
        <source>BT</source>
        <translation>BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="99" />
        <source>Extra 1</source>
        <translation>额外 1</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="101" />
        <source>Extra 2</source>
        <translation>额外 2</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="130" />
        <source>Grid</source>
        <translation>坐标格</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="135" />
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="140" />
        <source>Y Label</source>
        <translation>Y轴标签</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="145" />
        <source>X Label</source>
        <translation>X轴标签</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="165" />
        <source>Cooling Phase</source>
        <translation>冷却阶段</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="170" />
        <source>Bars Bkgnd</source>
        <translation>背景曲线的长块</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="175" />
        <source>Markers</source>
        <translation>标记</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="185" />
        <source>Watermarks</source>
        <translation>水印</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="190" />
        <source>Time Guide</source>
        <translation>时间指引</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="195" />
        <source>AUC Guide</source>
        <translation>AUC指引</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="200" />
        <source>AUC Area</source>
        <translation>曲线下面积（AUC）</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="205" />
        <source>Legend bkgnd</source>
        <translation>背景曲线图例</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="222" />
        <source>Legend border</source>
        <translation>图例边界</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="227" />
        <source>Canvas</source>
        <translation>画布</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="237" />
        <source>SpecialEvent Marker</source>
        <translation>特殊事件标记</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="242" />
        <source>SpecialEvent Text</source>
        <translation>特殊事件文本</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="247" />
        <source>Bkgd Event Marker</source>
        <translation>背景曲线上的事件标记</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="252" />
        <source>Bkgd Event Text</source>
        <translation>背景曲线上的文本</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="257" />
        <source>MET Text</source>
        <translation>MET 文本</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="262" />
        <source>MET Box</source>
        <translation>MET 框</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="267" />
        <source>Analysis Mask</source>
        <translation>分析区域</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="284" />
        <source>Stats&amp;Analysis Bkgnd</source>
        <translation>状态&amp;分析背景色</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="324" />
        <location filename="../artisanlib/colors.py" line="321" />
        <location filename="../artisanlib/colors.py" line="318" />
        <location filename="../artisanlib/colors.py" line="315" />
        <location filename="../artisanlib/colors.py" line="312" />
        <location filename="../artisanlib/colors.py" line="309" />
        <location filename="../artisanlib/colors.py" line="306" />
        <location filename="../artisanlib/colors.py" line="303" />
        <source>Digits</source>
        <translation>位数</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="361" />
        <source>B/W</source>
        <translation>黑/白</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="569" />
        <source>Grey</source>
        <translation>灰色</translation>
    </message>
    <message>
        <location filename="../artisanlib/cup_profile.py" line="98" />
        <source>Del</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>scan</source>
        <translation type="vanished">扫描</translation>
    </message>
</context><context>
    <name>CheckBox</name>
    <message>
        <location filename="../artisanlib/axis.py" line="170" />
        <source>Expand</source>
        <translation>扩展</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="174" />
        <source>Lock</source>
        <translation>锁定</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="277" />
        <location filename="../artisanlib/axis.py" line="179" />
        <source>Auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="53" />
        <location filename="../artisanlib/axis.py" line="237" />
        <source>Time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="242" />
        <source>Temp</source>
        <translation>温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="247" />
        <source>Roast-like layout</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="252" />
        <source>Phase bar labels (MM:SS %)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="86" />
        <location filename="../artisanlib/devices.py" line="80" />
        <location filename="../artisanlib/comm.py" line="193" />
        <location filename="../artisanlib/axis.py" line="278" />
        <source>ET</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="89" />
        <location filename="../artisanlib/devices.py" line="83" />
        <location filename="../artisanlib/axis.py" line="280" />
        <source>BT</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="126" />
        <location filename="../artisanlib/pid_dialogs.py" line="907" />
        <location filename="../artisanlib/axis.py" line="331" />
        <source>Load from profile</source>
        <translation>从曲线配置文件中读取</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="64" />
        <location filename="../artisanlib/comparator.py" line="1844" />
        <source>Events</source>
        <translation>事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="759" />
        <source>Start PID on CHARGE</source>
        <translation>投豆时打开 PID</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="763" />
        <source>Stop PID on DROP</source>
        <translation>DROP 时停止 PID</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="767" />
        <source>Create Events</source>
        <translation>创建事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="773" />
        <source>Load p-i-d from background</source>
        <translation>从后台加载 p-i-d</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="128" />
        <location filename="../artisanlib/pid_dialogs.py" line="910" />
        <source>Load from background</source>
        <translation>从背景曲线载入</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2856" />
        <location filename="../artisanlib/pid_dialogs.py" line="2055" />
        <source>Follow Background</source>
        <translation>跟随背景曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="57" />
        <source>Autosave [a]</source>
        <translation>自动保存 [a]</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="62" />
        <source>Add to recent file list</source>
        <translation>添加到最近的文件列表</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="67" />
        <source>Save also</source>
        <translation>同时保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="63" />
        <location filename="../artisanlib/events.py" line="284" />
        <source>Annotations</source>
        <translation>说明</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="290" />
        <source>Show on {}</source>
        <comment>Show on BT</comment>
        <translation>显示在 {}</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="297" />
        <source>Snap</source>
        <translation>呈现</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="301" />
        <source>Descr.</source>
        <translation>说明.</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="579" />
        <source>{} Timer</source>
        <comment>CHARGE Timer</comment>
        <translation>{}计时器</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="636" />
        <source>Time Guide</source>
        <translation>显示时间指引</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="672" />
        <source>Mark Last Pressed</source>
        <translation>标记上次按下</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="676" />
        <source>Tooltips</source>
        <translation>工具提示</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="741" />
        <source>Switch Using Number Keys + Cmd</source>
        <translation>使用数字键+命令切换</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="72" />
        <location filename="../artisanlib/events.py" line="1002" />
        <source>Keyboard Control</source>
        <translation>键盘控制</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1005" />
        <source>Alternative Layout</source>
        <translation>替代布局</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="91" />
        <source>Fct. 3</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="94" />
        <source>Fct. 4</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="267" />
        <source>Int</source>
        <translation>整数</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="270" />
        <source>Float</source>
        <translation>漂浮</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1361" />
        <source>START on CHARGE</source>
        <translation>投豆时开始</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1363" />
        <source>OFF on DROP</source>
        <translation>排豆后关闭</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1580" />
        <location filename="../artisanlib/curves.py" line="1038" />
        <location filename="../artisanlib/curves.py" line="949" />
        <location filename="../artisanlib/curves.py" line="943" />
        <location filename="../artisanlib/curves.py" line="936" />
        <location filename="../artisanlib/curves.py" line="918" />
        <location filename="../artisanlib/background.py" line="62" />
        <source>Show</source>
        <translation>显示</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="404" />
        <location filename="../artisanlib/background.py" line="71" />
        <source>Show Full</source>
        <translation>显示完全</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="220" />
        <source>Playback Aid</source>
        <translation>回放辅助设备</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1218" />
        <location filename="../artisanlib/background.py" line="224" />
        <source>Beep</source>
        <translation>提示音</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="229" />
        <source>Playback Events</source>
        <translation>回放事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="234" />
        <source>Playback DROP</source>
        <translation>回放 排豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="248" />
        <source>Clear background before loading</source>
        <translation>加载前清除背景</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="253" />
        <source>Set batch size</source>
        <translation>设置批次大小</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="258" />
        <source>Always hide background on loading</source>
        <translation>加载时始终隐藏背景</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="768" />
        <source>Delete roast properties on RESET</source>
        <translation>重置时删除烘焙属性</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="771" />
        <source>Open on CHARGE</source>
        <translation>投豆时打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="775" />
        <source>Open on DROP</source>
        <translation>排豆时打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="862" />
        <source>Show Always</source>
        <translation>总是显示</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23823" />
        <location filename="../artisanlib/roast_properties.py" line="1189" />
        <source>Heavy FC</source>
        <translation>较强一爆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23825" />
        <location filename="../artisanlib/roast_properties.py" line="1192" />
        <source>Low FC</source>
        <translation>较弱一爆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23827" />
        <location filename="../artisanlib/roast_properties.py" line="1195" />
        <source>Light Cut</source>
        <translation>浅色中线</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23829" />
        <location filename="../artisanlib/roast_properties.py" line="1198" />
        <source>Dark Cut</source>
        <translation>深色中线</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23831" />
        <location filename="../artisanlib/roast_properties.py" line="1201" />
        <source>Drops</source>
        <translation>滴油</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23833" />
        <location filename="../artisanlib/roast_properties.py" line="1204" />
        <source>Oily</source>
        <translation>豆表有油</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23835" />
        <location filename="../artisanlib/roast_properties.py" line="1207" />
        <source>Uneven</source>
        <translation>不均匀</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23837" />
        <location filename="../artisanlib/roast_properties.py" line="1209" />
        <source>Tipping</source>
        <translation>不规则</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23839" />
        <location filename="../artisanlib/roast_properties.py" line="1211" />
        <source>Scorching</source>
        <translation>焦烧</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23841" />
        <location filename="../artisanlib/roast_properties.py" line="1213" />
        <source>Divots</source>
        <translation>裂缝</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1418" />
        <source>Standard bean labels</source>
        <translation>标准豆类标签</translation>
    </message>
    <message>
        <location filename="../artisanlib/phases.py" line="93" />
        <source>Auto Adjusted</source>
        <translation>自动调整</translation>
    </message>
    <message>
        <location filename="../artisanlib/phases.py" line="96" />
        <source>From Background</source>
        <translation>来自背景曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/phases.py" line="99" />
        <source>Watermarks</source>
        <translation>水印</translation>
    </message>
    <message>
        <location filename="../artisanlib/phases.py" line="101" />
        <source>Phases LCDs</source>
        <translation>阶段LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/phases.py" line="103" />
        <source>Auto DRY</source>
        <translation>自动标记脱水</translation>
    </message>
    <message>
        <location filename="../artisanlib/phases.py" line="105" />
        <source>Auto FCs</source>
        <translation>自动记录第一次爆裂</translation>
    </message>
    <message>
        <location filename="../artisanlib/logs.py" line="43" />
        <source>Serial Log ON/OFF</source>
        <translation>串行日志 开/关</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="359" />
        <source>Optimal Smoothing Post Roast</source>
        <translation>烘焙后优化平滑度</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="365" />
        <source>Polyfit computation</source>
        <translation>多边形拟合计算</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="380" />
        <source>Smooth Spikes</source>
        <translation>平滑度峰值</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="386" />
        <source>Interpolate Duplicates</source>
        <translation>插值重复项</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="411" />
        <source>Interpolate Drops</source>
        <translation>插值处理滴落数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="418" />
        <source>Drop Spikes</source>
        <translation>去除尖峰</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="647" />
        <location filename="../artisanlib/curves.py" line="424" />
        <source>Limits</source>
        <translation>限制</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="451" />
        <location filename="../artisanlib/curves.py" line="450" />
        <location filename="../artisanlib/curves.py" line="449" />
        <location filename="../artisanlib/curves.py" line="448" />
        <source>Projection</source>
        <translation>预测</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="92" />
        <location filename="../artisanlib/curves.py" line="511" />
        <source>Swap</source>
        <translation>交换</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1222" />
        <source>Glow</source>
        <translation>辉光</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1226" />
        <source>Notifications</source>
        <translation>通知</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1271" />
        <source>Decimal Places</source>
        <translation>小数位数</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1308" />
        <source>Alarm Popups</source>
        <translation>警报弹出框</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1368" />
        <source>Hide Image During Roast</source>
        <translation>烘焙时隐藏图像</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="59" />
        <source>Bar</source>
        <translation>柱形图</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="67" />
        <source>Characteristics</source>
        <translation>特征</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="73" />
        <source>/min</source>
        <translation>/分钟</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="120" />
        <source>From Event</source>
        <translation>来自事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/cup_profile.py" line="109" />
        <location filename="../artisanlib/statistics.py" line="131" />
        <source>Background</source>
        <translation>背景曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="136" />
        <source>Guide</source>
        <translation>引导线</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="139" />
        <source>LCD</source>
        <translation>LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="143" />
        <source>Show Area</source>
        <translation>显示 区域（AUC）</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="247" />
        <source>Show summary</source>
        <translation>显示摘要</translation>
    </message>
    <message>
        <location filename="../artisanlib/dialogs.py" line="785" />
        <source>Use landmarks only</source>
        <translation>使用传统模式（ 仅限核心基准点</translation>
    </message>
    <message>
        <location filename="../artisanlib/batches.py" line="42" />
        <source>Batch Counter</source>
        <translation>批次计数器</translation>
    </message>
    <message>
        <location filename="../artisanlib/batches.py" line="57" />
        <source>Never overwrite counter</source>
        <translation>从不覆盖计数器</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="143" />
        <source>Output</source>
        <translation>输出</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="190" />
        <source>PID Duty/Power LCDs</source>
        <translation>PID占空比/功率 LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="193" />
        <source>Modbus Port</source>
        <translation>Modbus 端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="233" />
        <source>PID Firmware</source>
        <translation>PID 固件</translation>
    </message>
    <message>
        <source>CHARGE</source>
        <translation type="vanished">投豆</translation>
    </message>
    <message>
        <source>DRY END</source>
        <translation type="vanished">脱水结束</translation>
    </message>
    <message>
        <source>FC START</source>
        <translation type="vanished">第一次爆裂</translation>
    </message>
    <message>
        <source>FC END</source>
        <translation type="vanished">一爆结束</translation>
    </message>
    <message>
        <source>SC START</source>
        <translation type="vanished">第二次爆裂</translation>
    </message>
    <message>
        <source>SC END</source>
        <translation type="vanished">二爆结束</translation>
    </message>
    <message>
        <source>DROP</source>
        <translation type="vanished">排豆</translation>
    </message>
    <message>
        <source>COOL END</source>
        <translation type="vanished">冷却结束</translation>
    </message>
</context><context>
    <name>ComboBox</name>
    <message>
        <location filename="../artisanlib/axis.py" line="138" />
        <source>upper right</source>
        <translation>右上</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="139" />
        <source>upper left</source>
        <translation>左上</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="140" />
        <source>lower left</source>
        <translation>左下</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="141" />
        <source>lower right</source>
        <translation>右下</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="142" />
        <source>right</source>
        <translation>右</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="143" />
        <source>center left</source>
        <translation>中左</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="144" />
        <source>center right</source>
        <translation>中右</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="145" />
        <source>lower center</source>
        <translation>中下</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="146" />
        <source>upper center</source>
        <translation>中上</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="147" />
        <source>center</source>
        <translation>中心</translation>
    </message>
    <message>
        <location filename="../artisanlib/comparator.py" line="993" />
        <location filename="../artisanlib/axis.py" line="196" />
        <source>Roast</source>
        <translation>烘焙</translation>
    </message>
    <message>
        <location filename="../artisanlib/comparator.py" line="994" />
        <location filename="../artisanlib/axis.py" line="197" />
        <source>BBP+Roast</source>
        <translation>BBP+烘焙</translation>
    </message>
    <message>
        <location filename="../artisanlib/comparator.py" line="995" />
        <location filename="../artisanlib/axis.py" line="198" />
        <source>BBP</source>
        <translation>批次间规程(BBP)</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="213" />
        <source>1 minute</source>
        <translation>1 分钟</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="214" />
        <source>2 minutes</source>
        <translation>2 分钟</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="215" />
        <source>3 minutes</source>
        <translation>3 分钟</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="216" />
        <source>4 minutes</source>
        <translation>4 分钟</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="217" />
        <source>5 minutes</source>
        <translation>5 分钟</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="218" />
        <source>10 minutes</source>
        <translation>10 分钟</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="219" />
        <source>30 minutes</source>
        <translation>30 分钟</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="220" />
        <source>1 hour</source>
        <translation>1 小时</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="221" />
        <source>1 day</source>
        <translation>1天</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="294" />
        <source>solid</source>
        <translation>实线</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="295" />
        <source>dashed</source>
        <translation>虚线</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="296" />
        <source>dashed-dot</source>
        <translation>虚线加点</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="297" />
        <source>dotted</source>
        <translation>点线</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="453" />
        <source>Flat</source>
        <translation>平淡</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="454" />
        <source>Perpendicular</source>
        <translation>垂直</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="455" />
        <source>Radial</source>
        <translation>径向</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="896" />
        <location filename="../artisanlib/pid_dialogs.py" line="825" />
        <source>Pop Up</source>
        <translation>弹出</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="897" />
        <location filename="../artisanlib/events.py" line="1285" />
        <location filename="../artisanlib/events.py" line="789" />
        <location filename="../artisanlib/events.py" line="126" />
        <location filename="../artisanlib/pid_dialogs.py" line="826" />
        <source>Call Program</source>
        <translation>执行程序</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="898" />
        <location filename="../artisanlib/events.py" line="280" />
        <location filename="../artisanlib/pid_dialogs.py" line="827" />
        <source>Event Button</source>
        <translation>事件按钮</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="902" />
        <location filename="../artisanlib/alarms.py" line="901" />
        <location filename="../artisanlib/alarms.py" line="900" />
        <location filename="../artisanlib/alarms.py" line="899" />
        <location filename="../artisanlib/pid_dialogs.py" line="831" />
        <location filename="../artisanlib/pid_dialogs.py" line="830" />
        <location filename="../artisanlib/pid_dialogs.py" line="829" />
        <location filename="../artisanlib/pid_dialogs.py" line="828" />
        <source>Slider</source>
        <translation>控制滑块</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="903" />
        <location filename="../artisanlib/alarms.py" line="845" />
        <location filename="../artisanlib/pid_dialogs.py" line="832" />
        <source>START</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19481" />
        <location filename="../artisanlib/alarms.py" line="910" />
        <location filename="../artisanlib/alarms.py" line="854" />
        <location filename="../artisanlib/curves.py" line="2132" />
        <location filename="../artisanlib/roast_properties.py" line="4476" />
        <location filename="../artisanlib/roast_properties.py" line="754" />
        <location filename="../artisanlib/background.py" line="1081" />
        <location filename="../artisanlib/events.py" line="1376" />
        <location filename="../artisanlib/pid_dialogs.py" line="839" />
        <source>COOL END</source>
        <translation>冷却结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="911" />
        <location filename="../artisanlib/events.py" line="2755" />
        <location filename="../artisanlib/pid_dialogs.py" line="840" />
        <source>OFF</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="913" />
        <location filename="../artisanlib/pid_dialogs.py" line="842" />
        <source>RampSoak ON</source>
        <translation>缓升恒温 打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="914" />
        <location filename="../artisanlib/pid_dialogs.py" line="843" />
        <source>RampSoak OFF</source>
        <translation>缓升恒温 关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="915" />
        <location filename="../artisanlib/pid_dialogs.py" line="844" />
        <source>PID ON</source>
        <translation>PID打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="916" />
        <location filename="../artisanlib/pid_dialogs.py" line="845" />
        <source>PID OFF</source>
        <translation>PID关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="917" />
        <location filename="../artisanlib/pid_dialogs.py" line="846" />
        <source>SV</source>
        <translation>SV</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12246" />
        <location filename="../artisanlib/alarms.py" line="918" />
        <location filename="../artisanlib/pid_dialogs.py" line="847" />
        <source>Playback ON</source>
        <translation>打开回放</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12248" />
        <location filename="../artisanlib/alarms.py" line="919" />
        <location filename="../artisanlib/pid_dialogs.py" line="848" />
        <source>Playback OFF</source>
        <translation>关闭回放</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="920" />
        <location filename="../artisanlib/pid_dialogs.py" line="849" />
        <source>Set Canvas Color</source>
        <translation>设置画布颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="921" />
        <location filename="../artisanlib/pid_dialogs.py" line="850" />
        <source>Reset Canvas Color</source>
        <translation>重置画布颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1284" />
        <location filename="../artisanlib/events.py" line="786" />
        <location filename="../artisanlib/events.py" line="125" />
        <source>Serial Command</source>
        <translation>串行指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1303" />
        <location filename="../artisanlib/events.py" line="127" />
        <source>Multiple Event</source>
        <translation>多个事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1286" />
        <location filename="../artisanlib/events.py" line="787" />
        <location filename="../artisanlib/events.py" line="128" />
        <source>Modbus Command</source>
        <translation>Modbus 指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1287" />
        <location filename="../artisanlib/events.py" line="788" />
        <location filename="../artisanlib/events.py" line="129" />
        <source>DTA Command</source>
        <translation>DTA 指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1288" />
        <location filename="../artisanlib/events.py" line="796" />
        <location filename="../artisanlib/events.py" line="130" />
        <source>IO Command</source>
        <translation>IO 指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1289" />
        <location filename="../artisanlib/events.py" line="790" />
        <location filename="../artisanlib/events.py" line="131" />
        <source>Hottop Heater</source>
        <translation>Hottop 加热器</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1290" />
        <location filename="../artisanlib/events.py" line="791" />
        <location filename="../artisanlib/events.py" line="132" />
        <source>Hottop Fan</source>
        <translation>Hottop 风机</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1291" />
        <location filename="../artisanlib/events.py" line="792" />
        <location filename="../artisanlib/events.py" line="133" />
        <source>Hottop Command</source>
        <translation>Hottop 指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1292" />
        <location filename="../artisanlib/events.py" line="134" />
        <source>p-i-d</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1293" />
        <location filename="../artisanlib/events.py" line="793" />
        <location filename="../artisanlib/events.py" line="135" />
        <source>Fuji Command</source>
        <translation>Fuji 指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1294" />
        <location filename="../artisanlib/events.py" line="794" />
        <location filename="../artisanlib/events.py" line="136" />
        <source>PWM Command</source>
        <translation>PWM 指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1295" />
        <location filename="../artisanlib/events.py" line="795" />
        <location filename="../artisanlib/events.py" line="137" />
        <source>VOUT Command</source>
        <translation>VOUT 指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1296" />
        <location filename="../artisanlib/events.py" line="797" />
        <location filename="../artisanlib/events.py" line="138" />
        <source>S7 Command</source>
        <translation>S7 指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1297" />
        <location filename="../artisanlib/events.py" line="798" />
        <location filename="../artisanlib/events.py" line="139" />
        <source>Aillio R1 Heater</source>
        <translation>Aillio R1加热器</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1298" />
        <location filename="../artisanlib/events.py" line="799" />
        <location filename="../artisanlib/events.py" line="140" />
        <source>Aillio R1 Fan</source>
        <translation>Aillio R1风机</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1299" />
        <location filename="../artisanlib/events.py" line="800" />
        <location filename="../artisanlib/events.py" line="141" />
        <source>Aillio R1 Drum</source>
        <translation>Aillio R1滚筒</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1300" />
        <location filename="../artisanlib/events.py" line="142" />
        <source>Aillio R1 Command</source>
        <translation>Aillio R1指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1301" />
        <location filename="../artisanlib/events.py" line="801" />
        <location filename="../artisanlib/events.py" line="143" />
        <source>Artisan Command</source>
        <translation>Artisan 指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1302" />
        <location filename="../artisanlib/events.py" line="802" />
        <location filename="../artisanlib/events.py" line="144" />
        <source>RC Command</source>
        <translation>RC 指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1304" />
        <location filename="../artisanlib/events.py" line="803" />
        <location filename="../artisanlib/events.py" line="145" />
        <source>WebSocket Command</source>
        <translation>WebSocket 指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="804" />
        <location filename="../artisanlib/events.py" line="146" />
        <source>Stepper Command</source>
        <translation>步进 指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="319" />
        <source>Flag</source>
        <translation>标记</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="320" />
        <source>Bar</source>
        <translation>条形图</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="321" />
        <source>Step</source>
        <translation>阶段</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="322" />
        <source>Step+</source>
        <translation>阶段+</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="323" />
        <source>Combo</source>
        <translation>组合</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="341" />
        <source>Classic</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="342" />
        <source>Roest markers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="609" />
        <source>Standard</source>
        <translation>标准</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="609" />
        <source>Sensitive</source>
        <translation>敏感的</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="666" />
        <source>tiny</source>
        <translation>小</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="667" />
        <source>small</source>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="668" />
        <source>large</source>
        <translation>大</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="2247" />
        <location filename="../artisanlib/events.py" line="1122" />
        <source>ET</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="2248" />
        <location filename="../artisanlib/events.py" line="1123" />
        <source>BT</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="844" />
        <location filename="../artisanlib/alarms.py" line="820" />
        <location filename="../artisanlib/events.py" line="2756" />
        <source>ON</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="552" />
        <source>words</source>
        <translation>数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="951" />
        <location filename="../artisanlib/ports.py" line="763" />
        <source>optimize</source>
        <translation>最优化</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="956" />
        <location filename="../artisanlib/ports.py" line="768" />
        <source>fetch full blocks</source>
        <translation>获取完整块</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1479" />
        <source>compression</source>
        <translation>压缩</translation>
    </message>
    <message>
        <location filename="../artisanlib/phases.py" line="134" />
        <source>Time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/phases.py" line="135" />
        <source>Percentage</source>
        <translation>百分比</translation>
    </message>
    <message>
        <location filename="../artisanlib/phases.py" line="136" />
        <source>Temp</source>
        <translation>温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="98" />
        <source>liter</source>
        <translation>升</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="99" />
        <source>gallon</source>
        <translation>加仑</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="100" />
        <source>quart</source>
        <translation>夸脱</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="101" />
        <source>pint</source>
        <translation>品脱</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="102" />
        <source>cup</source>
        <translation>杯</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="103" />
        <source>cm^3</source>
        <translation>立方厘米</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="146" />
        <location filename="../artisanlib/curves.py" line="925" />
        <location filename="../artisanlib/curves.py" line="453" />
        <source>linear</source>
        <translation>线性</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="147" />
        <location filename="../artisanlib/curves.py" line="454" />
        <source>quadratic</source>
        <translation>平方</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="713" />
        <source>classic</source>
        <translation>经典</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="714" />
        <source>xkcd</source>
        <translation>xkcd 风格</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="721" />
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="926" />
        <source>cubic</source>
        <translation>立方</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="927" />
        <source>nearest</source>
        <translation>最接近的</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1000" />
        <location filename="../artisanlib/curves.py" line="968" />
        <source>120 secs before FCs</source>
        <translation>一爆前120秒</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1001" />
        <location filename="../artisanlib/curves.py" line="969" />
        <source>Custom</source>
        <translation>自定义</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="195" />
        <source>Blank Line</source>
        <translation>空行</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="197" />
        <source>Roast Date, Time</source>
        <translation>烘焙日期、时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="199" />
        <source>Ambient Conditions</source>
        <translation>环境条件</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="216" />
        <source>Weight Green</source>
        <translation>生豆重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="847" />
        <source>TP</source>
        <translation>回温点</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="855" />
        <source>If Alarm</source>
        <translation>If Alarm（依赖触发）</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="145" />
        <source>discrete</source>
        <translation>离散</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="1879" />
        <location filename="../artisanlib/canvas.py" line="1872" />
        <location filename="../artisanlib/canvas.py" line="1644" />
        <source>Air</source>
        <translation>气流</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="1887" />
        <location filename="../artisanlib/canvas.py" line="1880" />
        <location filename="../artisanlib/canvas.py" line="1873" />
        <location filename="../artisanlib/canvas.py" line="1645" />
        <source>Drum</source>
        <translation>滚筒</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="1881" />
        <location filename="../artisanlib/canvas.py" line="1874" />
        <location filename="../artisanlib/canvas.py" line="1646" />
        <source>Damper</source>
        <translation>风门</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="1882" />
        <location filename="../artisanlib/canvas.py" line="1875" />
        <location filename="../artisanlib/canvas.py" line="1647" />
        <source>Burner</source>
        <translation>火力</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="1674" />
        <source>Propane Gas (LPG)</source>
        <translation>丙烷 (LPG)</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="1675" />
        <source>Natural Gas (NG)</source>
        <translation>天然气 (NG)</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="1676" />
        <source>Electric</source>
        <translation>电力</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="1886" />
        <source>Fan</source>
        <translation>风机</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="1888" />
        <source>Cooling</source>
        <translation>冷却</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="1889" />
        <source>Heater</source>
        <translation>加热器</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2520" />
        <source>Elec</source>
        <translation>电</translation>
    </message>
    <message>
        <source>CHARGE</source>
        <translation type="vanished">投豆</translation>
    </message>
    <message>
        <source>DRY</source>
        <translation type="vanished">脱水</translation>
    </message>
    <message>
        <source>FCs</source>
        <translation type="vanished">第一次爆裂</translation>
    </message>
    <message>
        <source>FCe</source>
        <translation type="vanished">一爆结束</translation>
    </message>
    <message>
        <source>SCs</source>
        <translation type="vanished">第二次爆裂</translation>
    </message>
    <message>
        <source>SCe</source>
        <translation type="vanished">二爆结束</translation>
    </message>
    <message>
        <source>DROP</source>
        <translation type="vanished">排豆</translation>
    </message>
    <message>
        <source>DRY END</source>
        <translation type="vanished">脱水结束</translation>
    </message>
    <message>
        <source>FC START</source>
        <translation type="vanished">第一次爆裂</translation>
    </message>
    <message>
        <source>FC END</source>
        <translation type="vanished">一爆结束</translation>
    </message>
    <message>
        <source>SC START</source>
        <translation type="vanished">第二次爆裂</translation>
    </message>
    <message>
        <source>SC END</source>
        <translation type="vanished">二爆结束</translation>
    </message>
    <message>
        <source>COOL</source>
        <translation type="vanished">冷却</translation>
    </message>
</context><context>
    <name>Contextual Menu</name>
    <message>
        <location filename="../artisanlib/canvas.py" line="19256" />
        <source>Add point</source>
        <translation>增加点</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19260" />
        <source>Remove point</source>
        <translation>移除点</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19266" />
        <source>Load points</source>
        <translation>读取点</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19270" />
        <source>Save points</source>
        <translation>保存点</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19276" />
        <source>Reset Designer</source>
        <translation>重置曲线设计器</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19280" />
        <source>Config...</source>
        <translation>配置表...</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="20057" />
        <source>Add to Cupping Notes</source>
        <translation>加入杯测记录</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="20061" />
        <source>Add to Roasting Notes</source>
        <translation>加入烘焙记录</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="20067" />
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1554" />
        <source>All batches prepared</source>
        <translation>所有批次已准备好</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1557" />
        <source>One more batch prepared</source>
        <translation>又准备了一批</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1561" />
        <source>One less batch prepared</source>
        <translation>少准备一批</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1564" />
        <source>No batch prepared</source>
        <translation>未准备批次</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1576" />
        <source>Register roast</source>
        <translation>批次 + 正式录入归档</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1584" />
        <source>Hide</source>
        <translation>隐藏</translation>
    </message>
</context><context>
    <name>Countries</name>
    <message>
        <location filename="../plus/countries.py" line="26" />
        <source>Afghanistan</source>
        <translation>阿富汗</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="27" />
        <source>Aland Islands</source>
        <translation>奥兰群岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="28" />
        <source>Albania</source>
        <translation>阿尔巴尼亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="29" />
        <source>Algeria</source>
        <translation>阿尔及利亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="30" />
        <source>American Samoa</source>
        <translation>美属萨摩亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="31" />
        <source>Andorra</source>
        <translation>安道尔</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="32" />
        <source>Angola</source>
        <translation>安哥拉</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="33" />
        <source>Anguilla</source>
        <translation>安圭拉岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="34" />
        <source>ANI</source>
        <translation>安达曼和尼科巴群岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="35" />
        <source>Antarctica</source>
        <translation>南极洲</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="36" />
        <source>Antigua and Barbuda</source>
        <translation>安提瓜和巴布达</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="37" />
        <source>Argentina</source>
        <translation>阿根廷</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="38" />
        <source>Armenia</source>
        <translation>亚美尼亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="39" />
        <source>Aruba</source>
        <translation>阿鲁巴岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="40" />
        <source>Australia</source>
        <translation>澳大利亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="41" />
        <source>Austria</source>
        <translation>奥地利</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="42" />
        <source>Azerbaijan</source>
        <translation>阿塞拜疆</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="43" />
        <source>Bahamas</source>
        <translation>巴哈马</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="44" />
        <source>Bahrain</source>
        <translation>巴林</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="45" />
        <source>Bali</source>
        <translation>巴厘岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="46" />
        <source>Bangladesh</source>
        <translation>孟加拉国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="47" />
        <source>Barbados</source>
        <translation>巴巴多斯</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="48" />
        <source>Belarus</source>
        <translation>白俄罗斯</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="49" />
        <source>Belgium</source>
        <translation>比利时</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="50" />
        <source>Belize</source>
        <translation>伯利兹</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="51" />
        <source>Benin</source>
        <translation>贝宁</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="52" />
        <source>Bermuda</source>
        <translation>百慕大</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="53" />
        <source>Bhutan</source>
        <translation>不丹</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="54" />
        <source>Bolivia</source>
        <translation>玻利维亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="55" />
        <source>Bonaire, Sint Eustatius and Saba</source>
        <translation>博内尔，圣尤斯特歇斯和萨巴</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="56" />
        <source>Borneo</source>
        <translation>婆罗洲</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="57" />
        <source>Bosnia and Herzegovina</source>
        <translation>波斯尼亚和黑塞哥维那</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="58" />
        <source>Botswana</source>
        <translation>博茨瓦纳</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="59" />
        <source>Bouvet Island</source>
        <translation>布维岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="60" />
        <source>Brazil</source>
        <translation>巴西</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="61" />
        <source>British Indian Ocean Territory</source>
        <translation>英属印度洋领地</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="62" />
        <source>Brunei Darussalam</source>
        <translation>文莱达鲁萨兰国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="63" />
        <source>Bulgaria</source>
        <translation>保加利亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="64" />
        <source>Burkina Faso</source>
        <translation>布基纳法索</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="65" />
        <source>Burundi</source>
        <translation>布隆迪</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="66" />
        <source>Cape Verde</source>
        <translation>佛得角</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="67" />
        <source>Cambodia</source>
        <translation>柬埔寨</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="68" />
        <source>Cameroon</source>
        <translation>喀麦隆</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="69" />
        <source>Canada</source>
        <translation>加拿大</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="70" />
        <source>Canary Islands</source>
        <translation>加那利群岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="71" />
        <source>Cayman Islands</source>
        <translation>开曼群岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="72" />
        <source>Central African Republic</source>
        <translation>中非共和国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="73" />
        <source>Chad</source>
        <translation>乍得</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="74" />
        <source>Chile</source>
        <translation>智利</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="75" />
        <source>China</source>
        <translation>中国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="76" />
        <source>Christmas Island</source>
        <translation>圣诞岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="77" />
        <source>Cocos (Keeling) Islands</source>
        <translation>科科斯（基林）群岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="78" />
        <source>Colombia</source>
        <translation>哥伦比亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="79" />
        <source>Comoros</source>
        <translation>科摩罗</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="80" />
        <source>Congo, DR</source>
        <translation>刚果民主共和国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="81" />
        <source>Congo, Republic</source>
        <translation>刚果共和国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="82" />
        <source>Cook Islands</source>
        <translation>库克群岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="83" />
        <source>Costa Rica</source>
        <translation>哥斯达黎加</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="84" />
        <source>Croatia</source>
        <translation>克罗地亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="85" />
        <source>Cuba</source>
        <translation>古巴</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="86" />
        <source>Cyprus</source>
        <translation>塞浦路斯</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="87" />
        <source>Czechia</source>
        <translation>捷克</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="88" />
        <source>Denmark</source>
        <translation>丹麦</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="89" />
        <source>Djibouti</source>
        <translation>吉布地</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="90" />
        <source>Dominica</source>
        <translation>多米尼加</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="91" />
        <source>Dominican Republic</source>
        <translation>多明尼加共和国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="92" />
        <source>Ecuador</source>
        <translation>厄瓜多尔</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="93" />
        <source>Egypt</source>
        <translation>埃及</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="94" />
        <source>El Salvador</source>
        <translation>萨尔瓦多</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="95" />
        <source>Equatorial Guinea</source>
        <translation>赤道几内亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="96" />
        <source>Eritrea</source>
        <translation>厄立特里亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="97" />
        <source>Estonia</source>
        <translation>爱沙尼亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="98" />
        <source>Eswatini</source>
        <translation>埃斯瓦蒂尼</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="99" />
        <source>Ethiopia</source>
        <translation>埃塞俄比亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="100" />
        <source>Falkland Islands [Malvinas]</source>
        <translation>福克兰群岛[马尔维纳斯]</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="101" />
        <source>Faroe Islands</source>
        <translation>法罗群岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="102" />
        <source>Fiji</source>
        <translation>斐济</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="103" />
        <source>Flores</source>
        <translation>弗洛雷斯</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="104" />
        <source>Finland</source>
        <translation>芬兰</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="105" />
        <source>France</source>
        <translation>法国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="106" />
        <source>French Guiana</source>
        <translation>法属圭亚那</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="107" />
        <source>French Polynesia</source>
        <translation>法属波利尼西亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="108" />
        <source>French Southern Territories</source>
        <translation>法属南部领地</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="109" />
        <source>Gabon</source>
        <translation>加蓬</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="110" />
        <source>Gambia</source>
        <translation>冈比亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="111" />
        <source>Georgia</source>
        <translation>格鲁吉亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="112" />
        <source>Germany</source>
        <translation>德国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="113" />
        <source>Ghana</source>
        <translation>加纳</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="114" />
        <source>Gibraltar</source>
        <translation>直布罗陀</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="115" />
        <source>Greece</source>
        <translation>希腊</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="116" />
        <source>Greenland</source>
        <translation>格陵兰</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="117" />
        <source>Grenada</source>
        <translation>格林纳达</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="118" />
        <source>Guadeloupe</source>
        <translation>瓜德罗普岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="119" />
        <source>Guam</source>
        <translation>关岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="120" />
        <source>Guatemala</source>
        <translation>危地马拉</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="121" />
        <source>Guernsey</source>
        <translation>根西岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="122" />
        <source>Guinea</source>
        <translation>几内亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="123" />
        <source>Guinea-Bissau</source>
        <translation>几内亚比绍</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="124" />
        <source>Guyana</source>
        <translation>圭亚那</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="125" />
        <source>Haiti</source>
        <translation>海地</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="126" />
        <source>Hawaii</source>
        <translation>夏威夷</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="127" />
        <source>Heard Island and McDonald Islands</source>
        <translation>希尔德岛和麦当劳群岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="128" />
        <source>Honduras</source>
        <translation>洪都拉斯</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="129" />
        <source>Hong Kong</source>
        <translation>香港</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="130" />
        <source>Hungary</source>
        <translation>匈牙利</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="131" />
        <source>Iceland</source>
        <translation>冰岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="132" />
        <source>India</source>
        <translation>印度</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="133" />
        <source>Indonesia</source>
        <translation>印度尼西亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="134" />
        <source>Iran</source>
        <translation>伊朗</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="135" />
        <source>Iraq</source>
        <translation>伊拉克</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="136" />
        <source>Ireland</source>
        <translation>爱尔兰</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="137" />
        <source>Isle of Man</source>
        <translation>马恩岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="138" />
        <source>Israel</source>
        <translation>以色列</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="139" />
        <source>Italy</source>
        <translation>意大利</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="140" />
        <source>Ivory Coast</source>
        <translation>象牙海岸</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="141" />
        <source>Jamaica</source>
        <translation>牙买加</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="142" />
        <source>Japan</source>
        <translation>日本</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="143" />
        <source>Java</source>
        <translation>爪哇</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="144" />
        <source>Jersey</source>
        <translation>泽西岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="145" />
        <source>Jordan</source>
        <translation>约旦</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="146" />
        <source>Kazakhstan</source>
        <translation>哈萨克斯坦</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="147" />
        <source>Kenya</source>
        <translation>肯尼亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="148" />
        <source>Kiribati</source>
        <translation>基里巴斯</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="149" />
        <source>North Korea</source>
        <translation>北朝鲜</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="150" />
        <source>South Korea</source>
        <translation>南韩</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="151" />
        <source>Kuwait</source>
        <translation>科威特</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="152" />
        <source>Kyrgyzstan</source>
        <translation>吉尔吉斯斯坦</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="153" />
        <source>Laos</source>
        <translation>老挝</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="154" />
        <source>Latvia</source>
        <translation>拉脱维亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="155" />
        <source>Lebanon</source>
        <translation>黎巴嫩</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="156" />
        <source>Lesotho</source>
        <translation>莱索托</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="157" />
        <source>Liberia</source>
        <translation>利比里亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="158" />
        <source>Libya</source>
        <translation>利比亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="159" />
        <source>Liechtenstein</source>
        <translation>列支敦士登</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="160" />
        <source>Lithuania</source>
        <translation>立陶宛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="161" />
        <source>Luxembourg</source>
        <translation>卢森堡</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="162" />
        <source>Macao</source>
        <translation>澳门</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="163" />
        <source>Macedonia, the former Yugoslav Republic of</source>
        <translation>马其顿，前南斯拉夫共和国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="166" />
        <source>Madagascar</source>
        <translation>马达加斯加</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="167" />
        <source>Malawi</source>
        <translation>马拉维</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="168" />
        <source>Malaysia</source>
        <translation>马来西亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="169" />
        <source>Maldives</source>
        <translation>马尔代夫</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="170" />
        <source>Mali</source>
        <translation>马里</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="171" />
        <source>Malta</source>
        <translation>马耳他</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="172" />
        <source>Marshall Islands</source>
        <translation>马绍尔群岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="173" />
        <source>Martinique</source>
        <translation>马提尼克岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="174" />
        <source>Mauritania</source>
        <translation>毛里塔尼亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="175" />
        <source>Mauritius</source>
        <translation>毛里求斯</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="176" />
        <source>Mayotte</source>
        <translation>马约特岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="177" />
        <source>Mexico</source>
        <translation>墨西哥</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="178" />
        <source>Micronesia</source>
        <translation>密克罗尼西亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="179" />
        <source>Micronesia, Federated States of</source>
        <translation>密克罗尼西亚联邦</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="180" />
        <source>Moldova</source>
        <translation>摩尔多瓦</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="181" />
        <source>Moldova, the Republic of</source>
        <translation>摩尔多瓦共和国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="182" />
        <source>Monaco</source>
        <translation>摩纳哥</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="183" />
        <source>Mongolia</source>
        <translation>蒙古</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="184" />
        <source>Montenegro</source>
        <translation>黑山共和国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="185" />
        <source>Montserrat</source>
        <translation>蒙特塞拉特</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="186" />
        <source>North Macedonia</source>
        <translation>北马其顿</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="187" />
        <source>Morocco</source>
        <translation>摩洛哥</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="188" />
        <source>Mozambique</source>
        <translation>莫桑比克</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="189" />
        <source>Myanmar</source>
        <translation>缅甸</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="190" />
        <source>Namibia</source>
        <translation>纳米比亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="191" />
        <source>Nauru</source>
        <translation>瑙鲁</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="192" />
        <source>Nepal</source>
        <translation>尼尼泊尔</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="193" />
        <source>Netherlands</source>
        <translation>荷兰</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="194" />
        <source>New Caledonia</source>
        <translation>新喀里多尼亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="195" />
        <source>New Zealand</source>
        <translation>新西兰</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="196" />
        <source>Nicaragua</source>
        <translation>尼加拉瓜</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="197" />
        <source>Niger</source>
        <translation>尼日尔</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="198" />
        <source>Nigeria</source>
        <translation>奈及利亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="199" />
        <source>Niue</source>
        <translation>纽埃</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="200" />
        <source>Norfolk Island</source>
        <translation>诺福克岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="201" />
        <source>Northern Mariana Islands</source>
        <translation>北马里亚纳群岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="202" />
        <source>Norway</source>
        <translation>挪威</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="203" />
        <source>Oman</source>
        <translation>阿曼</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="204" />
        <source>Pakistan</source>
        <translation>巴基斯坦</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="205" />
        <source>Palau</source>
        <translation>帕劳</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="206" />
        <source>Palestine</source>
        <translation>巴勒斯坦</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="207" />
        <source>Palestine, State of</source>
        <translation>巴勒斯坦国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="208" />
        <source>Panama</source>
        <translation>巴拿马</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="209" />
        <source>Papua</source>
        <translation>巴布亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="210" />
        <source>PNG</source>
        <translation />
    </message>
    <message>
        <location filename="../plus/countries.py" line="211" />
        <source>Paraguay</source>
        <translation>巴拉圭</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="212" />
        <source>Peru</source>
        <translation>秘鲁</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="213" />
        <source>Philippines</source>
        <translation>菲律宾</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="214" />
        <source>Pitcairn</source>
        <translation>皮特凯恩</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="215" />
        <source>Poland</source>
        <translation>波兰</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="216" />
        <source>Portugal</source>
        <translation>葡萄牙</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="217" />
        <source>Puerto Rico</source>
        <translation>波多黎各</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="218" />
        <source>Qatar</source>
        <translation>卡塔尔</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="219" />
        <source>Romania</source>
        <translation>罗马尼亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="220" />
        <source>Russian Federation</source>
        <translation>俄罗斯联邦</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="221" />
        <source>Rwanda</source>
        <translation>卢旺达</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="222" />
        <source>St. Helena</source>
        <translation>圣海伦娜</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="223" />
        <source>Saint Kitts and Nevis</source>
        <translation>圣基茨和尼维斯</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="224" />
        <source>St. Lucia</source>
        <translation>圣卢西亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="225" />
        <source>Saint Lucia</source>
        <translation>圣卢西亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="226" />
        <source>Saint Martin (French part)</source>
        <translation>圣马丁（法语部分）</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="227" />
        <source>Saint Pierre and Miquelon</source>
        <translation>圣皮埃尔和密克隆群岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="228" />
        <source>St. Vincent</source>
        <translation>圣文森特</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="229" />
        <source>Samoa</source>
        <translation>萨摩亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="230" />
        <source>San Marino</source>
        <translation>圣马力诺</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="231" />
        <source>Saudi Arabia</source>
        <translation>沙特阿拉伯</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="232" />
        <source>Senegal</source>
        <translation>塞内加尔</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="233" />
        <source>Serbia</source>
        <translation>塞尔维亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="234" />
        <source>Seychelles</source>
        <translation>塞舌尔</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="235" />
        <source>Sierra Leone</source>
        <translation>塞拉利昂</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="236" />
        <source>Singapore</source>
        <translation>新加坡</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="237" />
        <source>Sint Maarten (Dutch part)</source>
        <translation>圣马丁（荷兰语部分）</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="238" />
        <source>Slovakia</source>
        <translation>斯洛伐克</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="239" />
        <source>Slovenia</source>
        <translation>斯洛文尼亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="240" />
        <source>Solomon Islands</source>
        <translation>所罗门群岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="241" />
        <source>Somalia</source>
        <translation>索马里</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="242" />
        <source>South Africa</source>
        <translation>南非</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="243" />
        <source>South Georgia and the South Sandwich Islands</source>
        <translation>南乔治亚岛和南桑威奇群岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="246" />
        <source>South Sudan</source>
        <translation>南苏丹</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="247" />
        <source>Spain</source>
        <translation>西班牙</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="248" />
        <source>Sri Lanka</source>
        <translation>斯里兰卡</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="249" />
        <source>Sudan</source>
        <translation>苏丹</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="250" />
        <source>Sulawesi</source>
        <translation>苏拉威西</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="251" />
        <source>Sumatra</source>
        <translation>苏门答腊</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="252" />
        <source>Sumbawa</source>
        <translation>松巴哇</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="253" />
        <source>Suriname</source>
        <translation>苏里南</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="254" />
        <source>Svalbard and Jan Mayen</source>
        <translation>斯瓦尔巴和扬·马延</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="255" />
        <source>Sweden</source>
        <translation>瑞典</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="256" />
        <source>Switzerland</source>
        <translation>瑞士</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="257" />
        <source>Syrian Arab Republic</source>
        <translation>阿拉伯叙利亚共和国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="258" />
        <source>Taiwan</source>
        <translation>台湾</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="259" />
        <source>Taiwan (Province of China)</source>
        <translation>台湾（中国省）</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="260" />
        <source>Tajikistan</source>
        <translation>塔吉克斯坦</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="261" />
        <source>Tanzania</source>
        <translation>坦桑尼亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="262" />
        <source>Thailand</source>
        <translation>泰国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="263" />
        <source>Timor, East</source>
        <translation>东帝汶</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="264" />
        <source>Togo</source>
        <translation>多哥</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="265" />
        <source>Tokelau</source>
        <translation>托克劳</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="266" />
        <source>Tonga</source>
        <translation>汤加</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="267" />
        <source>Trinidad and Tobago</source>
        <translation>特立尼达和多巴哥</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="268" />
        <source>Trinidad &amp; Tobago</source>
        <translation>特立尼达和多巴哥</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="269" />
        <source>Tunisia</source>
        <translation>突尼斯</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="270" />
        <source>Turkey</source>
        <translation>土耳其</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="271" />
        <source>Turkmenistan</source>
        <translation>土库曼斯坦</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="272" />
        <source>Turks and Caicos Islands</source>
        <translation>特克斯和凯科斯群岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="273" />
        <source>Tuvalu</source>
        <translation>图瓦卢</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="274" />
        <source>Uganda</source>
        <translation>乌干达</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="275" />
        <source>Ukraine</source>
        <translation>乌克兰</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="276" />
        <source>United Arab Emirates</source>
        <translation>阿拉伯联合酋长国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="277" />
        <source>UK</source>
        <translation>英国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="278" />
        <source>United Kingdom of Great Britain and Northern Ireland</source>
        <translation>大不列颠及北爱尔兰联合王国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="281" />
        <source>United States Minor Outlying Islands</source>
        <translation>美国本土外小岛屿</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="284" />
        <source>USA</source>
        <translation>美国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="285" />
        <source>United States of America</source>
        <translation>美国</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="286" />
        <source>Uruguay</source>
        <translation>乌拉圭</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="287" />
        <source>Uzbekistan</source>
        <translation>乌兹别克斯坦</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="288" />
        <source>Vanuatu</source>
        <translation>瓦努阿图</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="289" />
        <source>Venezuela</source>
        <translation>委内瑞拉</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="290" />
        <source>Vietnam</source>
        <translation>越南</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="291" />
        <source>Virgin Islands (British)</source>
        <translation>维尔京群岛（不列颠）</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="292" />
        <source>Virgin Islands (U.S.)</source>
        <translation>维尔京群岛（美国）</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="293" />
        <source>Wallis and Futuna</source>
        <translation>瓦利斯和富图纳群岛</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="294" />
        <source>Western Sahara</source>
        <translation>西撒哈拉</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="295" />
        <source>Yemen</source>
        <translation>也门</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="296" />
        <source>Zambia</source>
        <translation>赞比亚</translation>
    </message>
    <message>
        <location filename="../plus/countries.py" line="297" />
        <source>Zimbabwe</source>
        <translation>津巴布韦</translation>
    </message>
</context><context>
    <name>Dialog</name>
    <message>
        <location filename="../artisanlib/dialogs.py" line="769" />
        <source>Designer Spline Fit</source>
        <translation>曲线设计器样条拟合</translation>
    </message>
</context><context>
    <name>Error Message</name>
    <message>
        <location filename="../artisanlib/main.py" line="27035" />
        <location filename="../artisanlib/main.py" line="26997" />
        <location filename="../artisanlib/main.py" line="26854" />
        <location filename="../artisanlib/main.py" line="26406" />
        <location filename="../artisanlib/main.py" line="26336" />
        <location filename="../artisanlib/main.py" line="26285" />
        <location filename="../artisanlib/main.py" line="26144" />
        <location filename="../artisanlib/main.py" line="26001" />
        <location filename="../artisanlib/main.py" line="25869" />
        <location filename="../artisanlib/main.py" line="25654" />
        <location filename="../artisanlib/main.py" line="25574" />
        <location filename="../artisanlib/main.py" line="23806" />
        <location filename="../artisanlib/main.py" line="23149" />
        <location filename="../artisanlib/main.py" line="21791" />
        <location filename="../artisanlib/main.py" line="17277" />
        <location filename="../artisanlib/main.py" line="14347" />
        <location filename="../artisanlib/main.py" line="13688" />
        <location filename="../artisanlib/wheels.py" line="644" />
        <source>IO Error:</source>
        <translation>IO错误:</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="20241" />
        <location filename="../artisanlib/canvas.py" line="19802" />
        <location filename="../artisanlib/canvas.py" line="19698" />
        <location filename="../artisanlib/canvas.py" line="19656" />
        <location filename="../artisanlib/canvas.py" line="19551" />
        <location filename="../artisanlib/canvas.py" line="19533" />
        <location filename="../artisanlib/canvas.py" line="18776" />
        <location filename="../artisanlib/canvas.py" line="18754" />
        <location filename="../artisanlib/canvas.py" line="18469" />
        <location filename="../artisanlib/canvas.py" line="18443" />
        <location filename="../artisanlib/canvas.py" line="18258" />
        <location filename="../artisanlib/canvas.py" line="18096" />
        <location filename="../artisanlib/canvas.py" line="18039" />
        <location filename="../artisanlib/canvas.py" line="18009" />
        <location filename="../artisanlib/canvas.py" line="17378" />
        <location filename="../artisanlib/canvas.py" line="17343" />
        <location filename="../artisanlib/canvas.py" line="17077" />
        <location filename="../artisanlib/canvas.py" line="16788" />
        <location filename="../artisanlib/canvas.py" line="16695" />
        <location filename="../artisanlib/canvas.py" line="16467" />
        <location filename="../artisanlib/canvas.py" line="16282" />
        <location filename="../artisanlib/canvas.py" line="16149" />
        <location filename="../artisanlib/canvas.py" line="15968" />
        <location filename="../artisanlib/canvas.py" line="15852" />
        <location filename="../artisanlib/canvas.py" line="15742" />
        <location filename="../artisanlib/canvas.py" line="15636" />
        <location filename="../artisanlib/canvas.py" line="15523" />
        <location filename="../artisanlib/canvas.py" line="15440" />
        <location filename="../artisanlib/canvas.py" line="15380" />
        <location filename="../artisanlib/canvas.py" line="15192" />
        <location filename="../artisanlib/canvas.py" line="15129" />
        <location filename="../artisanlib/canvas.py" line="14565" />
        <location filename="../artisanlib/canvas.py" line="14520" />
        <location filename="../artisanlib/canvas.py" line="14338" />
        <location filename="../artisanlib/canvas.py" line="14259" />
        <location filename="../artisanlib/canvas.py" line="13130" />
        <location filename="../artisanlib/canvas.py" line="12894" />
        <location filename="../artisanlib/canvas.py" line="12648" />
        <location filename="../artisanlib/canvas.py" line="12607" />
        <location filename="../artisanlib/canvas.py" line="12562" />
        <location filename="../artisanlib/canvas.py" line="12307" />
        <location filename="../artisanlib/canvas.py" line="12246" />
        <location filename="../artisanlib/canvas.py" line="11930" />
        <location filename="../artisanlib/canvas.py" line="11879" />
        <location filename="../artisanlib/canvas.py" line="11410" />
        <location filename="../artisanlib/canvas.py" line="11365" />
        <location filename="../artisanlib/canvas.py" line="11321" />
        <location filename="../artisanlib/canvas.py" line="11276" />
        <location filename="../artisanlib/canvas.py" line="10727" />
        <location filename="../artisanlib/canvas.py" line="10691" />
        <location filename="../artisanlib/canvas.py" line="10651" />
        <location filename="../artisanlib/canvas.py" line="10611" />
        <location filename="../artisanlib/canvas.py" line="9705" />
        <location filename="../artisanlib/canvas.py" line="9653" />
        <location filename="../artisanlib/canvas.py" line="9307" />
        <location filename="../artisanlib/canvas.py" line="9132" />
        <location filename="../artisanlib/canvas.py" line="8663" />
        <location filename="../artisanlib/canvas.py" line="8542" />
        <location filename="../artisanlib/canvas.py" line="8196" />
        <location filename="../artisanlib/canvas.py" line="7857" />
        <location filename="../artisanlib/canvas.py" line="7047" />
        <location filename="../artisanlib/canvas.py" line="6877" />
        <location filename="../artisanlib/canvas.py" line="6549" />
        <location filename="../artisanlib/canvas.py" line="6531" />
        <location filename="../artisanlib/canvas.py" line="6508" />
        <location filename="../artisanlib/canvas.py" line="6151" />
        <location filename="../artisanlib/canvas.py" line="6041" />
        <location filename="../artisanlib/canvas.py" line="6027" />
        <location filename="../artisanlib/canvas.py" line="5642" />
        <location filename="../artisanlib/canvas.py" line="5629" />
        <location filename="../artisanlib/canvas.py" line="4837" />
        <location filename="../artisanlib/canvas.py" line="4478" />
        <location filename="../artisanlib/canvas.py" line="3888" />
        <location filename="../artisanlib/canvas.py" line="3406" />
        <location filename="../artisanlib/devices.py" line="4864" />
        <location filename="../artisanlib/devices.py" line="3388" />
        <location filename="../artisanlib/devices.py" line="3288" />
        <location filename="../artisanlib/devices.py" line="3241" />
        <location filename="../artisanlib/devices.py" line="3227" />
        <location filename="../artisanlib/devices.py" line="3197" />
        <location filename="../artisanlib/devices.py" line="3111" />
        <location filename="../artisanlib/devices.py" line="3097" />
        <location filename="../artisanlib/devices.py" line="3082" />
        <location filename="../artisanlib/devices.py" line="2888" />
        <location filename="../artisanlib/main.py" line="27567" />
        <location filename="../artisanlib/main.py" line="27461" />
        <location filename="../artisanlib/main.py" line="27288" />
        <location filename="../artisanlib/main.py" line="27274" />
        <location filename="../artisanlib/main.py" line="27040" />
        <location filename="../artisanlib/main.py" line="27002" />
        <location filename="../artisanlib/main.py" line="26416" />
        <location filename="../artisanlib/main.py" line="26150" />
        <location filename="../artisanlib/main.py" line="26007" />
        <location filename="../artisanlib/main.py" line="25960" />
        <location filename="../artisanlib/main.py" line="25876" />
        <location filename="../artisanlib/main.py" line="25660" />
        <location filename="../artisanlib/main.py" line="25580" />
        <location filename="../artisanlib/main.py" line="25147" />
        <location filename="../artisanlib/main.py" line="24935" />
        <location filename="../artisanlib/main.py" line="24478" />
        <location filename="../artisanlib/main.py" line="24291" />
        <location filename="../artisanlib/main.py" line="23817" />
        <location filename="../artisanlib/main.py" line="23413" />
        <location filename="../artisanlib/main.py" line="23408" />
        <location filename="../artisanlib/main.py" line="23339" />
        <location filename="../artisanlib/main.py" line="23323" />
        <location filename="../artisanlib/main.py" line="23079" />
        <location filename="../artisanlib/main.py" line="22930" />
        <location filename="../artisanlib/main.py" line="22805" />
        <location filename="../artisanlib/main.py" line="22434" />
        <location filename="../artisanlib/main.py" line="22034" />
        <location filename="../artisanlib/main.py" line="21856" />
        <location filename="../artisanlib/main.py" line="21817" />
        <location filename="../artisanlib/main.py" line="21798" />
        <location filename="../artisanlib/main.py" line="21164" />
        <location filename="../artisanlib/main.py" line="21121" />
        <location filename="../artisanlib/main.py" line="19940" />
        <location filename="../artisanlib/main.py" line="19537" />
        <location filename="../artisanlib/main.py" line="19446" />
        <location filename="../artisanlib/main.py" line="17715" />
        <location filename="../artisanlib/main.py" line="17263" />
        <location filename="../artisanlib/main.py" line="17173" />
        <location filename="../artisanlib/main.py" line="17166" />
        <location filename="../artisanlib/main.py" line="17151" />
        <location filename="../artisanlib/main.py" line="16888" />
        <location filename="../artisanlib/main.py" line="16875" />
        <location filename="../artisanlib/main.py" line="16821" />
        <location filename="../artisanlib/main.py" line="16805" />
        <location filename="../artisanlib/main.py" line="16694" />
        <location filename="../artisanlib/main.py" line="16670" />
        <location filename="../artisanlib/main.py" line="16652" />
        <location filename="../artisanlib/main.py" line="16338" />
        <location filename="../artisanlib/main.py" line="15253" />
        <location filename="../artisanlib/main.py" line="15065" />
        <location filename="../artisanlib/main.py" line="14795" />
        <location filename="../artisanlib/main.py" line="14759" />
        <location filename="../artisanlib/main.py" line="14744" />
        <location filename="../artisanlib/main.py" line="14724" />
        <location filename="../artisanlib/main.py" line="14704" />
        <location filename="../artisanlib/main.py" line="14628" />
        <location filename="../artisanlib/main.py" line="14484" />
        <location filename="../artisanlib/main.py" line="14358" />
        <location filename="../artisanlib/main.py" line="14003" />
        <location filename="../artisanlib/main.py" line="13952" />
        <location filename="../artisanlib/main.py" line="13911" />
        <location filename="../artisanlib/main.py" line="13706" />
        <location filename="../artisanlib/main.py" line="13552" />
        <location filename="../artisanlib/main.py" line="13291" />
        <location filename="../artisanlib/main.py" line="9651" />
        <location filename="../artisanlib/main.py" line="8986" />
        <location filename="../artisanlib/main.py" line="8696" />
        <location filename="../artisanlib/main.py" line="8318" />
        <location filename="../artisanlib/main.py" line="8256" />
        <location filename="../artisanlib/main.py" line="7957" />
        <location filename="../artisanlib/main.py" line="7615" />
        <location filename="../artisanlib/main.py" line="7484" />
        <location filename="../artisanlib/main.py" line="6722" />
        <location filename="../artisanlib/main.py" line="6346" />
        <location filename="../artisanlib/main.py" line="6321" />
        <location filename="../artisanlib/main.py" line="6292" />
        <location filename="../artisanlib/main.py" line="6261" />
        <location filename="../artisanlib/main.py" line="5689" />
        <location filename="../artisanlib/main.py" line="5411" />
        <location filename="../artisanlib/main.py" line="1319" />
        <location filename="../artisanlib/alarms.py" line="1052" />
        <location filename="../artisanlib/alarms.py" line="799" />
        <location filename="../artisanlib/alarms.py" line="706" />
        <location filename="../artisanlib/alarms.py" line="677" />
        <location filename="../artisanlib/statistics.py" line="761" />
        <location filename="../artisanlib/curves.py" line="2503" />
        <location filename="../artisanlib/curves.py" line="2443" />
        <location filename="../artisanlib/curves.py" line="2425" />
        <location filename="../artisanlib/curves.py" line="2393" />
        <location filename="../artisanlib/curves.py" line="1989" />
        <location filename="../artisanlib/curves.py" line="1980" />
        <location filename="../artisanlib/curves.py" line="1913" />
        <location filename="../artisanlib/curves.py" line="1900" />
        <location filename="../artisanlib/curves.py" line="1887" />
        <location filename="../artisanlib/curves.py" line="1718" />
        <location filename="../artisanlib/curves.py" line="1668" />
        <location filename="../artisanlib/pid_control.py" line="950" />
        <location filename="../artisanlib/pid_control.py" line="935" />
        <location filename="../artisanlib/pid_control.py" line="919" />
        <location filename="../artisanlib/pid_control.py" line="802" />
        <location filename="../artisanlib/pid_control.py" line="778" />
        <location filename="../artisanlib/pid_control.py" line="710" />
        <location filename="../artisanlib/roast_properties.py" line="3633" />
        <location filename="../artisanlib/roast_properties.py" line="2617" />
        <location filename="../artisanlib/ports.py" line="1696" />
        <location filename="../artisanlib/ports.py" line="1653" />
        <location filename="../artisanlib/events.py" line="3741" />
        <location filename="../artisanlib/comm.py" line="7365" />
        <location filename="../artisanlib/comm.py" line="7336" />
        <location filename="../artisanlib/comm.py" line="7225" />
        <location filename="../artisanlib/comm.py" line="7040" />
        <location filename="../artisanlib/comm.py" line="6826" />
        <location filename="../artisanlib/comm.py" line="6351" />
        <location filename="../artisanlib/comm.py" line="4545" />
        <location filename="../artisanlib/comm.py" line="4328" />
        <location filename="../artisanlib/comm.py" line="4258" />
        <location filename="../artisanlib/comm.py" line="4009" />
        <location filename="../artisanlib/comm.py" line="3887" />
        <location filename="../artisanlib/comm.py" line="3658" />
        <location filename="../artisanlib/comm.py" line="3574" />
        <location filename="../artisanlib/comm.py" line="3511" />
        <location filename="../artisanlib/comm.py" line="3462" />
        <location filename="../artisanlib/comm.py" line="3417" />
        <location filename="../artisanlib/comm.py" line="3357" />
        <location filename="../artisanlib/comm.py" line="3304" />
        <location filename="../artisanlib/comm.py" line="3243" />
        <location filename="../artisanlib/comm.py" line="3198" />
        <location filename="../artisanlib/comm.py" line="2990" />
        <location filename="../artisanlib/comm.py" line="2953" />
        <location filename="../artisanlib/comm.py" line="2926" />
        <location filename="../artisanlib/comm.py" line="2885" />
        <location filename="../artisanlib/comm.py" line="2862" />
        <location filename="../artisanlib/comm.py" line="2808" />
        <location filename="../artisanlib/comm.py" line="2760" />
        <location filename="../artisanlib/comm.py" line="2331" />
        <location filename="../artisanlib/comm.py" line="979" />
        <location filename="../artisanlib/comm.py" line="612" />
        <location filename="../artisanlib/comm.py" line="608" />
        <location filename="../artisanlib/comm.py" line="604" />
        <location filename="../artisanlib/pid_dialogs.py" line="4539" />
        <location filename="../artisanlib/pid_dialogs.py" line="3537" />
        <location filename="../artisanlib/pid_dialogs.py" line="3512" />
        <location filename="../artisanlib/pid_dialogs.py" line="3446" />
        <location filename="../artisanlib/pid_dialogs.py" line="2556" />
        <location filename="../artisanlib/pid_dialogs.py" line="2354" />
        <location filename="../artisanlib/pid_dialogs.py" line="2327" />
        <location filename="../artisanlib/pid_dialogs.py" line="2322" />
        <location filename="../artisanlib/pid_dialogs.py" line="2299" />
        <location filename="../artisanlib/pid_dialogs.py" line="2297" />
        <location filename="../artisanlib/pid_dialogs.py" line="1893" />
        <location filename="../artisanlib/pid_dialogs.py" line="1826" />
        <location filename="../artisanlib/pid_dialogs.py" line="1769" />
        <location filename="../artisanlib/pid_dialogs.py" line="1484" />
        <location filename="../artisanlib/pid_dialogs.py" line="1453" />
        <location filename="../artisanlib/comparator.py" line="1598" />
        <location filename="../artisanlib/wsport.py" line="402" />
        <source>Exception:</source>
        <translation>错误:</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="1044" />
        <location filename="../artisanlib/pid_dialogs.py" line="4747" />
        <location filename="../artisanlib/pid_dialogs.py" line="2726" />
        <source>Segment values could not be written into PID</source>
        <translation>部分数值无法写入到PID</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="611" />
        <location filename="../artisanlib/comm.py" line="607" />
        <location filename="../artisanlib/comm.py" line="603" />
        <source>F80h Error</source>
        <translation>F80h错误</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="620" />
        <source>CRC16 data corruption ERROR. TX does not match RX. Check wiring</source>
        <translation>CRC16数据发生错误. 传入传出不匹配.请检查线路</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="622" />
        <source>No RX data received</source>
        <translation>没有接收到传入数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="7443" />
        <location filename="../artisanlib/comm.py" line="7435" />
        <location filename="../artisanlib/comm.py" line="7418" />
        <location filename="../artisanlib/comm.py" line="2627" />
        <location filename="../artisanlib/comm.py" line="918" />
        <location filename="../artisanlib/comm.py" line="627" />
        <source>Serial Exception:</source>
        <translation>串行通信错误:</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="912" />
        <source>DTAcommand(): {0} bytes received but 15 needed</source>
        <translation>DTA指令(): {0} bytes已接收但需要至少15bytes</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="981" />
        <source>callprogram() received:</source>
        <translation>运行程序() 已接收:</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="2308" />
        <source>Extech755pressure(): conversion error, {0} bytes received</source>
        <translation>Extech755pressure():转换失败,{0} bytes 已接收</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="2319" />
        <source>Extech755pressure(): {0} bytes received but 10 needed</source>
        <translation>Extech755pressure(): {0} bytes已接收但需要至少10bytes</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="2627" />
        <source>Unable to open serial port</source>
        <translation>无法打开串行端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="2754" />
        <source>MS6514temperature(): {0} bytes received but 18 needed</source>
        <translation>MS6514温度(): {0} bytes已接收但需要至少18bytes</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="2802" />
        <source>DT301temperature(): {0} bytes received but 11 needed</source>
        <translation>DT301温度(): {0} bytes已接收但需要至少11bytes</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="2920" />
        <source>HH806AUtemperature(): {0} bytes received</source>
        <translation>HH806AU温度(): {0} bytes已接收</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="2966" />
        <source>HH806Wtemperature(): Unable to initiate device</source>
        <translation>HH806W温度(): 无法初始化设备</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3193" />
        <source>HH506RAGetID: {0} bytes received but 5 needed</source>
        <translation>HH506RA获取ID: {0} bytes已接收但需要至少5bytes</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3212" />
        <source>HH506RAtemperature(): Unable to get id from HH506RA device </source>
        <translation>HH506RA温度():无法从HH506RA设备获取ID </translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3237" />
        <source>HH506RAtemperature(): {0} bytes received but 14 needed</source>
        <translation>HH506RA温度(): {0} bytes已接收但需要至少14bytes</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3296" />
        <source>TA612C(): {0} bytes received but 13 needed</source>
        <translation>TA612C()：已接收 {0} 个字节，但需要 13 个</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3349" />
        <source>CENTER302temperature(): {0} bytes received but 7 needed</source>
        <translation>CENTER302温度(): {0} bytes已接收但需要至少7bytes</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3409" />
        <source>CENTER303temperature(): {0} bytes received but 8 needed</source>
        <translation>CENTER303温度(): {0} bytes已接收但需要至少8bytes</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3453" />
        <source>VOLTCRAFTPL125T2temperature(): {0} bytes received but 26 needed</source>
        <translation>VOLTCRAFTPL125T2温度(): {0} bytes已接收但需要至少26bytes</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3502" />
        <source>VOLTCRAFTPL125T4temperature(): {0} bytes received but 26 needed</source>
        <translation>VOLTCRAFTPL125T4温度(): {0} bytes已接收但需要至少26bytes</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3565" />
        <source>CENTER306temperature(): {0} bytes received but 10 needed</source>
        <translation>CENTER306温度(): {0} bytes已接收但需要至少10bytes</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3652" />
        <source>CENTER309temperature(): {0} bytes received but 45 needed</source>
        <translation>CENTER309温度(): {0} bytes已接收但需要至少45bytes</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6885" />
        <source>Arduino could not set channels</source>
        <translation>Arduino无法设置频道</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6901" />
        <source>Arduino could not set temperature unit</source>
        <translation>Arduino无法设置温度单位</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6911" />
        <source>Arduino could not set filters</source>
        <translation>Arduino无法设置筛选器</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="20235" />
        <location filename="../artisanlib/canvas.py" line="19796" />
        <location filename="../artisanlib/canvas.py" line="18464" />
        <location filename="../artisanlib/canvas.py" line="18438" />
        <location filename="../artisanlib/canvas.py" line="18252" />
        <location filename="../artisanlib/main.py" line="26411" />
        <location filename="../artisanlib/main.py" line="26146" />
        <location filename="../artisanlib/main.py" line="26003" />
        <location filename="../artisanlib/main.py" line="25871" />
        <location filename="../artisanlib/main.py" line="25656" />
        <location filename="../artisanlib/main.py" line="25576" />
        <location filename="../artisanlib/main.py" line="14352" />
        <location filename="../artisanlib/main.py" line="13702" />
        <location filename="../artisanlib/comm.py" line="7319" />
        <location filename="../artisanlib/comm.py" line="7216" />
        <source>Value Error:</source>
        <translation>数值错误:</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1757" />
        <source>Serial Exception: invalid comm port</source>
        <translation>串行异常:无效端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1761" />
        <source>Serial Exception: timeout</source>
        <translation>串行异常: 超时</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="5355" />
        <source>Unable to move CHARGE to a value that does not exist</source>
        <translation>因为不存在投豆的数值所以无法移动</translation>
    </message>
    <message>
        <location filename="../artisanlib/modbusport.py" line="276" />
        <source>Modbus Communication Resumed</source>
        <translation>通信协议通信恢复</translation>
    </message>
    <message>
        <location filename="../artisanlib/modbusport.py" line="367" />
        <source>Modbus Error: failed to connect</source>
        <translation>Modbus 错误：连接失败</translation>
    </message>
    <message>
        <location filename="../artisanlib/modbusport.py" line="753" />
        <location filename="../artisanlib/modbusport.py" line="727" />
        <location filename="../artisanlib/modbusport.py" line="702" />
        <location filename="../artisanlib/modbusport.py" line="675" />
        <location filename="../artisanlib/modbusport.py" line="639" />
        <location filename="../artisanlib/modbusport.py" line="608" />
        <location filename="../artisanlib/modbusport.py" line="566" />
        <location filename="../artisanlib/modbusport.py" line="542" />
        <location filename="../artisanlib/modbusport.py" line="371" />
        <source>Modbus Error:</source>
        <translation>通信协议错误:</translation>
    </message>
    <message>
        <location filename="../artisanlib/modbusport.py" line="1071" />
        <location filename="../artisanlib/modbusport.py" line="1027" />
        <location filename="../artisanlib/modbusport.py" line="981" />
        <location filename="../artisanlib/modbusport.py" line="895" />
        <location filename="../artisanlib/modbusport.py" line="854" />
        <location filename="../artisanlib/modbusport.py" line="517" />
        <source>Modbus Communication Error</source>
        <translation>通信协议通信错误</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="674" />
        <source>RampSoak could not be changed</source>
        <translation>缓升恒温 无法被改变</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="1104" />
        <source>pid.readoneword(): {0} RX bytes received (7 needed) for unit ID={1}</source>
        <translation>pid.readoneword(): {0} RX bytes 已接收 (需要7bytes) 来自单元ID={1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="2051" />
        <location filename="../artisanlib/curves.py" line="1996" />
        <source>Univariate: no profile data available</source>
        <translation>单因素:无有效曲线配置文件数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="2010" />
        <source>ln(): no profile data available</source>
        <translation>自然对数函数: 无有效曲线配置文件数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="2029" />
        <source>expvar(): no profile data available</source>
        <translation>expvar(): 无有效配置数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="2283" />
        <source>Polyfit: no profile data available</source>
        <translation>拟合: 无有效曲线配置文件数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/s7port.py" line="724" />
        <location filename="../artisanlib/s7port.py" line="633" />
        <location filename="../artisanlib/s7port.py" line="542" />
        <location filename="../artisanlib/s7port.py" line="345" />
        <source>S7 Communication Resumed</source>
        <translation>S7 通信恢复</translation>
    </message>
    <message>
        <location filename="../artisanlib/s7port.py" line="356" />
        <source>readActiveRegisters() S7 Communication Error</source>
        <translation>readActiveRegisters() S7通信错误</translation>
    </message>
    <message>
        <location filename="../artisanlib/s7port.py" line="730" />
        <location filename="../artisanlib/s7port.py" line="639" />
        <location filename="../artisanlib/s7port.py" line="548" />
        <location filename="../artisanlib/s7port.py" line="479" />
        <location filename="../artisanlib/s7port.py" line="448" />
        <location filename="../artisanlib/s7port.py" line="416" />
        <location filename="../artisanlib/s7port.py" line="385" />
        <source>S7 Error: connecting to PLC failed</source>
        <translation>S7错误：连接到PLC失败</translation>
    </message>
    <message>
        <location filename="../artisanlib/s7port.py" line="737" />
        <location filename="../artisanlib/s7port.py" line="647" />
        <location filename="../artisanlib/s7port.py" line="555" />
        <location filename="../artisanlib/s7port.py" line="485" />
        <location filename="../artisanlib/s7port.py" line="454" />
        <location filename="../artisanlib/s7port.py" line="422" />
        <location filename="../artisanlib/s7port.py" line="391" />
        <source>S7 Communication Error</source>
        <translation>S7 通信错误</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="16579" />
        <location filename="../artisanlib/main.py" line="16502" />
        <location filename="../artisanlib/main.py" line="13221" />
        <location filename="../artisanlib/main.py" line="13145" />
        <source>Error:</source>
        <translation>错误:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17885" />
        <source>Exception: {} not a valid settings file</source>
        <translation>例外：{}不是有效的设置文件</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="21164" />
        <location filename="../artisanlib/main.py" line="21121" />
        <location filename="../artisanlib/main.py" line="21112" />
        <location filename="../artisanlib/main.py" line="19537" />
        <location filename="../artisanlib/main.py" line="19446" />
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="19574" />
        <source>Exception: WebLCDs not supported by this build</source>
        <translation>例外：此版本不支持 WebLCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="19580" />
        <source>Could not start WebLCDs. Selected port might be busy.</source>
        <translation>无法启动 WebLCD。所选端口可能正忙。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="19624" />
        <source>Exception: Task Green remote display not supported by this build</source>
        <translation>异常：此版本不支持 Task Green 远程显示</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="19630" />
        <source>Could not start Task Green remote display. Selected port might be busy.</source>
        <translation>无法启动 Task Green 远程显示。所选端口可能正忙。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="19674" />
        <source>Exception: Task Roasted remote display not supported by this build</source>
        <translation>异常：此版本不支持 Task Roasted 远程显示</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="19680" />
        <source>Could not start Task Roasted remote display. Selected port might be busy.</source>
        <translation>无法启动 Task Roasted 远程显示。所选端口可能正忙。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="21112" />
        <source>Failed to save settings</source>
        <translation>保存设置失败</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23011" />
        <location filename="../artisanlib/main.py" line="22637" />
        <source>Exception (probably due to an empty profile):</source>
        <translation>错误 (可能是因为一个空的配置文件):</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27086" />
        <source>Analyze: CHARGE event required, none found</source>
        <translation>分析：需要投豆事件，并没有找到</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27090" />
        <source>Analyze: DROP event required, none found</source>
        <translation>分析：需要排豆事件，并没有找到</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27181" />
        <source>Analyze: no background profile data available</source>
        <translation>分析: 无有效背景曲线配置数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27186" />
        <source>Analyze: background profile requires CHARGE and DROP events</source>
        <translation>分析: 背景曲线配置需要投豆和排豆事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12895" />
        <source>Unexpected value for n, got</source>
        <translation>n 的值不符合预期，得到</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="14097" />
        <source>Exception: phidgetServer couldn't be added. Verify that the Phidget driver is correctly installed!</source>
        <translation>异常：无法添加 phidgetServer。请验证 Phidget 驱动程序是否已正确安装！</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="14105" />
        <source>Exception: PhidgetManager couldn't be started. Verify that the Phidget driver is correctly installed!</source>
        <translation>错误: Phidget管理器不能被启动. 校验Phidget驱动是否正常安装!</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="14619" />
        <location filename="../artisanlib/canvas.py" line="14593" />
        <source>Unstable meter data</source>
        <translation>电表数据不稳定</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="18404" />
        <source>Error in lnRegression:</source>
        <translation>回归错误:</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19185" />
        <location filename="../artisanlib/canvas.py" line="19181" />
        <source>Exception: redrawdesigner() Roast events may be out of order. Resetting Designer.</source>
        <translation>例外：redrawdesigner() 烘焙事件可能无序。重置设计师。</translation>
    </message>
</context><context>
    <name>Form Caption</name>
    <message>
        <location filename="../artisanlib/axis.py" line="73" />
        <source>Axes</source>
        <translation>坐标轴</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="41" />
        <source>Wheel Graph Editor</source>
        <translation>风味轮编辑器</translation>
    </message>
    <message>
        <location filename="../artisanlib/comparator.py" line="969" />
        <source>Comparator</source>
        <translation>比较器</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="56" />
        <source>Arduino/TC4 PID Control</source>
        <translation>Arduino/TC4 PID控制</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="58" />
        <source>S7 PID Control</source>
        <translation>S7 PID 控制</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="60" />
        <source>MODBUS PID Control</source>
        <translation>MODBUS PID 控制</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="62" />
        <source>PID Control</source>
        <translation>PID 控制</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1906" />
        <source>Fuji PXR PID Control</source>
        <translation>Fuji PXR PID 控制</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2739" />
        <source>Fuji PXG PID Control</source>
        <translation>Fuji PXG PID 控制</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2741" />
        <source>Fuji PXF PID Control</source>
        <translation>Fuji PXF PID 控制</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4759" />
        <source>Delta DTA PID Control</source>
        <translation>Delta DTA PID 控制</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="177" />
        <source>Manual Temperature Logger</source>
        <translation>手动操作温度记录器</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="37" />
        <source>Autosave</source>
        <translation>自动保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="163" />
        <source>Autosave Fields Help</source>
        <translation>自动保存失败帮助</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="191" />
        <source>AutoSave Path</source>
        <translation>自动保存文件路径</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="196" />
        <source>AutoSave Save Also Path</source>
        <translation>自动保存另存路径</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="151" />
        <source>Events</source>
        <translation>事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="3879" />
        <location filename="../artisanlib/events.py" line="922" />
        <location filename="../artisanlib/events.py" line="917" />
        <location filename="../artisanlib/events.py" line="913" />
        <location filename="../artisanlib/events.py" line="908" />
        <source>Slider Calculator</source>
        <translation>滑块计算器</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="3759" />
        <source>Event Custom Buttons Help</source>
        <translation>事件自定义按钮帮助</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="3768" />
        <source>Event Custom Sliders Help</source>
        <translation>事件自定义滑动条帮助</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="3777" />
        <source>Event Annotations Help</source>
        <translation>事件说明帮助</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13259" />
        <location filename="../artisanlib/main.py" line="3499" />
        <location filename="../artisanlib/calculator.py" line="60" />
        <location filename="../artisanlib/calculator.py" line="58" />
        <location filename="../artisanlib/events.py" line="3916" />
        <source>Event</source>
        <translation>事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="70" />
        <source>Scan Modbus</source>
        <translation>扫描通信协议</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="236" />
        <source>Scan S7</source>
        <translation>扫描 S7</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="390" />
        <source>Ports Configuration</source>
        <translation>端口配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1705" />
        <source>MODBUS Help</source>
        <translation>通信协议帮助</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1712" />
        <source>S7 Help</source>
        <translation>S7 帮助</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="49" />
        <source>Profile Background</source>
        <translation>背景曲线设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="79" />
        <source>Volume Calculator</source>
        <translation>体积计算器</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="560" />
        <source>Roast Properties</source>
        <translation>烘焙属性</translation>
    </message>
    <message>
        <location filename="../plus/blend.py" line="130" />
        <location filename="../artisanlib/roast_properties.py" line="1768" />
        <source>Custom Blend</source>
        <translation>自定义混合</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="4200" />
        <source>Energy Help</source>
        <translation>能源帮助</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="5894" />
        <source>Set Measure from Profile</source>
        <translation>从配置文件设置度量</translation>
    </message>
    <message>
        <location filename="../artisanlib/platformdlg.py" line="38" />
        <source>Artisan Platform</source>
        <translation>Artisan平台</translation>
    </message>
    <message>
        <location filename="../artisanlib/phases.py" line="33" />
        <source>Roast Phases</source>
        <translation>烘焙阶段</translation>
    </message>
    <message>
        <location filename="../artisanlib/logs.py" line="42" />
        <source>Serial Log</source>
        <translation>串行日志</translation>
    </message>
    <message>
        <location filename="../artisanlib/logs.py" line="89" />
        <source>Error Log</source>
        <translation>错误记录</translation>
    </message>
    <message>
        <location filename="../artisanlib/logs.py" line="125" />
        <source>Message History</source>
        <translation>历史信息</translation>
    </message>
    <message>
        <location filename="../artisanlib/designer.py" line="40" />
        <source>Designer Config</source>
        <translation>曲线设计器配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/designer.py" line="713" />
        <source>Add Point</source>
        <translation>添加点</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="38" />
        <source>Roast Calculator</source>
        <translation>烘焙计算器</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="59" />
        <source>Plotter Data</source>
        <translation>绘图仪数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="295" />
        <source>Curves</source>
        <translation>曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="4887" />
        <location filename="../artisanlib/devices.py" line="4878" />
        <location filename="../artisanlib/curves.py" line="2545" />
        <source>Symbolic Formulas Help</source>
        <translation>符号公式帮助</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="348" />
        <location filename="../artisanlib/statistics.py" line="42" />
        <source>Statistics</source>
        <translation>统计</translation>
    </message>
    <message>
        <location filename="../artisanlib/dialogs.py" line="606" />
        <source>Containers</source>
        <translation>容器</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="62" />
        <source>Alarms</source>
        <translation>警报</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="1160" />
        <source>Alarms Help</source>
        <translation>警报帮助</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13231" />
        <source>Keyboard Shortcuts Help</source>
        <translation>键盘快捷键帮助</translation>
    </message>
    <message>
        <location filename="../artisanlib/batches.py" line="35" />
        <source>Batch</source>
        <translation>批次</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="54" />
        <source>Device Assignment</source>
        <translation>设备分配</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="4896" />
        <source>External Programs Help</source>
        <translation>外部程序帮助</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="64" />
        <source>Profile Transposer</source>
        <translation>配置转换器</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="620" />
        <source>Profile Transposer Help</source>
        <translation>配置转换器帮助</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="41" />
        <source>Colors</source>
        <translation>色度</translation>
    </message>
    <message>
        <location filename="../artisanlib/cup_profile.py" line="50" />
        <source>Cup Profile</source>
        <translation>杯测设置</translation>
    </message>
</context><context>
    <name>GroupBox</name>
    <message>
        <location filename="../artisanlib/axis.py" line="438" />
        <source>Time Axis</source>
        <translation>时间轴</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="440" />
        <source>Temperature Axis</source>
        <translation>温度轴</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2716" />
        <location filename="../artisanlib/devices.py" line="2715" />
        <location filename="../artisanlib/curves.py" line="1053" />
        <location filename="../artisanlib/axis.py" line="442" />
        <source>Axis</source>
        <translation>坐标轴</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="444" />
        <source>Legend Location</source>
        <translation>图例位置</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="446" />
        <source>Grid</source>
        <translation>坐标格</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="144" />
        <source>Label Properties</source>
        <translation>标签属性</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="66" />
        <source>p-i-d</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="418" />
        <source>Output</source>
        <translation>输出</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="569" />
        <source>Set Value</source>
        <translation>设置值</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="606" />
        <source>Clamp</source>
        <translatorcomment>箝位</translatorcomment>
        <translation>钳位</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="621" />
        <source>Duty</source>
        <translatorcomment>佔空比</translatorcomment>
        <translation>占空比</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1223" />
        <source>Automatic Marking</source>
        <translation>自动打标</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1281" />
        <source>Event Types</source>
        <translation>事件类型</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1481" />
        <source>Default Buttons</source>
        <translation>默认按钮</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1493" />
        <source>Sampling</source>
        <translation>采样</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="215" />
        <location filename="../artisanlib/events.py" line="1564" />
        <source>Management</source>
        <translation>管理</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1130" />
        <location filename="../artisanlib/ports.py" line="665" />
        <source>Registers</source>
        <translation>寄存器</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1340" />
        <location filename="../artisanlib/ports.py" line="1147" />
        <location filename="../artisanlib/ports.py" line="682" />
        <source>Commands</source>
        <translation>指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1411" />
        <location filename="../artisanlib/ports.py" line="1170" />
        <location filename="../artisanlib/ports.py" line="694" />
        <source>PID</source>
        <translation>PID</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="836" />
        <location filename="../artisanlib/ports.py" line="723" />
        <source>Serial</source>
        <translation>串行</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="750" />
        <source>UDP/TCP</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="856" />
        <source>Input</source>
        <translation>输入</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1252" />
        <source>Machine</source>
        <translation>机器</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1291" />
        <source>Timeout</source>
        <translation>超时</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1328" />
        <source>Nodes</source>
        <translation>节点</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1358" />
        <source>Messages</source>
        <translation>信息</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1371" />
        <source>Flags</source>
        <translation>标志</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1430" />
        <source>Events</source>
        <translation>事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="470" />
        <source>Playback</source>
        <translation>回放</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="17009" />
        <location filename="../artisanlib/canvas.py" line="16947" />
        <location filename="../artisanlib/roast_properties.py" line="2902" />
        <source>Energy</source>
        <translation>能源</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="17010" />
        <location filename="../artisanlib/canvas.py" line="16948" />
        <location filename="../artisanlib/roast_properties.py" line="2903" />
        <source>CO2</source>
        <translation>二氧化碳</translation>
    </message>
    <message>
        <location filename="../artisanlib/designer.py" line="295" />
        <source>Initial Settings</source>
        <translation>初始设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="179" />
        <source>Rate of Change</source>
        <translation>变化率</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="181" />
        <source>Temperature Conversion</source>
        <translation>温度单位转换</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="183" />
        <source>Weight Conversion</source>
        <translation>重量单位转换</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="185" />
        <source>Volume Conversion</source>
        <translation>体积单位转换</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="187" />
        <source>Extraction Yield</source>
        <translation>萃取率</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="572" />
        <source>Rate of Rise Curves</source>
        <translation>RoR 曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="574" />
        <source>Rate of Rise LCDs</source>
        <translation>RoR LCDs</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="593" />
        <source>Rate of Rise Symbolic Assignments</source>
        <translation>RoR 符号分配</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="619" />
        <source>Input Filter</source>
        <translation>输入筛选器</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="632" />
        <source>Curve Filter</source>
        <translation>曲线筛选器</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="641" />
        <source>Display Filter</source>
        <translation>显示筛选器</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="691" />
        <source>Rate of Rise Filter</source>
        <translation>RoR 筛选器</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1080" />
        <source>Interpolate</source>
        <translation>插值</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1086" />
        <source>Univariate</source>
        <translation>单因素</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1094" />
        <source>ln()</source>
        <translation>自然对数函数</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1109" />
        <source>Exponent</source>
        <translation>指数</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1141" />
        <source>Polyfit</source>
        <translation>拟合</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1165" />
        <source>Curve Fit Options</source>
        <translation>曲线拟合选项</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1178" />
        <source>Interval of Interest Options</source>
        <translation>目的范围选项</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1192" />
        <source>Analyze Options</source>
        <translation>分析选项</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1250" />
        <source>Appearance</source>
        <translation>外观</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1260" />
        <source>Resolution</source>
        <translation>分辨率</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1336" />
        <source>WebLCDs</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1351" />
        <source>Rename ET and BT</source>
        <translation>重命名ET和BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1390" />
        <source>Logo Image File</source>
        <translation>Logo图像文件</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="212" />
        <location filename="../artisanlib/statistics.py" line="172" />
        <source>AUC</source>
        <translation>曲线下面积（AUC）</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="174" />
        <source>Display</source>
        <translation>显示</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="361" />
        <source>Stats Summary</source>
        <translation>统计摘要</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="19605" />
        <source>Task Green</source>
        <translation>生豆任务</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="19655" />
        <source>Task Roasted</source>
        <translation>烘焙任务</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="101" />
        <source>Curves</source>
        <translation>曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="111" />
        <source>LCDs</source>
        <translation>LCDs</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1028" />
        <location filename="../artisanlib/devices.py" line="985" />
        <source>Network</source>
        <translation>网络</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1059" />
        <source>Async</source>
        <translation>异步</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1061" />
        <source>IR</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1438" />
        <source>Arduino TC4</source>
        <translation>Arduino TC4</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1450" />
        <source>External Program</source>
        <translation>外部程序</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1464" />
        <source>Symbolic Assignments</source>
        <translation>符号分配</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1817" />
        <location filename="../artisanlib/devices.py" line="1815" />
        <source>Scale {0}</source>
        <translation>缩放 {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1928" />
        <source>Container Green</source>
        <translation>生豆桶</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1931" />
        <source>Container Roasted</source>
        <translation>熟豆桶</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1934" />
        <source>Task Display Green</source>
        <translation>任务显示生豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1936" />
        <source>Task Display Roasted</source>
        <translation>烘焙任务展示</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="497" />
        <source>Timer LCD</source>
        <translation>计时器LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="506" />
        <location filename="../artisanlib/colors.py" line="500" />
        <source>ET LCD</source>
        <translation>ET LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="509" />
        <location filename="../artisanlib/colors.py" line="503" />
        <source>BT LCD</source>
        <translation>BT LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="512" />
        <source>Extra Devices / PID SV LCD</source>
        <translation>额外设备 / PID SV LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="515" />
        <source>Ramp/Soak Timer LCD</source>
        <translation>缓升/恒温 计时器 显示器</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="518" />
        <source>Slow Cooling Timer LCD</source>
        <translation>慢冷定时器液晶屏</translation>
    </message>
</context><context>
    <name>HTML Report Template</name>
    <message>
        <location filename="../artisanlib/canvas.py" line="12822" />
        <location filename="../artisanlib/main.py" line="22318" />
        <location filename="../artisanlib/statistics.py" line="219" />
        <source>BBP Total Time</source>
        <translation>批次间规程(BBP) 总时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12825" />
        <location filename="../artisanlib/main.py" line="22319" />
        <location filename="../artisanlib/statistics.py" line="220" />
        <source>BBP Bottom Temp</source>
        <translation>批次间规程(BBP) 底部温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="221" />
        <source>BBP Summary</source>
        <translation>批次间规程(BBP) 摘要</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="223" />
        <source>BBP Summary compact</source>
        <translation>批次间规程(BBP) 紧凑摘要</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12867" />
        <location filename="../artisanlib/main.py" line="22216" />
        <location filename="../artisanlib/statistics.py" line="227" />
        <source>Whole Color</source>
        <translation>整豆色值</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22197" />
        <location filename="../artisanlib/main.py" line="21949" />
        <location filename="../artisanlib/main.py" line="15130" />
        <source>Profile</source>
        <translation>配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="21746" />
        <source>Roast Batches</source>
        <translation>烘焙批次</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22195" />
        <location filename="../artisanlib/main.py" line="21944" />
        <location filename="../artisanlib/main.py" line="21754" />
        <source>Batch</source>
        <translation>批次</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23099" />
        <location filename="../artisanlib/main.py" line="21755" />
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22285" />
        <location filename="../artisanlib/main.py" line="21952" />
        <location filename="../artisanlib/main.py" line="21757" />
        <source>Beans</source>
        <translation>生豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23101" />
        <location filename="../artisanlib/main.py" line="21955" />
        <location filename="../artisanlib/main.py" line="21758" />
        <source>In</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="21957" />
        <location filename="../artisanlib/main.py" line="21759" />
        <source>Out</source>
        <translation>结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23102" />
        <location filename="../artisanlib/main.py" line="21959" />
        <location filename="../artisanlib/main.py" line="21760" />
        <source>Loss</source>
        <translation>损失</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="21761" />
        <source>Def.</source>
        <translation>Def。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="21762" />
        <source>Def.L</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22010" />
        <location filename="../artisanlib/main.py" line="21763" />
        <source>SUM</source>
        <translation>合计</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="21938" />
        <source>Production Report</source>
        <translation>生产报告</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22196" />
        <location filename="../artisanlib/main.py" line="21946" />
        <source>Time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="21961" />
        <source>Defects</source>
        <translation>瑕疵</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="21963" />
        <source>Defects Loss</source>
        <translation>缺陷损失</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22268" />
        <location filename="../artisanlib/main.py" line="22198" />
        <source>Weight In</source>
        <translation>投豆重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22223" />
        <location filename="../artisanlib/main.py" line="22199" />
        <source>CHARGE BT</source>
        <translation>投豆 BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22230" />
        <location filename="../artisanlib/main.py" line="22200" />
        <source>FCs Time</source>
        <translation>一爆时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22232" />
        <location filename="../artisanlib/main.py" line="22201" />
        <source>FCs BT</source>
        <translation>一爆温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22242" />
        <location filename="../artisanlib/main.py" line="22202" />
        <source>DROP Time</source>
        <translation>排豆时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22244" />
        <location filename="../artisanlib/main.py" line="22203" />
        <source>DROP BT</source>
        <translation>排豆温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22204" />
        <source>Dry Percent</source>
        <translation>脱水占比</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22205" />
        <source>MAI Percent</source>
        <translation>梅纳占比</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22206" />
        <source>Dev Percent</source>
        <translation>发展占比</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22262" />
        <location filename="../artisanlib/main.py" line="22207" />
        <source>AUC</source>
        <translation>曲线下面积（AUC）</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22270" />
        <location filename="../artisanlib/main.py" line="22208" />
        <source>Weight Loss</source>
        <translation>失重</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23103" />
        <location filename="../artisanlib/main.py" line="22209" />
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22210" />
        <source>Cupping</source>
        <translation>杯测</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22211" />
        <source>Roaster</source>
        <translation>烘焙机</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22212" />
        <source>Capacity</source>
        <translation>容量</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22213" />
        <source>Operator</source>
        <translation>烘焙师</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22214" />
        <source>Organization</source>
        <translation>组织</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22215" />
        <source>Drum Speed</source>
        <translation>滚筒转速</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22217" />
        <source>Ground Color</source>
        <translation>咖啡粉色值</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22218" />
        <source>Color System</source>
        <translation>颜色系统</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22219" />
        <source>Screen Min</source>
        <translation>豆目最小</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22220" />
        <source>Screen Max</source>
        <translation>豆目最大</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22221" />
        <source>Bean Temp</source>
        <translation>豆温</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22222" />
        <source>CHARGE ET</source>
        <translation>投豆 ET</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22224" />
        <source>TP Time</source>
        <translation>回温点时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22225" />
        <source>TP ET</source>
        <translation>回温点ET</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22226" />
        <source>TP BT</source>
        <translation>回温点BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22227" />
        <source>DRY Time</source>
        <translation>转黄点时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22228" />
        <source>DRY ET</source>
        <translation>转黄点ET</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22229" />
        <source>DRY BT</source>
        <translation>转黄点BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22231" />
        <source>FCs ET</source>
        <translation>第一次爆裂ET</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22233" />
        <source>FCe Time</source>
        <translation>一爆结束时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22234" />
        <source>FCe ET</source>
        <translation>一爆结束ET</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22235" />
        <source>FCe BT</source>
        <translation>一爆结束BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22236" />
        <source>SCs Time</source>
        <translation>第二次爆裂时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22237" />
        <source>SCs ET</source>
        <translation>二爆结束ET</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22238" />
        <source>SCs BT</source>
        <translation>第二次爆裂BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22239" />
        <source>SCe Time</source>
        <translation>二爆结束时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22240" />
        <source>SCe ET</source>
        <translation>二爆结束ET</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22241" />
        <source>SCe BT</source>
        <translation>二爆结束 BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22243" />
        <source>DROP ET</source>
        <translation>排豆 ET</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22245" />
        <source>COOL Time</source>
        <translation>冷却时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22246" />
        <source>COOL ET</source>
        <translation>冷却ET</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22247" />
        <source>COOL BT</source>
        <translation>冷却BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22248" />
        <source>Total Time</source>
        <translation>总时长</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22249" />
        <source>Dry Phase Time</source>
        <translation>脱水阶段时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22250" />
        <source>Mid Phase Time</source>
        <translation>梅纳阶段时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22251" />
        <source>Finish Phase Time</source>
        <translation>结束阶段时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22252" />
        <source>Dry Phase RoR</source>
        <translation>脱水阶段RoR</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22253" />
        <source>Mid Phase RoR</source>
        <translation>梅纳阶段RoR</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22254" />
        <source>Finish Phase RoR</source>
        <translation>结束阶段RoR</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22255" />
        <source>Dry Phase Delta BT</source>
        <translation>脱水阶段达美BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22256" />
        <source>Mid Phase Delta BT</source>
        <translation>梅纳阶段达美BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22257" />
        <source>Finish Phase Delta BT</source>
        <translation>结束阶段达美BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22258" />
        <source>Finish Phase Rise</source>
        <translation>结束阶段上升</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22259" />
        <source>Total RoR</source>
        <translation>全程平均RoR</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22260" />
        <source>FCs RoR</source>
        <translation>第一次爆裂RoR</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22261" />
        <source>MET</source>
        <translation>最高环境温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22263" />
        <source>AUC Begin</source>
        <translation>AUC开始</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22264" />
        <source>AUC Base</source>
        <translation>AUC 基础</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22265" />
        <source>Dry Phase AUC</source>
        <translation>脱水阶段 AUC</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22266" />
        <source>Mid Phase AUC</source>
        <translation>梅纳阶段AUC</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22267" />
        <source>Finish Phase AUC</source>
        <translation>结束阶段AUC</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22269" />
        <source>Weight Out</source>
        <translation>排豆重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22271" />
        <source>Defects Weight</source>
        <translation>缺陷重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22272" />
        <source>Defect Loss</source>
        <translation>缺陷损失</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22273" />
        <source>Volume In</source>
        <translation>投豆 体积</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22274" />
        <source>Volume Out</source>
        <translation>排豆体积</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22275" />
        <source>Volume Gain</source>
        <translation>体积增加</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22276" />
        <source>Green Density</source>
        <translation>生豆密度</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22277" />
        <source>Roasted Density</source>
        <translation>熟豆密度</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22278" />
        <source>Moisture Greens</source>
        <translation>生豆含水率</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22279" />
        <source>Moisture Roasted</source>
        <translation>熟豆含水率</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22280" />
        <source>Moisture Loss</source>
        <translation>水份流失</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22281" />
        <source>Organic Loss</source>
        <translation>有机物流失</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22282" />
        <source>Ambient Humidity</source>
        <translation>环境湿度</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22283" />
        <source>Ambient Pressure</source>
        <translation>环境压力</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22284" />
        <source>Ambient Temperature</source>
        <translation>室内温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23774" />
        <location filename="../artisanlib/main.py" line="22286" />
        <source>Roasting Notes</source>
        <translation>烘焙笔记</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23783" />
        <location filename="../artisanlib/main.py" line="22287" />
        <source>Cupping Notes</source>
        <translation>杯测笔记</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22288" />
        <source>Heavy FC</source>
        <translation>较强一爆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22289" />
        <source>Low FC</source>
        <translation>较弱一爆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22290" />
        <source>Light Cut</source>
        <translation>浅中线</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22291" />
        <source>Dark Cut</source>
        <translation>深中线</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22292" />
        <source>Drops</source>
        <translation>滴油</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22293" />
        <source>Oily</source>
        <translation>油腻</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22294" />
        <source>Uneven</source>
        <translation>不均匀</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22295" />
        <source>Tipping</source>
        <translation>点灼伤</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22296" />
        <source>Scorching</source>
        <translation>灼伤</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22297" />
        <source>Divots</source>
        <translation>破裂</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22298" />
        <source>Mode</source>
        <translation>模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22299" />
        <source>BTU Batch</source>
        <translation>BTU 批量</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22300" />
        <source>BTU Batch per green kg</source>
        <translation>BTU批量每公斤生豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22301" />
        <source>CO2 Batch</source>
        <translation>CO2 批量</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22302" />
        <source>BTU Preheat</source>
        <translation>BTU 预热</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22303" />
        <source>CO2 Preheat</source>
        <translation>CO2 预热</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22304" />
        <source>BTU BBP</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22305" />
        <source>CO2 BBP</source>
        <translation>二氧化碳 BBP</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22306" />
        <source>BTU Cooling</source>
        <translation>BTU 冷却</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22307" />
        <source>CO2 Cooling</source>
        <translation>CO2 冷却</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22308" />
        <source>BTU Roast</source>
        <translation>BTU 烘焙</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22309" />
        <source>BTU Roast per green kg</source>
        <translation>BTU烘焙每公斤生豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22310" />
        <source>CO2 Roast</source>
        <translation>CO2 烘焙</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22311" />
        <source>CO2 Batch per green kg</source>
        <translation>CO2批量每公斤生豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22312" />
        <source>BTU LPG</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22313" />
        <source>BTU NG</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22314" />
        <source>BTU ELEC</source>
        <translation>BTU 电力</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22315" />
        <source>Efficiency Batch</source>
        <translation>有效批量</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22316" />
        <source>Efficiency Roast</source>
        <translation>有效烘焙</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22317" />
        <source>BBP Begin</source>
        <translation>BBP开始</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22320" />
        <source>BBP Begin to Bottom Time</source>
        <translation>BBP 开始到底部时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22321" />
        <source>BBP Bottom to CHARGE Time</source>
        <translation>BBP 触底至 CHARGE 时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22322" />
        <source>BBP Begin to Bottom RoR</source>
        <translation>BBP 开始触底 RoR</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22323" />
        <source>BBP Bottom to CHARGE RoR</source>
        <translation>BBP 底部至 CHARGE RoR</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22325" />
        <source>File Name</source>
        <translation>文件名</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23098" />
        <source>Roast Ranking</source>
        <translation>烘焙排名</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23183" />
        <source>Ranking Report</source>
        <translation>排名报告</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23351" />
        <source>AVG</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23702" />
        <source>Roasting Report</source>
        <translation>烘焙属性</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23703" />
        <source>Date:</source>
        <translation>日期:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23705" />
        <source>Beans:</source>
        <translation>豆名:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23707" />
        <source>Weight:</source>
        <translation>重量:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23711" />
        <source>Volume:</source>
        <translation>体积:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23713" />
        <source>Roaster:</source>
        <translation>烘焙机:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23715" />
        <source>Operator:</source>
        <translation>烘焙师:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23717" />
        <source>Organization:</source>
        <translation>组织:</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12796" />
        <location filename="../artisanlib/main.py" line="23719" />
        <source>Cupping:</source>
        <translation>杯测:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23721" />
        <source>Color:</source>
        <translation>颜色:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23723" />
        <source>Energy:</source>
        <translation>能源:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23725" />
        <source>CO2:</source>
        <translation>二氧化碳:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23727" />
        <source>CHARGE:</source>
        <translation>投豆:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23729" />
        <source>Size:</source>
        <translation>大小:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23732" />
        <source>Density:</source>
        <translation>密度:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23734" />
        <source>Moisture:</source>
        <translation>含水量:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23736" />
        <source>Ambient:</source>
        <translation>环境:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23738" />
        <source>TP:</source>
        <translation>回温点:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23740" />
        <source>DRY:</source>
        <translation>脱水:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23742" />
        <source>FCs:</source>
        <translation>第一次爆裂:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23744" />
        <source>FCe:</source>
        <translation>一爆结束:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23746" />
        <source>SCs:</source>
        <translation>第二次爆裂:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23748" />
        <source>SCe:</source>
        <translation>二爆结束:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23750" />
        <source>DROP:</source>
        <translation>排豆:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23752" />
        <source>COOL:</source>
        <translation>冷却:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23754" />
        <source>MET:</source>
        <translation>最高环境温度:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23756" />
        <source>CM:</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23758" />
        <source>Drying:</source>
        <translation>脱水:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23760" />
        <source>Maillard:</source>
        <translation>梅纳反应:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23762" />
        <source>Finishing:</source>
        <translation>完成:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23764" />
        <source>Cooling:</source>
        <translation>冷却:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23766" />
        <source>Background:</source>
        <translation>背景曲线:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23768" />
        <source>Alarms:</source>
        <translation>警报:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23770" />
        <source>RoR:</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23772" />
        <source>AUC:</source>
        <translation>曲线下面积（AUC）:</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23780" />
        <source>Events</source>
        <translation>事件</translation>
    </message>
</context><context>
    <name>HelpDlg</name>
    <message>
        <location filename="../help/alarms_help.py" line="14" />
        <source>ALARMS</source>
        <translation>警报</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="18" />
        <source>Each alarm is only triggered once.
Alarms are scanned in order from the top of the table to the bottom.</source>
        <translation>每个警报仅触发一次
警报从上至下按顺序发生.</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="69" />
        <location filename="../help/energy_help.py" line="43" />
        <location filename="../help/energy_help.py" line="32" />
        <location filename="../help/alarms_help.py" line="21" />
        <source>Field</source>
        <translation>字段</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="192" />
        <location filename="../help/symbolic_help.py" line="158" />
        <location filename="../help/symbolic_help.py" line="151" />
        <location filename="../help/symbolic_help.py" line="142" />
        <location filename="../help/symbolic_help.py" line="129" />
        <location filename="../help/symbolic_help.py" line="117" />
        <location filename="../help/symbolic_help.py" line="108" />
        <location filename="../help/symbolic_help.py" line="98" />
        <location filename="../help/symbolic_help.py" line="86" />
        <location filename="../help/symbolic_help.py" line="79" />
        <location filename="../help/symbolic_help.py" line="66" />
        <location filename="../help/symbolic_help.py" line="21" />
        <location filename="../help/energy_help.py" line="69" />
        <location filename="../help/energy_help.py" line="43" />
        <location filename="../help/energy_help.py" line="32" />
        <location filename="../help/eventbuttons_help.py" line="97" />
        <location filename="../help/eventbuttons_help.py" line="34" />
        <location filename="../help/eventbuttons_help.py" line="21" />
        <location filename="../help/eventsliders_help.py" line="37" />
        <location filename="../help/eventsliders_help.py" line="17" />
        <location filename="../help/keyboardshortcuts_help.py" line="17" />
        <location filename="../help/alarms_help.py" line="38" />
        <location filename="../help/alarms_help.py" line="32" />
        <location filename="../help/alarms_help.py" line="21" />
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="22" />
        <source>Nr</source>
        <translatorcomment>警报编号</translatorcomment>
        <translation>编号</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="22" />
        <source>Alarm number for reference.</source>
        <translation>供参考警报编号.</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="23" />
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="23" />
        <source>Activate or Deactivate the alarm.</source>
        <translation>激活或取消激活警报。</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="24" />
        <source>If Alarm</source>
        <translation>If Alarm（依赖触发）0无依赖</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="24" />
        <source>Alarm triggered only if the alarm with the given number was triggered before. Use 0 for no guard.</source>
        <translation>唯有在指定编号的报警之前被触发时才会触发报警。使用编号0表示无保护。</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="25" />
        <source>But Not</source>
        <translation>But Not（排除触发）0无排除</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="25" />
        <source>Alarm triggered only if the alarm with the given number was not triggered before. Use 0 for no guard.</source>
        <translation>唯有在指定编号的报警之前被触发时才会触发报警。使用编号0表示无保护。</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="26" />
        <source>From</source>
        <translation>来自</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="26" />
        <source>Alarm only triggered after the given event.</source>
        <translation>警报仅在指定事件后触发.</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="27" />
        <source>Time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="27" />
        <source>If not 00:00, alarm is triggered mm:ss after the event "From" happens.</source>
        <translation>如果不是 00:00，则在“From”事件发生后触发警报 mm:ss。</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="30" />
        <location filename="../help/eventannotations_help.py" line="17" />
        <location filename="../help/alarms_help.py" line="28" />
        <source>Source</source>
        <translation>来源</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="28" />
        <source>The observed temperature source.</source>
        <translation>观察到的温度源。</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="29" />
        <source>Condition</source>
        <translation>条件</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="29" />
        <source>Alarm is triggered if source rises above or below the specified temperature.</source>
        <translation>如果源高于或低于指定温度，则会触发警报。</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="26" />
        <location filename="../help/alarms_help.py" line="30" />
        <source>Temp</source>
        <translation>温度</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="30" />
        <source>The specified temperature limit.</source>
        <translation>指定的温度限制。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="97" />
        <location filename="../help/eventbuttons_help.py" line="26" />
        <location filename="../help/eventsliders_help.py" line="37" />
        <location filename="../help/eventsliders_help.py" line="19" />
        <location filename="../help/keyboardshortcuts_help.py" line="110" />
        <location filename="../help/keyboardshortcuts_help.py" line="56" />
        <location filename="../help/alarms_help.py" line="61" />
        <location filename="../help/alarms_help.py" line="31" />
        <source>Action</source>
        <translation>动作</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="31" />
        <source>The action to be triggered if all conditions are fulfilled.</source>
        <translation>满足所有条件时要触发的操作。</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="32" />
        <source>Commands for alarms with an action go here.  Anything after a &amp;#39;#&amp;#39; character is considered a comment and is ignored when processing the alarm.</source>
        <translation>带有操作的警报命令放在此处。'#'字符后的任何内容被视为注释，在处理警报时将被忽略.</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="35" />
        <source>ALARM CONFIGURATION OPTIONS</source>
        <translation>警报配置选项</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="34" />
        <location filename="../help/alarms_help.py" line="38" />
        <source>Option</source>
        <translation>选项</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="40" />
        <location filename="../help/alarms_help.py" line="39" />
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="39" />
        <source>Adds a new alarm to the bottom of the table.</source>
        <translation>新增警报至表格底部.</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="41" />
        <location filename="../help/alarms_help.py" line="40" />
        <source>Insert</source>
        <translation>插入</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="40" />
        <source>Inserts a new alarm above the selected alarm.</source>
        <translation>在所选警报上方插入新警报。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="42" />
        <location filename="../help/alarms_help.py" line="41" />
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="41" />
        <source>Deletes the selected alarm.</source>
        <translation>删除选定的警报。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="43" />
        <location filename="../help/alarms_help.py" line="42" />
        <source>Copy Table</source>
        <translation>复制表</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="42" />
        <source>Copy the alarm table in tab separated format to the clipboard.  Option or ALT click to copy a tabular format to the clipboard.</source>
        <translation>将制表符分隔格式的报警表复制到剪贴板。 Option 或 ALT 单击以将表格格式复制到剪贴板。</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="43" />
        <source>All On</source>
        <translation>全部打开</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="43" />
        <source>Enables all alarms.</source>
        <translation>启用所有警报。</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="44" />
        <source>All Off</source>
        <translation>全部关闭</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="44" />
        <source>Disables all alarms.</source>
        <translation>禁用所有警报。</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="45" />
        <source>Load</source>
        <translation>载入</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="45" />
        <source>Load alarm definition from a file.</source>
        <translation>从文件加载警报定义。</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="112" />
        <location filename="../help/alarms_help.py" line="46" />
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="46" />
        <source>Save the alarm definitions to a file.</source>
        <translation>将警报定义保存到文件中。</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="47" />
        <source>Clear</source>
        <translation>清除</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="47" />
        <source>Clears all alarms from the table.</source>
        <translation>清除表中的所有警报。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="44" />
        <location filename="../help/keyboardshortcuts_help.py" line="130" />
        <location filename="../help/keyboardshortcuts_help.py" line="57" />
        <location filename="../help/alarms_help.py" line="48" />
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="44" />
        <location filename="../help/alarms_help.py" line="48" />
        <source>Opens this window.</source>
        <translation>打开此窗口。</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="49" />
        <source>Load from Profile</source>
        <translation>从配置文件加载</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="49" />
        <source>when ticked will replace the alarm table when loading a profile with the alarms stored in the profile.  If there are no alarms in the profile the alarm table will be cleared.</source>
        <translation>勾选时将在加载配置文件时使用存储在配置文件中的警报替换警报表。 如果配置文件中没有警报，警报表将被清除。</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="50" />
        <source>Load from Background</source>
        <translation>从背景载入</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="50" />
        <source>when ticked will replace the alarm table when loading a background profile with the alarms stored in the profile.  If there are no alarms in the profile the alarm table will be cleared.</source>
        <translation>勾选后，当加载背景配置文件时，将使用配置文件中存储的警报替换警报表。 如果配置文件中没有警报，警报表将被清除。</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="51" />
        <source>PopUp TimeOut</source>
        <translation>弹窗超时</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="51" />
        <source>A PopUp will automatically close after this time if the OK button has not been clicked.</source>
        <translation>如果未单击确定按钮，弹出窗口将在此时间后自动关闭。</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="54" />
        <source>Alarm Actions</source>
        <translation>警报动作</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="58" />
        <source>Enter the Command into the Description field of the Alarm.</source>
        <translation>在警报的描述字段中输入命令。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="97" />
        <location filename="../help/eventsliders_help.py" line="37" />
        <location filename="../help/eventsliders_help.py" line="20" />
        <location filename="../help/alarms_help.py" line="61" />
        <source>Command</source>
        <translation>指令</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="17" />
        <location filename="../help/alarms_help.py" line="61" />
        <source>Meaning</source>
        <translation>意义</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="62" />
        <source>Pop Up</source>
        <translation>弹窗</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="62" />
        <source>&lt;text&gt;</source>
        <translation>&lt;文本&gt;</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="62" />
        <source>the text to  be displayed in the pop up</source>
        <translation>要在弹出窗口中显示的文本</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="99" />
        <location filename="../help/eventsliders_help.py" line="59" />
        <location filename="../help/alarms_help.py" line="63" />
        <source>Call Program</source>
        <translation>执行程序</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="99" />
        <location filename="../help/eventsliders_help.py" line="59" />
        <location filename="../help/alarms_help.py" line="63" />
        <source>A program/script path (absolute or relative)</source>
        <translation>程序/脚本路径（绝对或相对）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="99" />
        <location filename="../help/alarms_help.py" line="63" />
        <source>start an external program</source>
        <translation>启动外部程序</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="64" />
        <source>Event Button</source>
        <translation>事件按钮</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="64" />
        <source>&lt;button number&gt;[&gt;&lt;value&gt;],..,&lt;button number&gt;[&gt;&lt;value&gt;]</source>
        <translation>&lt;按钮编号&gt;[&gt;&lt;值&gt;],..,&lt;按钮编号&gt;[&gt;&lt;值&gt;]</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="64" />
        <source>triggers the button optional overwriting the button value with &lt;value&gt; (eg. ‘1&gt;10,2,3&gt;100’); the button number comes from the Events Buttons configuration</source>
        <translation>触发按钮（可选），用&lt;value&gt;覆盖按钮值（例如 “1&gt;10,2,3&gt;100”）；按钮编号来自 “事件按钮” 配置</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="65" />
        <source>Slider &lt;1&gt;</source>
        <translation>控制滑块 &lt;1&gt;</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="68" />
        <location filename="../help/alarms_help.py" line="67" />
        <location filename="../help/alarms_help.py" line="66" />
        <location filename="../help/alarms_help.py" line="65" />
        <source>&lt;value&gt;</source>
        <translation>&lt;值&gt;</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="65" />
        <source>set the slider for special event nr. 1 to the value</source>
        <translation>将 1 号特殊事件的滑块设置为该值</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="66" />
        <source>Slider &lt;2&gt;</source>
        <translation>控制滑块 &lt;2&gt;</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="66" />
        <source>set the slider for special event nr. 2 to the value</source>
        <translation>将第 2 号特别活动的滑块设置为该值</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="67" />
        <source>Slider &lt;3&gt;</source>
        <translation>控制滑块 &lt;3&gt;</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="67" />
        <source>set the slider for special event nr. 3 to the value</source>
        <translation>设置特殊事件 nr 的滑块。 3 到数值</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="68" />
        <source>Slider &lt;4&gt;</source>
        <translation>控制滑块 &lt;4&gt;</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="68" />
        <source>set the slider for special event nr. 4 to the value</source>
        <translation>将第 4 号特殊事件的滑块设置为该值</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="69" />
        <source>START</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="69" />
        <source>trigger START</source>
        <translation>触发开始</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="70" />
        <source>DRY</source>
        <translation>脱水</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="70" />
        <source>trigger the DRY event</source>
        <translation>触发 DRY 事件</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="71" />
        <source>FCs</source>
        <translation>第一次爆裂</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="71" />
        <source>trigger the FCs event</source>
        <translation>触发 FCs 事件</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="72" />
        <source>FCe</source>
        <translation>一爆结束</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="72" />
        <source>trigger the FCe event</source>
        <translation>触发FCe事件</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="73" />
        <source>SCs</source>
        <translation>第二次爆裂</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="73" />
        <source>trigger the SCs event</source>
        <translation>触发 SCs 事件</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="74" />
        <source>SCe</source>
        <translation>二爆结束</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="74" />
        <source>trigger the SCe event</source>
        <translation>触发 SCe 事件</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="75" />
        <source>DROP</source>
        <translation>排豆</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="75" />
        <source>trigger the DROP event</source>
        <translation>触发 DROP 事件</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="76" />
        <source>COOL END</source>
        <translation>冷却结束</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="76" />
        <source>trigger the COOL END event</source>
        <translation>触发 COOL END 事件</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="77" />
        <source>OFF</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="77" />
        <source>trigger OFF</source>
        <translation>触发关闭</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="78" />
        <source>CHARGE</source>
        <translation>投豆</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="78" />
        <source>trigger the CHARGE event</source>
        <translation>触发 CHARGE 事件</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="79" />
        <source>RampSoak ON</source>
        <translation>缓升恒温 打开</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="79" />
        <source>turns PID on and switches to RampSoak mode</source>
        <translation>打开PID并切换至缓升恒温模式</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="80" />
        <source>RampSoak OFF</source>
        <translation>缓升恒温 关闭</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="80" />
        <source>turns PID off and switches to manual mode</source>
        <translation>关闭PID并切换至手动模式</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="81" />
        <source>Set Canvas Color</source>
        <translation>设置画布颜色</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="81" />
        <source>&lt;color&gt;</source>
        <translation>&lt;颜色&gt;</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="81" />
        <source>sets the canvas to &lt;color&gt;, can be in hex format, e.g. "#ffaa55" or a color name, e.g. "blue"</source>
        <translation>将画布设置为 &lt;color&gt;，可以是十六进制格式，例如“#ffaa55”或颜色名称，例如“蓝色的”</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="82" />
        <source>Reset Canvas Color</source>
        <translation>重置画布颜色</translation>
    </message>
    <message>
        <location filename="../help/alarms_help.py" line="82" />
        <source>reset the canvas color to the color specified in Config&gt;&gt;Colors
canvas color resets automatically at OFF</source>
        <translation>将画布颜色重置为 Config&gt;&gt;Colors 中指定的颜色
画布颜色在关闭时自动重置</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="14" />
        <source>EXTERNAL PROGRAMS</source>
        <translation>外部项目</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="18" />
        <source>Link external programs that print temperature when called.  This allows to connect meters that use any program language.

Artisan will start the program each sample period.  The program output must be to stdout (like when using print statements).  The program must exit and must not be persistent.</source>
        <translation>链接在调用时打印温度的外部程序。这允许连接使用任何程序语言的仪表。

Artisan 将在每个采样周期启动程序。程序输出必须是标准输出（就像使用打印语句时一样）。该程序必须退出并且不得持久存在。</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="18" />
        <source>If only one temperature is provided it will be interpreted as BT.  If more than one temperature is provided the values are order dependent with ET first and BT second.</source>
        <translation>如果仅提供一种温度，则会被解释为 BT。如果提供了多个温度，则这些值取决于顺序，首先是 ET，其次是 BT。</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="18" />
        <source>Data may also be provided to the "Program" extra devices.  Extra device "Program" are the first two values, typically ET and BT.  "Program 34" are the third and fourth values.  Up to 10 values may be supplied.</source>
        <translation>数据也可以提供给“程序”额外设备。额外设备“程序”是前两个值，通常是 ET 和 BT。 “Program 34”是第三个和第四个值。最多可以提供 10 个值。</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="18" />
        <source>Example of output needed from program for single temperature (BT):
"100.4" (note: "" not needed)</source>
        <translation>单一温度 (BT) 程序所需的输出示例：
“100.4”（注：“”不需要）</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="18" />
        <source>Example of output needed from program for double temperature (ET,BT)
"200.4,100.4" (note: temperatures are separated by a comma "ET,BT")</source>
        <translation>双温 (ET,BT) 程序所需的输出示例
“200.4,100.4”（注意：温度用逗号“ET,BT”隔开）</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="18" />
        <source>Example of output needed from program for double temperature (ET,BT) and extra devices (Program and Program 34)
"200.4,100.4,312.4,345.6,299.0,275.5"</source>
        <translation>双温（ET、BT）和额外设备（程序和程序 34）程序所需的输出示例
"200.4,100.4,312.4,345.6,299.0,275.5"</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="22" />
        <source>Example of a file written in Python called test.py:</source>
        <translation>用 Python 编写的名为 test.py 的文件示例：</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="22" />
        <source>#comment: print a string with two numbers separated by a comma</source>
        <translation>#comment: 打印一个字符串，两个数字用逗号隔开</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="22" />
        <location filename="../help/programs_help.py" line="22" />
        <source>#!/usr/bin/env python</source>
        <translation />
    </message>
    <message>
        <location filename="../help/programs_help.py" line="22" />
        <source>print("237.1,100.4")</source>
        <translation>打印（“237.1,100.4”）</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="22" />
        <source>Note: In many cases the path to the Python or other language executatable should be provided along with the external program path.  On Windows it is  advised to enclose the paths with quotation marks if there are any spaces, and use forward slashes &amp;#39;/&amp;#39; in the path.
"C:/Python38-64/python.exe" "c:/scripts/test.py"</source>
        <translation>注意：在许多情况下，Python 或其他语言可执行文件的路径应与外部程序路径一起提供。在 Windows 上，如果有空格，建议用引号将路径括起来，并使用正斜杠 &amp;#39;/&amp;#39;在路径中。
"C:/Python38-64/python.exe" "c:/scripts/test.py"</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="22" />
        <source> Under Output a script can be specified which is called per sample interval with 4 arguments, ET, BT, Background ET and Background BT</source>
        <translation> 在输出下可以指定一个脚本，每个采样间隔使用 4 个参数 ET、BT、背景 ET 和背景 BT 调用该脚本</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="22" />
        <source> the output script also called if Prog is not selected as input source</source>
        <translation> 如果未选择 Prog 作为输入源，也会调用输出脚本</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="22" />
        <source> Example of a file written in Python called out.py:</source>
        <translation> 用 Python 编写的名为 out.py 的文件示例：</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="22" />
        <source>#comment: adds the script arguments ET, BT, ETB, BTB to "/tmp/out.txt"</source>
        <translation>#comment：将脚本参数 ET、BT、ETB、BTB 添加到“/tmp/out.txt”</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="22" />
        <source>import sys</source>
        <translation>导入系统</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="22" />
        <source>ET, BT, ETB, BTB = sys.argv[1:]</source>
        <translation />
    </message>
    <message>
        <location filename="../help/programs_help.py" line="22" />
        <source>with open("/tmp/out.txt", "w+") as file:</source>
        <translation>以 open("/tmp/out.txt", "w+") 作为文件：</translation>
    </message>
    <message>
        <location filename="../help/programs_help.py" line="22" />
        <source>    file.write(f&amp;#39;ET: {ET}, BT: {ET}, ETB: {ETB}, BTB: {BTB};&amp;#39;)</source>
        <translation />
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="14" />
        <source>KEYBOARD SHORTCUTS</source>
        <translation>键盘快捷键</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="110" />
        <location filename="../help/keyboardshortcuts_help.py" line="17" />
        <source>Keys</source>
        <translation>键</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="18" />
        <source>Turns ON/OFF Keyboard Shortcuts</source>
        <translation>打开/关闭键盘快捷键</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="19" />
        <source>Starts recording</source>
        <translation>开始录制</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="20" />
        <source>Turns Artisan OFF</source>
        <translation>关闭 Artisan</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="21" />
        <source>When Keyboard Shortcuts are ON chooses the current button
When Keyboard Shortcuts are OFF adds a custom event
When Meter=NONE opens dialog to manually enter temperatures during roast</source>
        <translation>当键盘快捷键打开时选择当前按钮
当键盘快捷键关闭时添加自定义事件
当 Meter=NONE 时，打开对话框以在烘焙过程中手动输入温度</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="22" />
        <source>Change roast event key focus (when Keyboard Shortcuts are ON)</source>
        <translation>更改烘焙事件关键焦点（当键盘快捷键启用时）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="23" />
        <source>Move background (when sliders not visible or when Config&gt;&gt; Events&gt;&gt; Sliders tab&gt;&gt; Keyboard Control is not selected)</source>
        <translation>移动背景（当滑块不可见或配置&gt;&gt;事件&gt;&gt;滑块选项卡&gt;&gt;键盘控制未被选中时）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="24" />
        <source>Autosave</source>
        <translation>自动保存</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="25" />
        <source>Autosave + RESET + START</source>
        <translation>自动保存 + 重置 + 开始</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="26" />
        <source>Toggle mouse cross lines</source>
        <translation>切换鼠标交叉线</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="27" />
        <source>Toggle auto axis mode between Roast, BBP+Roast and BBP</source>
        <translation>在 Roast、BBP+Roast 和 BBP 之间切换自动轴模式</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="28" />
        <source>Toggle xy cursor mode (off/temp/delta)</source>
        <translation>切换 xy 光标模式（关闭/温度/变化率）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="29" />
        <source>Toggle xy cursor clamp mode (off/BT/ET/BTB/ETB)</source>
        <translation>切换 xy 光标钳制模式（关闭/BT/ET/BTB/ETB）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="30" />
        <source>Toggle LCD cursor (off/profile/background)</source>
        <translation>切换 LCD 光标（关闭/配置文件/背景）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="31" />
        <source>Shows/Hides Controls</source>
        <translation>显示/隐藏控件</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="32" />
        <source>Shows/Hides LCD Readings</source>
        <translation>显示/隐藏 LCD 读数</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="33" />
        <source>Shows/Hides Mini Event editor</source>
        <translation>显示 / 隐藏迷你事件编辑器</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="34" />
        <source>Shows/Hides Event Buttons</source>
        <translation>显示/隐藏事件按钮</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="35" />
        <source>Shows/Hides Extra Event Buttons</source>
        <translation>显示/隐藏额外事件按钮</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="36" />
        <source>Shows/Hides Event Sliders</source>
        <translation>显示/隐藏事件滑块</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="37" />
        <source>Toggle PID mode</source>
        <translation>切换 PID 模式</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="38" />
        <source>Toggle Playback Events</source>
        <translation>切换播放事件</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="39" />
        <source>Load background profile</source>
        <translation>载入背景曲线</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="40" />
        <source>Remove background profile</source>
        <translation>移除背景曲线</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="41" />
        <source>Toggle foreground curves “show full”</source>
        <translation>切换前景曲线“显示完整”</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="42" />
        <source>Toggle background curves “show full”</source>
        <translation>切换背景曲线“显示完整”</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="43" />
        <source>Load alarms
(Expert and Standard modes)</source>
        <translation>加载警报
（专家和标准模式）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="44" />
        <source>Changes Event Button Palettes
(Can be disabled or enabled in Expert mode Config&gt;&gt; Events&gt;&gt; Palettes&gt;&gt; Switch Using Number Keys and Cmd)</source>
        <translation>更改事件按钮调色板
（可在专家模式配置&gt;&gt;事件&gt;&gt;调色板&gt;&gt;通过数字键和Cmd切换中禁用或启用）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="45" />
        <source>Application ScreenShot
(Expert and Standard modes)</source>
        <translation>应用截图
（专家和标准模式）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="46" />
        <source>Desktop ScreenShot
(Expert and Standard modes)</source>
        <translation>桌面截图
（专家和标准模式）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="47" />
        <source>Quick Special Event Entry.  The keys q,w,e, and r correspond to special events 1,2,3 and 4. The new &lt;value&gt; is established using the ENTER/RETURN key. The last digit can be removed by using the backspace key.</source>
        <translation>快速特殊事件输入。q、w、e 和 r 键分别对应特殊事件 1、2、3 和 4。使用 ENTER/RETURN 键可确定新的 &lt;数值&gt;。使用退格键可删除最后一位数字。</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="48" />
        <source>Quick PID SV Entry. The new &lt;value&gt; is established using the ENTER/RETURN key. The last digit can be removed by using the backspace key.</source>
        <translation>快速输入 PID SV。使用 ENTER/RETURN 键建立新的 &lt;数值&gt;。使用退格键可以删除最后一位数字。</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="49" />
        <source>Fire custom event button action. Value is a two digit number indicating the button number.</source>
        <translation>触发自定义事件按钮操作。值是一个两位数，表示按钮编号。</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="50" />
        <source>Full Screen Mode</source>
        <translation>全屏模式</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="53" />
        <source>ADDITIONAL SHORTCUTS</source>
        <translation>其他快捷方式</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="56" />
        <source>Key/mouse stroke(s)</source>
        <translation>键盘 / 鼠标按键操作</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="56" />
        <source>Where</source>
        <translation>在哪里</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="56" />
        <source>Additional Information</source>
        <translation>附加信息</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="57" />
        <source>⌘+F [Mac]
CTRL+F [Win]</source>
        <translation />
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="57" />
        <source>Move cursor to the Search box</source>
        <translation>将光标移至搜索框</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="57" />
        <source>Return/Enter key to execute the search</source>
        <translation>按回车键执行搜索</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="58" />
        <source>Click on Roast Title</source>
        <translation>点击“烘焙标题”</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="79" />
        <location filename="../help/keyboardshortcuts_help.py" line="78" />
        <location filename="../help/keyboardshortcuts_help.py" line="77" />
        <location filename="../help/keyboardshortcuts_help.py" line="76" />
        <location filename="../help/keyboardshortcuts_help.py" line="75" />
        <location filename="../help/keyboardshortcuts_help.py" line="74" />
        <location filename="../help/keyboardshortcuts_help.py" line="73" />
        <location filename="../help/keyboardshortcuts_help.py" line="72" />
        <location filename="../help/keyboardshortcuts_help.py" line="71" />
        <location filename="../help/keyboardshortcuts_help.py" line="70" />
        <location filename="../help/keyboardshortcuts_help.py" line="69" />
        <location filename="../help/keyboardshortcuts_help.py" line="68" />
        <location filename="../help/keyboardshortcuts_help.py" line="67" />
        <location filename="../help/keyboardshortcuts_help.py" line="66" />
        <location filename="../help/keyboardshortcuts_help.py" line="65" />
        <location filename="../help/keyboardshortcuts_help.py" line="64" />
        <location filename="../help/keyboardshortcuts_help.py" line="63" />
        <location filename="../help/keyboardshortcuts_help.py" line="62" />
        <location filename="../help/keyboardshortcuts_help.py" line="61" />
        <location filename="../help/keyboardshortcuts_help.py" line="59" />
        <location filename="../help/keyboardshortcuts_help.py" line="58" />
        <source>Graph</source>
        <translation>图形</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="58" />
        <source>Open Roast Properties</source>
        <translation>打开烘焙属性对话框</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="59" />
        <source>Double click on Roast Title</source>
        <translation>双击烘焙标题</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="59" />
        <source>Open the roast in artisan.plus</source>
        <translation>在 artisan.plus 中打开烘焙</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="59" />
        <source>Requires an artisan.plus account</source>
        <translation>需要一个 artisan.plus 帐户</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="60" />
        <source>Double click on Background Profile Title</source>
        <translation>双击背景曲线标题</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="60" />
        <source>Graph &amp; Designer</source>
        <translation>图表设计师</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="60" />
        <source>Toggle Show/Hide Background Profile</source>
        <translation>Toggle 显示/隐藏背景配置文件</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="60" />
        <source>Only when a Background profile is loaded</source>
        <translation>仅在加载背景配置文件时</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="61" />
        <source>Double click on Graph canvas</source>
        <translation>双击曲线图形画布</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="61" />
        <source>Auto zoom out to show min and max of temperature curves
Double click again to zoom in to original view</source>
        <translation>自动缩小以显示温度曲线的最小值和最大值
再次双击可放大回原始视图</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="62" />
        <source>Right click on BT curve</source>
        <translation>右击BT曲线</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="62" />
        <source>Place or re-place events</source>
        <translation>放置或替换事件</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="63" />
        <source>Right click on timer</source>
        <translation>右键单击计时器</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="63" />
        <source>Toggle super mode</source>
        <translation>切换超级模式</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="64" />
        <source>Right click on characteristics line below graph</source>
        <translation>右键单击图表下方的特征线</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="64" />
        <source>Toggle set of characteristics displayed</source>
        <translation>切换显示的特征集</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="64" />
        <source>Characteristics must be enabled in Config&gt;&gt; Statistics</source>
        <translation>必须在 Config&gt;&gt; Statistics 中启用特性</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="65" />
        <source>Click on plus icon (when not red)</source>
        <translation>点击加号图标（当不是红色时）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="65" />
        <source>Toggle connect/disconnect to plus</source>
        <translation>切换连接/断开连接到 plus</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="66" />
        <source>Click on plus icon (when it is red)</source>
        <translation>点击加号图标（当它是红色时）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="66" />
        <source>Sync the roast with artisan.plus</source>
        <translation>将烘焙与 artisan.plus 同步</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="67" />
        <source>⌘ click on plus icon [Mac]
CTRL click on plus icon [Win]</source>
        <translation>⌘ 点击加号图标 [Mac]
CTRL 点击加号图标 [Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="67" />
        <source>When connected to plus, disconnect and clear credentials</source>
        <translation>连接到 plus 时，断开连接并清除凭据</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="68" />
        <source>OPTION click on plus icon [Mac]
ALT click on plus icon [Win]</source>
        <translation>选项单击加号图标 [Mac]
ALT 点击加号图标 [Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="68" />
        <source>Generate email message with Artisan Logs</source>
        <translation>使用 Artisan Logs 生成电子邮件</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="69" />
        <source>⌘+OPTION click on plus icon [Mac]
CTRL+ALT click on plus icon [Win]</source>
        <translation>⌘+OPTION 点击加号图标 [Mac]
CTRL+ALT 点击加号图标 [Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="69" />
        <source>Toggle debug logging mode</source>
        <translation>切换调试日志记录模式</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="70" />
        <source>OPTION File&gt;&gt; New&gt;&gt; &lt;recent-roast&gt; [Mac]
ALT File&gt;&gt; New&gt;&gt; &lt;recent-roast&gt; [Win]</source>
        <translation>选项文件&gt;&gt; 新建&gt;&gt; &lt;最近的烘焙&gt; [Mac]
ALT File&gt;&gt; New&gt;&gt; &lt;最近的烘焙&gt; [Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="70" />
        <source>Sets roast properties to &lt;recent-roast&gt; without starting a new roast</source>
        <translation>将烘焙属性设置为 &lt;最近的烘焙&gt; 而不开始新的烘焙</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="71" />
        <source>Click on LCD</source>
        <translation>点击液晶屏</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="72" />
        <location filename="../help/keyboardshortcuts_help.py" line="71" />
        <source>Hide or Show corresponding Curve</source>
        <translation>隐藏或显示相应的曲线</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="71" />
        <source>In OFF state this changes the Artisan Settings, in ON/START states the change is temporary until OFF state</source>
        <translation>在关闭状态下，这会更改 Artisan 设置；在开启 / 启动状态下，更改是临时的，直到切换到关闭状态为止</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="72" />
        <source>Click on label in the Legend</source>
        <translation>点击图例中的标签</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="72" />
        <source>Only in OFF state when the Legend is displayed</source>
        <translation>仅在显示 Legend 时处于 OFF 状态</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="73" />
        <source>OPTION click &amp;#39;RESET&amp;#39; Button [Mac]
ALT click &amp;#39;RESET&amp;#39; Button [Win]</source>
        <translation>选项点击 'RESET'按钮 [Mac]
ALT 点击 'RESET'按钮 [Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="73" />
        <source>Detach IO Phidgets</source>
        <translation>分离 IO Phidgets</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="76" />
        <location filename="../help/keyboardshortcuts_help.py" line="75" />
        <location filename="../help/keyboardshortcuts_help.py" line="74" />
        <source>⌘ click &amp;#39;CONTROL&amp;#39; Button [Mac]
CTRL click &amp;#39;CONTROL&amp;#39; Button [Win]</source>
        <translation>⌘ 点击“CONTROL”按钮 [Mac]
CTRL 点击“CONTROL”按钮 [Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="74" />
        <source>Toggle PID Standby on and off</source>
        <translation>打开和关闭 PID 待机</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="74" />
        <source>Device = Fuji or Delta</source>
        <translation>设备 = 富士或台达</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="75" />
        <source>Opens PID dialog</source>
        <translation>打开 PID 对话框</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="75" />
        <source>Device = Hottop</source>
        <translation>设备 = Hottop</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="76" />
        <source>Toggle PID</source>
        <translation>切换 PID</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="76" />
        <source>Device = &lt;all others&gt;, Control enabled in Expert mode: Config&gt;&gt; Device</source>
        <translation>设备 = &lt;所有其他设备&gt;，专家模式下启用控制：配置&gt;&gt;设备</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="80" />
        <location filename="../help/keyboardshortcuts_help.py" line="77" />
        <source>PLUS, MINUS</source>
        <translation>PLUS, MINUS</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="77" />
        <source>Increase or Decrease PID lookahead</source>
        <translation>增加或减少PID预判</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="78" />
        <source>⌘+PLUS, ⌘+MINUS [Mac]
CTRL+SHIFT+PLUS, CTRL+MINUS [Win]</source>
        <translation>⌘+加号、⌘+减号 [Mac]
CTRL+SHIFT+加号、CTRL+减号 [Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="78" />
        <source>Increase or Decrease Graph Resolution %</source>
        <translation>增加或减少图形分辨率 %</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="78" />
        <source>Same as Config&gt;&gt; Curves&gt;&gt; UI tab&gt;&gt; Graph % +/-</source>
        <translation>与配置&gt;&gt;曲线&gt;&gt; UI 选项卡&gt;&gt;图形 % +/- 相同</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="79" />
        <source>Click on a custom Event</source>
        <translation>点击自定义事件</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="79" />
        <source>Select a custom Event</source>
        <translation>选择一个自定义事件</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="79" />
        <source>Event time highlighted with vertical yellow line</source>
        <translation>事件时间以黄色垂直线高亮显示</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="82" />
        <location filename="../help/keyboardshortcuts_help.py" line="81" />
        <location filename="../help/keyboardshortcuts_help.py" line="80" />
        <source>Graph when Event selected</source>
        <translation>选择事件时显示图表</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="80" />
        <source>Increase or Decrease Event value</source>
        <translation>增加或减少事件值</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="81" />
        <source>BACKSPACE</source>
        <translation>BACKSPACE</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="81" />
        <source>Delete the selected Event</source>
        <translation>删除所选事件</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="82" />
        <source>ESC</source>
        <translation>ESC</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="82" />
        <source>Deselect the custom Event</source>
        <translation>取消选择自定义事件</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="83" />
        <source>TAB</source>
        <translation>标签</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="86" />
        <location filename="../help/keyboardshortcuts_help.py" line="85" />
        <location filename="../help/keyboardshortcuts_help.py" line="84" />
        <location filename="../help/keyboardshortcuts_help.py" line="83" />
        <source>Graph when Sliders visible</source>
        <translation>滑块可见时的图形</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="83" />
        <source>Sequence slider select</source>
        <translation>序列滑块选择</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="85" />
        <location filename="../help/keyboardshortcuts_help.py" line="84" />
        <location filename="../help/keyboardshortcuts_help.py" line="83" />
        <source>Requires Keyboard Control enabled in Expert mode: Config&gt;&gt; Events&gt;&gt; Sliders
Keyboard Shortcuts must be turned off (ENTER)</source>
        <translation>需要在专家模式下启用键盘控制：配置&gt;&gt;事件&gt;&gt;控制滑块
必须关闭键盘快捷键（按ENTER键）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="84" />
        <source>UP,DOWN,RIGHT,LEFT</source>
        <translation>上、下、右、左</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="84" />
        <source>Increment selected slider up or down by step amount</source>
        <translation>按步长向上或向下增加选定的滑块</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="85" />
        <source>OPTION+UP, OPTION+DOWN [Mac]
PAGEUP,PAGEDOWN [Win]</source>
        <translation>选项+向上，选项+向下 [Mac]
PAGEUP,PAGEDOWN [Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="85" />
        <source>Increment selected slider up or down by 10</source>
        <translation>将选定的滑块向上或向下增加 10</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="86" />
        <source>HOME,END</source>
        <translation>HOME,END</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="86" />
        <source>Set selected slider to minimum or maximum value</source>
        <translation>将选定的滑块设置为最小值或最大值</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="86" />
        <source>Requires Keyboard Control enabled in Expert mode: Config&gt;&gt; Events&gt;&gt; Sliders
Keyboard Shortcuts must be disabled (ENTER)</source>
        <translation>需在专家模式下启用键盘控制：配置&gt;&gt;事件&gt;&gt;滑块
必须禁用键盘快捷键（回车键）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="87" />
        <source>Click on timer</source>
        <translation>点击计时器</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="87" />
        <source>Simulator
(Expert mode)</source>
        <translation>模拟器
（专家模式）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="87" />
        <source>Toggle Pause/Continue Simulation</source>
        <translation>切换暂停/继续模拟</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="87" />
        <source>Simulator speed may be changed while paused (hold shift  (1x), OPTION/ALT (2x) or COMMAND/CTRL (4x) on restart).</source>
        <translation>暂停时也可以调整模拟器速度（重启时按住shift键（1倍速）、OPTION/ALT键（2倍速）或COMMAND/CTRL键（4倍速））。</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="88" />
        <source>OPTION Tools&gt;&gt;Simulator [Mac]
ALT Tools&gt;&gt;Simulator [Win]</source>
        <translation>选项工具&gt;&gt;模拟器[Mac]
ALT工具&gt;&gt;模拟器[Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="89" />
        <location filename="../help/keyboardshortcuts_help.py" line="88" />
        <source>Graph/Simulator
(Expert mode)</source>
        <translation>曲线图/模拟器
（专家模式）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="88" />
        <source>Start or change Simulator speed to 2x mode</source>
        <translation>启动或将模拟器速度更改为 2x 模式</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="89" />
        <source>⌘ Tools&gt;&gt;Simulator [Mac]
CTRL Tools&gt;&gt;Simulator [Win]</source>
        <translation>⌘ 工具&gt;&gt;模拟器 [Mac]
CTRL工具&gt;&gt;模拟器[Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="89" />
        <source>Start or change Simulator speed to 4x mode</source>
        <translation>启动或将模拟器速度更改为 4 倍模式</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="90" />
        <source>⌘+L [Mac]
CTRL+L [Win]</source>
        <translation>⌘+L [Mac]
CTRL+L [Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="90" />
        <source>Roast Properties Roast tab
(Expert and Standard modes)</source>
        <translation>烘焙属性 烘焙选项卡
（专家和标准模式）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="90" />
        <source>Open volume calculator</source>
        <translation>打开体积计算器</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="91" />
        <source>OPTION click Stock [Mac]
ALT click Stock [Win]</source>
        <translation>选项 点击 Stock  [苹果电脑]
按住 Alt 键点击Stock [Windows 系统]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="95" />
        <location filename="../help/keyboardshortcuts_help.py" line="94" />
        <location filename="../help/keyboardshortcuts_help.py" line="93" />
        <location filename="../help/keyboardshortcuts_help.py" line="92" />
        <location filename="../help/keyboardshortcuts_help.py" line="91" />
        <source>Roast Properties Roast tab</source>
        <translation>烘焙属性 烘焙选项卡</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="91" />
        <source>Show plus Stock in alternate weight unit from Artisan setting (imperial &lt;-&gt; metric)</source>
        <translation>显示加上来自 Artisan 设置的替代重量单位的库存（英制 &lt;-&gt; 公制）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="91" />
        <source>Requires a connection to plus</source>
        <translation>需要连接到 plus</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="92" />
        <source>OPTION click  &amp;#39;+&amp;#39;  button [Mac]
ALT click  &amp;#39;+&amp;#39;  button [Win]</source>
        <translation>选项点击 &amp;#39;+&amp;#39;按钮 [Mac]
ALT 点击 &amp;#39;+&amp;#39;按钮 [Mac]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="92" />
        <source>Adds Weight Roasted, Volume Roasted, Moisture Roasted, ColorWhole, and Color Ground to the recent roast</source>
        <translation>在最近的烘焙中添加重量烘焙、体积烘焙、水分烘焙、ColorWhole 和 Color Ground</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="93" />
        <source>⌘+I [Mac]
CTRL+I [Win]</source>
        <translation>⌘+I [Mac]
CTRL+I [Mac]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="93" />
        <source>Adds scale weight to Green Weight field (same action as &amp;#39;in&amp;#39; button)</source>
        <translation>将秤重量添加到生豆重量字段（与 &amp;#39;in&amp;#39; 按钮相同的操作）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="97" />
        <location filename="../help/keyboardshortcuts_help.py" line="96" />
        <location filename="../help/keyboardshortcuts_help.py" line="95" />
        <location filename="../help/keyboardshortcuts_help.py" line="94" />
        <location filename="../help/keyboardshortcuts_help.py" line="93" />
        <source>Requires a connected scale</source>
        <translation>需要连接秤</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="94" />
        <source>⌘+O [Mac]
CTRL+O [Win]</source>
        <translation>⌘+O [Mac]
CTRL+O [Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="94" />
        <source>Adds scale weight to Roasted Weight field (same action as &amp;#39;out&amp;#39; button)</source>
        <translation>将秤重量添加到 Roasted Weight 字段（与 &amp;#39;out&amp;#39; 按钮相同的操作）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="95" />
        <source>⌘+P [Mac]
CTRL+P [Win]</source>
        <translation>⌘+P [Mac]
CTRL+P [Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="95" />
        <source>Clear accumulated scale weight preview display (same as clicking on the preview display)</source>
        <translation>清除累计秤重预览显示（与点击预览显示相同）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="97" />
        <location filename="../help/keyboardshortcuts_help.py" line="96" />
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="96" />
        <source>Roast Properties Roast Tab
Volume Calculator Unit, Green Unit  Weight or Roasted Unit Weight field</source>
        <translation>烘焙属性 烘焙选项卡
体积计算器单位、生豆单位重量或烘焙单位重量字段</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="96" />
        <source>Overwrite with current scale weight (same action as &amp;#39;unit&amp;#39;, &amp;#39;in&amp;#39;, &amp;#39;out&amp;#39; buttons)</source>
        <translation>用当前秤重覆盖（与 &amp;#39;unit&amp;#39;、&amp;#39;in&amp;#39;、&amp;#39;out&amp;#39; 按钮的操作相同）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="97" />
        <source>Roast Properties Roast tab
Green Weight  or Roasted Weight field</source>
        <translation>烘焙属性 烘焙选项卡
生豆重量或烘焙重量字段</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="97" />
        <source>Overwrite with current scale weight</source>
        <translation>用当前秤重覆盖</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="98" />
        <source>⌘+C [Mac]
CTRL+C [Win]</source>
        <translation>⌘+C [Mac]
CTRL+C [Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="98" />
        <source>Roast Properties Data tab</source>
        <translation>烘焙属性数据选项卡</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="98" />
        <source>Copy table</source>
        <translation>复制表</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="99" />
        <source>Click on Energy / CO2 result area</source>
        <translation>点击能源/二氧化碳结果区域</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="99" />
        <source>Roast Properties Energy tab</source>
        <translation>烘焙属性能源选项卡</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="99" />
        <source>Toggle &amp;#39;per kg green coffee&amp;#39; result for Batch or Roast</source>
        <translation>切换“每公斤生咖啡”批次或烘焙结果</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="100" />
        <source>OPTION click &amp;#39;Copy Table&amp;#39; Button [Mac]
ALT click &amp;#39;Copy Table&amp;#39; Button [Win]</source>
        <translation>选项点击'复制表格'按钮 [Mac]
ALT 点击'复制表格'按钮 [Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="100" />
        <source>Various</source>
        <translation>各种各样的</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="100" />
        <source>For various tables this copies the table in tabular form</source>
        <translation>对于各种表格，这会以表格形式复制表格</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="101" />
        <source>Click on Home Icon
While recording only</source>
        <translation>单击主页图标
仅录制时</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="101" />
        <source>Navigation Toolbar</source>
        <translation>导航工具栏</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="101" />
        <source>Toggle Zoom Follow (automatic panning)</source>
        <translation>切换缩放跟随（自动平移）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="101" />
        <source>Zoom action while recording sets Follow ON</source>
        <translation>录制时的变焦动作设置 Follow ON</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="104" />
        <location filename="../help/keyboardshortcuts_help.py" line="103" />
        <location filename="../help/keyboardshortcuts_help.py" line="102" />
        <source>Hold Shift+Option [Mac]
Hold Shift+Alt [Win]</source>
        <translation>按住 Shift+Option [Mac]
按住 Shift+Alt [Win]</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="102" />
        <source>When starting Artisan</source>
        <translation>开始工匠时</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="102" />
        <source>Skip Settings Load</source>
        <translation>跳过设置加载</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="103" />
        <source>When quitting Artisan</source>
        <translation>退出 Artisan 时</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="103" />
        <source>Skip Settings Save</source>
        <translation>跳过设置保存</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="104" />
        <source>When opening a profile (.alog file)</source>
        <translation>打开配置文件（.alog 文件）时</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="104" />
        <source>Skip creating settings cache and ask user to apply existing settings or settings from profile</source>
        <translation>跳过创建设置缓存并要求用户应用现有设置或配置文件中的设置</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="107" />
        <source>MENU SHORTCUTS</source>
        <translation>菜单快捷方式</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="110" />
        <source>Menu</source>
        <translation>菜单</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="114" />
        <location filename="../help/keyboardshortcuts_help.py" line="113" />
        <location filename="../help/keyboardshortcuts_help.py" line="112" />
        <location filename="../help/keyboardshortcuts_help.py" line="111" />
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="111" />
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="113" />
        <source>Save As...</source>
        <translation>保存为...</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="114" />
        <source>Print</source>
        <translation>打印</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="117" />
        <location filename="../help/keyboardshortcuts_help.py" line="116" />
        <location filename="../help/keyboardshortcuts_help.py" line="115" />
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="115" />
        <source>Cut</source>
        <translation>剪切</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="116" />
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="117" />
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="119" />
        <location filename="../help/keyboardshortcuts_help.py" line="118" />
        <source>Roast</source>
        <translation>烘焙</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="118" />
        <source>Open Roast Properties dialog</source>
        <translation>打开烘焙属性对话框</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="119" />
        <source>Open Profile Background dialog</source>
        <translation>打开配置文件背景对话框</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="120" />
        <source>Roast
(Expert and Standard modes)</source>
        <translation>烘焙
（专家和标准模式）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="120" />
        <source>Switch Profiles (Foreground&lt;=&gt;Background)</source>
        <translation>切换配置文件（前台&lt;=&gt;后台）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="122" />
        <location filename="../help/keyboardshortcuts_help.py" line="121" />
        <source>Config
(Expert mode)</source>
        <translation>配置
（专家模式）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="121" />
        <source>Open Devices dialog</source>
        <translation>打开设备对话框</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="122" />
        <source>Open Curves dialog</source>
        <translation>打开曲线对话框</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="125" />
        <location filename="../help/keyboardshortcuts_help.py" line="124" />
        <location filename="../help/keyboardshortcuts_help.py" line="123" />
        <source>Config
(Expert and Standard modes)</source>
        <translation>配置
专家和标准模式）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="123" />
        <source>Open Events dialog</source>
        <translation>打开事件对话框</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="124" />
        <source>Open Alarms dialog</source>
        <translation>打开警报对话框</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="125" />
        <source>Open Axes dialog</source>
        <translation>打开轴对话框</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="127" />
        <location filename="../help/keyboardshortcuts_help.py" line="126" />
        <source>Tools
(Expert mode)</source>
        <translation>工具
（专家模式）</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="126" />
        <source>Analyzer Auto All</source>
        <translation>分析仪自动全部</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="127" />
        <source>Analyzer Clear Results</source>
        <translation>分析仪清除结果</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="129" />
        <location filename="../help/keyboardshortcuts_help.py" line="128" />
        <source>View</source>
        <translation>查看</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="128" />
        <source>Show/Hide Large Main LCDs</source>
        <translation>显示/隐藏大型主 LCD</translation>
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="129" />
        <source>Toggle Full Screen Mode</source>
        <translation />
    </message>
    <message>
        <location filename="../help/keyboardshortcuts_help.py" line="130" />
        <source>Open QuickStart Guide in the system browser</source>
        <translation>在系统浏览器中打开快速入门指南</translation>
    </message>
    <message>
        <location filename="../help/transposer_help.py" line="14" />
        <source>TRANSPOSER</source>
        <translation>转置器</translation>
    </message>
    <message>
        <location filename="../help/transposer_help.py" line="18" />
        <source>The Transposer allows to map the current profile w.r.t. the time and temperature axis by setting targets time and temperature at major events like yellow point (DRY END) or first crack (FC START) or for time transformations also by target phases duration. Temperature transformation are only applied to the bean temperature (BT) curve while time transformations are applied to the whole profile.

Three different mapping methods are available to compute from the current profile and the given targets a resulting profile. The linear and quadratic mappings are continuous functions while the discrete option is defined stepwise between the given source/target pairs and extended at the borders

Pressing the "Apply" button applies the current computed mapping to the loaded profile for inspection. "Reset" returns to the original profile shape. Leaving the Transposer with "OK" applies the current mapping to the profile. Leaving the Transposer with "Cancel" returns to the unchanged initially loaded profile.</source>
        <translation>Transposer 允许映射当前配置文件 w.r.t。通过在黄点 (DRY END) 或第一次裂纹 (FC START) 等主要事件处设置目标时间和温度来设置时间和温度轴，或者也通过目标阶段持续时间设置时间转换。温度变换仅应用于豆温 (BT) 曲线，而时间变换应用于整个曲线。

三种不同的映射方法可用于从当前配置文件和给定目标计算结果配置文件。线性和二次映射是连续函数，而离散选项在给定的源/目标对之间逐步定义并在边界处扩展

按下“应用”按钮将当前计算的映射应用到加载的配置文件以进行检查。 “重置”返回到原始轮廓形状。使用“OK”离开 Transposer 会将当前映射应用到配置文件。使用“取消”离开转置器将返回到未更改的初始加载配置文件。</translation>
    </message>
    <message>
        <location filename="../help/transposer_help.py" line="21" />
        <source>EXAMPLE 1: ADJUST TOTAL ROAST TIME</source>
        <translation>示例 1：调整总烘焙时间</translation>
    </message>
    <message>
        <location filename="../help/transposer_help.py" line="25" />
        <source>You might want to re-roast a profile, but extended/restricted to a total length of 10:00. 

Load the profile and start the Transposer under Tools. Enter our target roast time of "10:00" minutes into the target DROP field under Time and select "linear" as mapping. Check the resulting times of the main events in the time tables last row, press "Apply" to view the transposed profile in the graph. If you are happy with the result, press "OK" and save the newly generated transposed profile such that you can use it as a template for future roasts.</source>
        <translation>您可能想要重新烘焙配置文件，但扩展/限制为 10:00 的总长度。

加载配置文件并在工具下启动转置器。在 Time 下的 target DROP 字段中输入我们的目标烘焙时间“10:00”分钟，然后选择“linear”作为映射。检查时间表最后一行中主要事件的结果时间，按“应用”以查看图表中的转置配置文件。如果您对结果满意，请按“确定”并保存新生成的转置配置文件，以便您可以将其用作未来烘焙的模板。</translation>
    </message>
    <message>
        <location filename="../help/transposer_help.py" line="28" />
        <source>EXAMPLE 2: MAP BETWEEN TWO ROASTING MACHINES</source>
        <translation>示例 2：两台烘焙机之间的映射</translation>
    </message>
    <message>
        <location filename="../help/transposer_help.py" line="32" />
        <source>Transpose temperature readings from your smaller machine to your larger machine assuming on your larger machine the DRY and FC START events happen at different temperatures than on your smaller one.

Load the profile recorded on the smaller machine and open the Transposer. Select the linear mapping and put the DRY and FC START target temperatures as observed on your larger machine into the into the corresponding fields under BT. Underneath the table you see the calculated symbolic formula that can be copy-pasted into the BT symbolic formula under Config &gt;&gt; Devices to adjust the computed mapping automatically while roasting on your smaller machine to see the temperature reading as you expect them on the larger machine.</source>
        <translation>假设大型机器上的 DRY 和 FC START 事件发生在与小型机器不同的温度下，则将较小机器上的温度读数转移到较大机器上。

加载在较小机器上记录的配置文件并打开 Transposer。选择线性映射并将在大型机器上观察到的 DRY 和 FC START 目标温度放入 BT 下的相应字段中。在表格下方，您会看到计算出的符号公式，可以将其复制粘贴到 Config &gt;&gt; Devices 下的 BT 符号公式中，以便在较小的机器上烘焙时自动调整计算的映射，以在较大的机器上查看您所期望的温度读数.</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="14" />
        <source>EVENT CUSTOM SLIDERS</source>
        <translation>活动定制滑块</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="21" />
        <location filename="../help/eventsliders_help.py" line="17" />
        <source>Column</source>
        <translation>列名</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="48" />
        <location filename="../help/eventsliders_help.py" line="18" />
        <source>Event</source>
        <translation>事件</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="18" />
        <source>Hide or show the corresponding slider.</source>
        <translation>隐藏或显示相应的滑块。</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="19" />
        <source>Perform an action on the slider release.</source>
        <translation>对滑块释放执行操作。</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="20" />
        <source>Command to perform, depends on the Action type. (&amp;#39;{}&amp;#39; is replaced by the slider value*Factor + Offset)</source>
        <translation>要执行的命令，取决于操作类型。 （&amp;#39;{}&amp;#39; 替换为滑块值*Factor + Offset）</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="21" />
        <source>Offset</source>
        <translation>补偿</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="21" />
        <source>Offset to be added to the Slider value (after scaling by Factor).</source>
        <translation>要添加到滑块值的偏移量（按因子缩放后）。</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="22" />
        <source>Factor</source>
        <translation>因子</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="22" />
        <source>Scale factor, Slider value is multiplied by this value.</source>
        <translation>比例因子，滑块值乘以该值。</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="23" />
        <source>Min</source>
        <translation>最小</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="23" />
        <source>Sets the minimum value for the range of the slider.</source>
        <translation>设置滑块范围的最小值。</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="24" />
        <source>Max</source>
        <translation>最大</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="24" />
        <source>Sets the maximum value for the range of the slider.</source>
        <translation>设置滑块范围的最大值。</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="25" />
        <source>Course</source>
        <translation>步长</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="25" />
        <source>When ticked the slider moves in steps of 10.</source>
        <translation>勾选后，滑块以 10 步移动。</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="26" />
        <source>Should be ticked when the slider&amp;#39;s value is a temperature to allow Artisan to properly scale the value between Centigrade and Fahrenheit.</source>
        <translation>当滑块的值是温度时应勾选以允许 Artisan 正确调整摄氏和华氏之间的值。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="46" />
        <location filename="../help/eventsliders_help.py" line="27" />
        <source>Unit</source>
        <translation>单位</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="27" />
        <source>Optional text used in annotations to the the units used for the slider value.</source>
        <translation>用于滑块值单位的注释中的可选文本。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="90" />
        <location filename="../help/eventsliders_help.py" line="30" />
        <source>COMMANDS</source>
        <translation>命令</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="34" />
        <source>Note: "{}" can be used as a placeholder, it will be substituted by (value*factor + offset). In all slider command actions, but for IO, VOUT, S7 and RC Commands, the bound value is converted from a float to an int.
</source>
        <translation>注意：“{}”可以用作占位符，它将被替换为（值*因子+偏移量）。在所有滑块命令操作中，除了 IO、VOUT、S7 和 RC 命令外，绑定值都会从浮点转换为整数。
</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="94" />
        <location filename="../help/eventsliders_help.py" line="34" />
        <source>Note: The placeholders {ET}, {BT}, {time}, {ETB}, {BTB}, and {WEIGHTin} will be substituted by the current ET, BT, time, ET background, BT background value, and batch size (in g) in Serial/Artisan/CallProgram/MODBUS/S7/WebSocket commands
</source>
        <translation>注意：占位符 {ET}、{BT}、{time}、{ETB}、{BTB} 和 {WEIGHTin} 将替换为 Serial/Artisan/CallProgram/MODBUS/S7/WebSocket 命令中的当前 ET、BT、时间、ET 背景、BT 背景值和批次大小（以克为单位）
</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="34" />
        <source>Note: commands can be sequenced, separated by semicolons like in “&lt;cmd1&gt;;&lt;cmd2&gt;;&lt;cmd3&gt;”
</source>
        <translation>注意：命令可以排序，用分号分隔，如“&lt;cmd1&gt;;&lt;cmd2&gt;;&lt;cmd3&gt;”
</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="34" />
        <source>Note: in PHIDGET commands, the optional parameter &lt;sn&gt; has the form &lt;hub_serial&gt;[:&lt;hub_port&gt;] allows to refer to a specific Phidget HUB by given its serial number, and optionally specifying the port number the addressed module is connected to.
</source>
        <translation>注意：在 PHIDGET 命令中，可选参数 &lt;sn&gt; 的形式为 &lt;hub_serial&gt;[:&lt;hub_port&gt;] 允许通过给定的序列号来引用特定的 Phidget HUB，并可选择指定寻址模块连接到的端口号.
</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="34" />
        <source>Note: in YOCTOPUCE commands, the optional parameters &lt;sn&gt; holds either the modules serial number or its name</source>
        <translation>注意：在 YOCTOPUCE 命令中，可选参数 &lt;sn&gt; 包含模块序列号或其名称</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="98" />
        <location filename="../help/eventsliders_help.py" line="38" />
        <source>Serial Command</source>
        <translation>串行指令</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="98" />
        <location filename="../help/eventsliders_help.py" line="38" />
        <source>ASCII serial command or binary a2b_uu(serial command)</source>
        <translation>ASCII 串行命令或二进制 a2b_uu（串行命令）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="101" />
        <location filename="../help/eventsliders_help.py" line="39" />
        <source>Modbus Command</source>
        <translation>通信协议指令</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="101" />
        <location filename="../help/eventsliders_help.py" line="39" />
        <source>variable holding the last value read via MODBUS</source>
        <translation>保存通过 MODBUS 读取的最后一个值的变量</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="252" />
        <location filename="../help/eventbuttons_help.py" line="191" />
        <location filename="../help/eventbuttons_help.py" line="171" />
        <location filename="../help/eventbuttons_help.py" line="168" />
        <location filename="../help/eventbuttons_help.py" line="144" />
        <location filename="../help/eventbuttons_help.py" line="103" />
        <location filename="../help/eventsliders_help.py" line="175" />
        <location filename="../help/eventsliders_help.py" line="118" />
        <location filename="../help/eventsliders_help.py" line="103" />
        <location filename="../help/eventsliders_help.py" line="98" />
        <location filename="../help/eventsliders_help.py" line="79" />
        <location filename="../help/eventsliders_help.py" line="40" />
        <source>sleep: add a delay of &lt;float&gt; seconds</source>
        <translation>sleep：添加 &lt;float&gt; 秒的延迟</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="173" />
        <location filename="../help/eventbuttons_help.py" line="105" />
        <location filename="../help/eventsliders_help.py" line="41" />
        <source>sets calling button to “pressed” if argument is 1 or True</source>
        <translation>如果参数为 1 或 True，则将调用按钮设置为“按下”</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="42" />
        <source>reads register from device deviceID using function 3 (Read Multiple Holding Registers). The result is bound to the placeholder `_` and thus can be accessed in later commands.</source>
        <translation>使用函数 3（读取多个保持寄存器）从设备 deviceID 读取寄存器。结果绑定到占位符“_”，以便后续命令可以访问。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="108" />
        <location filename="../help/eventsliders_help.py" line="43" />
        <source>reads 1 16bit register from device deviceID using function 3 (Read Multiple Holding Registers) interpreted as signed integer. The result is bound to the placeholder `_` and thus can be accessed in later commands.</source>
        <translation>使用函数 3（读取多个保持寄存器）从设备 deviceID 读取 1 个 16 位寄存器，并将其解析为有符号整数。结果绑定到占位符“_”，以便后续命令中访问。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="109" />
        <location filename="../help/eventsliders_help.py" line="44" />
        <source>reads 1 16bit register from device deviceID using function 3 (Read Multiple Holding Registers) interpreted as BCD. The result is bound to the placeholder `_` and thus can be accessed in later commands.</source>
        <translation>使用函数 3（读取多个保持寄存器）从设备 deviceID 读取 1 个 16 位寄存器，并将其解析为 BCD 码。结果绑定到占位符“_”，以便后续命令中访问。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="110" />
        <location filename="../help/eventsliders_help.py" line="45" />
        <source>reads 2 16bit registers from device deviceID using function 3 (Read Multiple Holding Registers) interpreted as unsigned integer. The result is bound to the placeholder `_` and thus can be accessed in later commands.</source>
        <translation>使用函数 3（读取多个保持寄存器）从设备 deviceID 读取 2 个 16 位寄存器，并将其解析为无符号整数。结果绑定到占位符“_”，以便后续命令中访问。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="111" />
        <location filename="../help/eventsliders_help.py" line="46" />
        <source>reads 2 16bit registers from device deviceID using function 3 (Read Multiple Holding Registers) interpreted as signed integer. The result is bound to the placeholder `_` and thus can be accessed in later commands.</source>
        <translation>使用函数 3（读取多个保持寄存器）从设备 deviceID 读取 2 个 16 位寄存器，并将其解析为有符号整数。结果绑定到占位符“_”，以便后续命令中访问。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="112" />
        <location filename="../help/eventsliders_help.py" line="47" />
        <source>reads 2 16bit register from device deviceID using function 3 (Read Multiple Holding Registers) interpreted as BCD. The result is bound to the placeholder `_` and thus can be accessed in later commands.</source>
        <translation>使用函数 3（读取多个保持寄存器）从设备 deviceID 读取 2 个 16 位寄存器，并将其解析为 BCD 码。结果绑定到占位符“_”，以便后续命令中访问。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="113" />
        <location filename="../help/eventsliders_help.py" line="48" />
        <source>reads 2 16bit registers from device deviceID using function 3 (Read Multiple Holding Registers) interpreted as float. The result is bound to the placeholder `_` and thus can be accessed in later commands.</source>
        <translation>使用函数 3（读取多个保持寄存器）从设备 deviceID 读取 2 个 16 位寄存器，并将其解析为浮点数。结果绑定到占位符“_”，以便后续命令中访问。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="114" />
        <location filename="../help/eventsliders_help.py" line="49" />
        <source>DEPRECATED: use writeSingle for MODBUS function 6 (int) or writeWord for function 16 (float)</source>
        <translation>已弃用：使用 writeSingle 作为 MODBUS 功能 6（int）或使用 writeWord 作为功能 16（float）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="115" />
        <location filename="../help/eventsliders_help.py" line="50" />
        <source>write coil: MODBUS function 5</source>
        <translation>写线圈：MODBUS功能5</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="116" />
        <location filename="../help/eventsliders_help.py" line="51" />
        <source>write coils: MODBUS function 15</source>
        <translation>写线圈：MODBUS 功能 15</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="52" />
        <source> </source>
        <translation />
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="117" />
        <location filename="../help/eventsliders_help.py" line="52" />
        <source>mask write register: MODBUS function 22 or simulates function 22 with function 6 and the given value value</source>
        <translation>屏蔽写寄存器：MODBUS功能22或者用功能6和给定值模拟功能22</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="118" />
        <location filename="../help/eventsliders_help.py" line="53" />
        <source>write registers: MODBUS function 16</source>
        <translation>写寄存器：MODBUS功能16</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="54" />
        <source>write 16bit BCD encoded value to register of device with deviceID </source>
        <translation>将 16 位 BCD 编码值写入具有设备 ID 的设备寄存器</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="120" />
        <location filename="../help/eventsliders_help.py" line="55" />
        <source>write 32bit float to two 16bit int registers: MODBUS function 16</source>
        <translation>将 32 位浮点数写入两个 16 位整数寄存器：MODBUS 函数 16</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="121" />
        <location filename="../help/eventsliders_help.py" line="56" />
        <source>write 32bit integer to two 16bit int registers: MODBUS function 16</source>
        <translation>将 32 位整数写入两个 16 位 int 寄存器：MODBUS 函数 16</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="122" />
        <location filename="../help/eventsliders_help.py" line="57" />
        <source>write 16bit integer to a single 16bit register: MODBUS function 6 (int)</source>
        <translation>将 16 位整数写入单个 16 位寄存器：MODBUS 函数 6 (int)</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="123" />
        <location filename="../help/eventsliders_help.py" line="58" />
        <source>DTA Command</source>
        <translation>DTA 指令</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="58" />
        <source>Insert Data address : value, ex. 4701:1000 and sv is 100. </source>
        <translation>插入数据地址：值，例如。 4701:1000 并且 sv 是 100. </translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="58" />
        <source>Always multiply with 10 if value Unit: 0.1 / ex. 4719:0 stops heating</source>
        <translation>如果值单位：0.1 / ex. 总是乘以 10。 4719:0 停止加热</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="59" />
        <source>start and external program</source>
        <translation>启动和外部程序</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="148" />
        <location filename="../help/eventsliders_help.py" line="60" />
        <source>Hottop Heater</source>
        <translation>Hottop加热器</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="182" />
        <location filename="../help/eventbuttons_help.py" line="148" />
        <location filename="../help/eventsliders_help.py" line="111" />
        <location filename="../help/eventsliders_help.py" line="60" />
        <source>sets heater to value</source>
        <translation>将加热器设置为值</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="149" />
        <location filename="../help/eventsliders_help.py" line="61" />
        <source>Hottop Fan</source>
        <translation>Hottop风机</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="183" />
        <location filename="../help/eventbuttons_help.py" line="149" />
        <location filename="../help/eventsliders_help.py" line="112" />
        <location filename="../help/eventsliders_help.py" line="61" />
        <source>sets fan to value</source>
        <translation>设定风机到值</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="150" />
        <location filename="../help/eventsliders_help.py" line="62" />
        <source>Hottop Command</source>
        <translation>Hottop指令</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="150" />
        <location filename="../help/eventsliders_help.py" line="62" />
        <source>with n={0 ,1},h={0,..100},f={0,..10}</source>
        <translation>n={0 ,1},h={0,..100},f={0,..10}</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="152" />
        <location filename="../help/eventsliders_help.py" line="63" />
        <source>Fuji Command</source>
        <translation>Fuji指令</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="153" />
        <location filename="../help/eventsliders_help.py" line="64" />
        <source>PWM Command</source>
        <translation>PWM指令</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="153" />
        <location filename="../help/eventsliders_help.py" line="64" />
        <source>PHIDGET PWM Output: &lt;value&gt; in [0-100]</source>
        <translation>PHIDGET PWM 输出：&lt;值&gt; in [0-100]</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="154" />
        <location filename="../help/eventsliders_help.py" line="65" />
        <source>PHIDGET PWM Frequency: &lt;value&gt; in Hz</source>
        <translation>PHIDGET PWM 频率：&lt;值&gt;（单位：Hz）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="155" />
        <location filename="../help/eventsliders_help.py" line="66" />
        <source>PHIDGET PWM Output: toggles &lt;channel&gt;</source>
        <translation>PHIDGET PWM 输出：切换 &lt;通道&gt;</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="156" />
        <location filename="../help/eventsliders_help.py" line="67" />
        <source>PHIDGET PWM Output: turn &lt;channel&gt; on for &lt;millis&gt; milliseconds</source>
        <translation>PHIDGET PWM 输出：开启 &lt;channel&gt; 持续 &lt;millis&gt; 毫秒</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="68" />
        <source>PHIDGET HUB PWM Output: &lt;value&gt; in [0-100]</source>
        <translation>PHIDGET HUB PWM 输出：&lt;value&gt; in [0-100]</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="69" />
        <source>PHIDGET HUB PWM Output: toggles &lt;channel&gt;</source>
        <translation>PHIDGET HUB PWM 输出：切换 &lt;channel&gt;</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="70" />
        <source>PHIDGET HUB PWM Output:  turn &lt;channel&gt; on for &lt;millis&gt; milliseconds</source>
        <translation>PHIDGET HUB PWM 输出：开启 &lt;channel&gt; 持续 &lt;millis&gt; 毫秒</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="160" />
        <location filename="../help/eventsliders_help.py" line="71" />
        <source>YOCTOPUCE PWM Output: PWM running state</source>
        <translation>YOCTOPUCE PWM输出：PWM运行状态</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="161" />
        <location filename="../help/eventsliders_help.py" line="72" />
        <source>YOCTOPUCE PWM Output: set PWM frequency to f (Hz)</source>
        <translation>YOCTOPUCE PWM 输出：将 PWM 频率设置为 f (Hz)</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="162" />
        <location filename="../help/eventsliders_help.py" line="73" />
        <source>YOCTOPUCE PWM Output: set PWM period with the duty cycle in % as a float [0.0-100.0]</source>
        <translation>YOCTOPUCE PWM 输出：设置 PWM 周期，以 % 为单位的占空比为浮点数 [0.0-100.0]</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="163" />
        <location filename="../help/eventsliders_help.py" line="74" />
        <source>YOCTOPUCE PWM Output: changes progressively the PWM to the specified value over the given time interval</source>
        <translation>YOCTOPUCE PWM 输出：在给定的时间间隔内逐渐将 PWM 更改为指定值</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="164" />
        <location filename="../help/eventsliders_help.py" line="75" />
        <source>VOUT Command</source>
        <translation>VOUT指令</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="75" />
        <source>for PHIDGET OUTPUT modules: sets voltage voltage range (r=5 for r5V and r=10 for 10V)</source>
        <translation>对于 PHIDGET OUTPUT 模块：设置电压电压范围（r5V 时 r=5，10V 时 r=10）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="165" />
        <location filename="../help/eventsliders_help.py" line="76" />
        <source>for PHIDGET OUTPUT modules: set analog output channel n to output voltage value v in V (eg. 5.5 for 5.5V)</source>
        <translation>对于 PHIDGET OUTPUT 模块：将模拟输出通道 n 设置为以 V 为单位的输出电压值 v（例如 5.5 表示 5.5V）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="166" />
        <location filename="../help/eventsliders_help.py" line="77" />
        <source>for YOCTOPUCE VOLTAGE OUT modules with c the channel (1 or 2),v the voltage as float [0.0-10.0]</source>
        <translation>对于带有 c 通道（1 或 2）的 YOCTOPUCE VOLTAGE OUT 模块，v 电压为浮动 [0.0-10.0]</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="167" />
        <location filename="../help/eventsliders_help.py" line="78" />
        <source>for YOCTOPUCE CURRENT OUT modules with c the current as float [3.0-21.0]</source>
        <translation>对于 YOCTOPUCE CURRENT OUT 模块，c 电流为浮点 [3.0-21.0]</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="124" />
        <location filename="../help/eventsliders_help.py" line="80" />
        <source>IO Command</source>
        <translation>IO指令</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="126" />
        <location filename="../help/eventsliders_help.py" line="80" />
        <source>PHIDGET Binary Output: switches channel c off (b=0) and on (b=1)</source>
        <translation>PHIDGET 二进制输出：关闭（b=0）和打开（b=1）通道 c</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="127" />
        <location filename="../help/eventsliders_help.py" line="81" />
        <source>PHIDGET Binary Output: toggles channel c</source>
        <translation>PHIDGET 二进制输出：切换通道 c</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="128" />
        <location filename="../help/eventsliders_help.py" line="82" />
        <source>PHIDGET Binary Output: sets the output of channel c to on for time t in milliseconds</source>
        <translation>PHIDGET 二进制输出：将通道 c 的输出设置为开启时间 t，以毫秒为单位</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="129" />
        <location filename="../help/eventsliders_help.py" line="83" />
        <source>PHIDGET Voltage Output: sets voltage output of channel c to v (float)</source>
        <translation>PHIDGET 电压输出：将通道 c 的电压输出设置为 v（浮点）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="130" />
        <location filename="../help/eventsliders_help.py" line="84" />
        <source>PHIDGET DCMotor: sets acceleration of channel c to v (float)</source>
        <translation>PHIDGET DCMotor：将通道 c 的加速度设置为 v（浮点数）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="131" />
        <location filename="../help/eventsliders_help.py" line="85" />
        <source>PHIDGET DCMotor: sets target velocity of channel c to v (float)</source>
        <translation>PHIDGET DCMotor：将通道 c 的目标速度设置为 v (float)</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="132" />
        <location filename="../help/eventsliders_help.py" line="86" />
        <source>PHIDGET DCMotor: sets current limit of channel c to v (float)</source>
        <translation>PHIDGET DCMotor：将通道 c 的电流限制设置为 v（浮点）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="133" />
        <location filename="../help/eventsliders_help.py" line="87" />
        <source>YOCTOPUCE Relay Output: turn channel c of the relay module on</source>
        <translation>YOCTOPUCE 继电器输出：打开继电器模块的通道 c</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="134" />
        <location filename="../help/eventsliders_help.py" line="88" />
        <source>YOCTOPUCE Relay Output: turn channel c of the relay module off</source>
        <translation>YOCTOPUCE继电器输出：关闭继电器模块的通道c</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="135" />
        <location filename="../help/eventsliders_help.py" line="89" />
        <source>YOCTOPUCE Relay Output: switches channel c of the relay module off (b=0) and on (b=1)</source>
        <translation>YOCTOPUCE 继电器输出：关闭（b=0）和打开（b=1）继电器模块的通道 c</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="136" />
        <location filename="../help/eventsliders_help.py" line="90" />
        <source>YOCTOPUCE Relay Output: toggle the state of channel c</source>
        <translation>YOCTOPUCE 继电器输出：切换通道 c 的状态</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="137" />
        <location filename="../help/eventsliders_help.py" line="91" />
        <source>YOCTOPUCE Relay Output: pulse the channel c on after a delay of delay milliseconds for the duration of duration milliseconds</source>
        <translation>YOCTOPUCE 继电器输出：在 delay 毫秒的延迟后将通道 c 脉冲到 duration 毫秒的持续时间</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="138" />
        <location filename="../help/eventsliders_help.py" line="92" />
        <source>YOCTOPUCE resets the power counter of the Yocto-Watt module</source>
        <translation>YOCTOPUCE 重置 Yocto-Watt 模块的功率计数器</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="139" />
        <location filename="../help/eventsliders_help.py" line="93" />
        <source>move slider c to value v</source>
        <translation>将滑块 c 移动到值 v</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="140" />
        <location filename="../help/eventsliders_help.py" line="94" />
        <source>switches PHIDGET Binary Output channel c off (b=0) and on (b=1) and sets button i to pressed or normal depending on the value b</source>
        <translation>关闭 (b=0) 和打开 (b=1) PHIDGET 二进制输出通道 c 并根据值 b 将按钮 i 设置为按下或正常</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="253" />
        <location filename="../help/eventbuttons_help.py" line="172" />
        <location filename="../help/eventbuttons_help.py" line="141" />
        <location filename="../help/eventbuttons_help.py" line="104" />
        <location filename="../help/eventsliders_help.py" line="95" />
        <source>sets button i to pressed if value b is yes, true, t, or 1, otherwise to normal</source>
        <translation>如果值 b 为 yes、true、t 或 1，则将按钮 i 设置为按下，否则设置为正常</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="142" />
        <location filename="../help/eventsliders_help.py" line="96" />
        <source>sets button to pressed if value b is yes, true, t, or 1, otherwise to normal</source>
        <translation>如果值 b 为 yes、true、t 或 1，则将按钮设置为按下，否则设置为正常</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="255" />
        <location filename="../help/eventbuttons_help.py" line="214" />
        <location filename="../help/eventbuttons_help.py" line="174" />
        <location filename="../help/eventbuttons_help.py" line="143" />
        <location filename="../help/eventbuttons_help.py" line="106" />
        <location filename="../help/eventsliders_help.py" line="97" />
        <source>toggles the state of the button</source>
        <translation>切换按钮的状态</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="145" />
        <location filename="../help/eventsliders_help.py" line="99" />
        <source>sends integer &lt;value&gt; to &lt;target&gt; register specified by as byte in hex notation like “fa” via the Santoker Network protocol</source>
        <translation>通过 Santoker 网络协议将整数 &lt;value&gt; 发送到 &lt;target&gt; 寄存器，该寄存器由 as byte 以十六进制表示法（如“fa”）指定</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="146" />
        <location filename="../help/eventsliders_help.py" line="100" />
        <source>sends &lt;value&gt; to &lt;target&gt; via the Kaleido Serial or Network protocol</source>
        <translation>通过 Kaleido 串行或网络协议将 &lt;value&gt; 发送到 &lt;target&gt;</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="147" />
        <location filename="../help/eventsliders_help.py" line="101" />
        <source>switches Shelly plug number &lt;n&gt; ON if b is true or 1, and OFF otherwise</source>
        <translation>如果 b 为真或 1，则将 Shelly 插头编号 &lt;n&gt; 切换为 ON，否则切换为 OFF</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="169" />
        <location filename="../help/eventsliders_help.py" line="102" />
        <source>S7 Command</source>
        <translation>S7指令</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="169" />
        <location filename="../help/eventsliders_help.py" line="102" />
        <source>variable holding the last value read via S7</source>
        <translation>保存通过 S7 读取的最后一个值的变量</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="254" />
        <location filename="../help/eventsliders_help.py" line="176" />
        <location filename="../help/eventsliders_help.py" line="104" />
        <source>sets calling button to “pressed” if argument evaluates to 1 or True</source>
        <translation>如果参数评估为 1 或 True，则将调用按钮设置为“按下”</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="175" />
        <location filename="../help/eventsliders_help.py" line="105" />
        <source>read bool from S7 DB</source>
        <translation>从 S7 DB 中读取布尔值</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="176" />
        <location filename="../help/eventsliders_help.py" line="106" />
        <source>read int from S7 DB</source>
        <translation>从 S7 DB 中读取 int</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="177" />
        <location filename="../help/eventsliders_help.py" line="107" />
        <source>read float from S7 DB</source>
        <translation>从 S7 DB 读取浮点数</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="178" />
        <location filename="../help/eventsliders_help.py" line="108" />
        <source>write bool to S7 DB</source>
        <translation>将布尔值写入 S7 DB</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="179" />
        <location filename="../help/eventsliders_help.py" line="109" />
        <source>write int to S7 DB</source>
        <translation>将 int 写入 S7 DB</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="181" />
        <location filename="../help/eventsliders_help.py" line="110" />
        <source>write float to S7 DB</source>
        <translation>将浮点数写入 S7 DB</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="182" />
        <location filename="../help/eventsliders_help.py" line="111" />
        <source>Aillio R1 Heater</source>
        <translation>Aillio R1加热器</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="183" />
        <location filename="../help/eventsliders_help.py" line="112" />
        <source>Aillio R1 Fan</source>
        <translation>Aillio R1风机</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="184" />
        <location filename="../help/eventsliders_help.py" line="113" />
        <source>Aillio R1 Drum</source>
        <translation>Aillio R1滚筒</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="184" />
        <location filename="../help/eventsliders_help.py" line="113" />
        <source>sets drum speed to value</source>
        <translation>将滚筒速度设置为值</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="186" />
        <location filename="../help/eventsliders_help.py" line="114" />
        <source>Artisan Command</source>
        <translation>Artisan指令</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="188" />
        <location filename="../help/eventsliders_help.py" line="114" />
        <source>enables/disables alarms</source>
        <translation>启用/禁用警报</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="187" />
        <location filename="../help/eventsliders_help.py" line="115" />
        <source>enables/disables alarm number n</source>
        <translation>启用/禁用警报号 n</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="189" />
        <location filename="../help/eventsliders_help.py" line="116" />
        <source>enables/disables autoCHARGE</source>
        <translation>启用/禁用自动充电</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="190" />
        <location filename="../help/eventsliders_help.py" line="117" />
        <source>enables/disables autoDROP</source>
        <translation>启用/禁用 autoDROP</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="192" />
        <location filename="../help/eventsliders_help.py" line="119" />
        <source>tare channel &lt;int&gt; with 1 =&gt; ET, 2 =&gt; BT, 3 =&gt; E1c1, 4: E1c2,..</source>
        <translation>使用 1 =&gt; ET, 2 =&gt; BT, 3 =&gt; E1c1, 4: E1c2,.. 去皮通道 &lt;int&gt;,..</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="193" />
        <location filename="../help/eventsliders_help.py" line="120" />
        <source>turns PID on</source>
        <translation>打开PID</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="194" />
        <location filename="../help/eventsliders_help.py" line="121" />
        <source>turns PID off</source>
        <translation>关闭 PID</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="195" />
        <location filename="../help/eventsliders_help.py" line="122" />
        <source>toggles the PID state</source>
        <translation>切换 PID 状态</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="196" />
        <location filename="../help/eventsliders_help.py" line="123" />
        <source>sets PID mode to 0: manual, 1: RS, 2: background follow</source>
        <translation>设置PID模式为0：手动，1：RS，2：后台跟随</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="197" />
        <location filename="../help/eventsliders_help.py" line="124" />
        <source>sets the p-i-d parameters of the PID</source>
        <translation>设置 PID 的 p-i-d 参数</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="198" />
        <location filename="../help/eventsliders_help.py" line="125" />
        <source>sets the beta and gamma parameters of the PID</source>
        <translation>设置PID的beta和gamma参数</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="199" />
        <location filename="../help/eventsliders_help.py" line="126" />
        <source>increases or decreases the current target SV value by &lt;float&gt;</source>
        <translation>将当前目标 SV 值增加或减少 &lt;float&gt;</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="200" />
        <location filename="../help/eventsliders_help.py" line="127" />
        <source>sets the PID target set value SV</source>
        <translation>设定 PID 目标设定值 SV</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="201" />
        <location filename="../help/eventsliders_help.py" line="128" />
        <source>sets the PID target set value SV given in C</source>
        <translation>设置C中给定的PID目标设定值SV</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="202" />
        <location filename="../help/eventsliders_help.py" line="129" />
        <source>activates the PID Ramp-Soak pattern number &lt;rs&gt; (1-based!) or the one labeled &lt;rs&gt;</source>
        <translation>激活PID 缓升-恒温 程式编码&lt;rs&gt; (1-based!) or the one labeled &lt;rs&gt;</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="203" />
        <location filename="../help/eventsliders_help.py" line="130" />
        <source>selects the PID input source with &lt;n&gt; 0: BT, 1: ET (Software PID); &lt;n&gt; in {0,..,3} (Arduino PID)</source>
        <translation>用 &lt;n&gt; 选择 PID 输入源 0：BT，1：ET（软件 PID）； &lt;n&gt; 在 {0,..,3} (Arduino PID)</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="204" />
        <location filename="../help/eventsliders_help.py" line="131" />
        <source>sets the PID lookahead in seconds</source>
        <translation>以秒为单位设置 PID 前瞻</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="205" />
        <location filename="../help/eventsliders_help.py" line="132" />
        <source>sets the Ramping Event Replay lookahead in seconds</source>
        <translation>以秒为单位设置斜坡事件重播前瞻</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="206" />
        <location filename="../help/eventsliders_help.py" line="133" />
        <source>shows popup with message &lt;msg&gt; which optionally automatically closes after &lt;int&gt; seconds</source>
        <translation>显示带有消息 &lt;msg&gt; 的弹出窗口，该消息可选择在 &lt;int&gt; 秒后自动关闭</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="207" />
        <location filename="../help/eventsliders_help.py" line="134" />
        <source>shows message &lt;msg&gt; in the message line</source>
        <translation>在消息行中显示消息 &lt;msg&gt;</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="208" />
        <location filename="../help/eventsliders_help.py" line="135" />
        <source>enables/disables notifications; while disabled issued notifications are ignored</source>
        <translation>启用/禁用通知；虽然禁用发出的通知被忽略</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="209" />
        <location filename="../help/eventsliders_help.py" line="136" />
        <source>sends notification with title &lt;title&gt; and optional message &lt;msg&gt;</source>
        <translation>发送带有标题 &lt;title&gt; 和可选消息 &lt;msg&gt; 的通知</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="210" />
        <location filename="../help/eventsliders_help.py" line="137" />
        <source>sets canvas color to the RGB-hex &lt;color&gt; like #27f1d3</source>
        <translation>将画布颜色设置为 RGB-hex &lt;color&gt; 像 #27f1d3</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="211" />
        <location filename="../help/eventsliders_help.py" line="138" />
        <source>resets canvas color</source>
        <translation>重置画布颜色</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="139" />
        <source>activates button &lt;name&gt; from { START, CHARGE, DRY, FCs, FCe, SCs, SCe, DROP, COOL, OFF } </source>
        <translation>从 { START, CHARGE, DRY, FCs, FCe, SCs, SCe, DROP, COOL, OFF } 激活按钮 &lt;名称&gt; </translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="216" />
        <location filename="../help/eventsliders_help.py" line="140" />
        <source>activates palette &lt;p&gt; with &lt;p&gt; either a number 0-9 or a palette label</source>
        <translation>使用 &lt;p&gt; 数字 0-9 或调色板标签激活调色板 &lt;p&gt;</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="217" />
        <location filename="../help/eventsliders_help.py" line="141" />
        <source>sets playback mode to 0: off, 1: time, 2: BT, 3: ET; 4: BT/time; 5: ET/time</source>
        <translation>播放模式设置为：0：关闭；1：时间；2：蓝牙；3：ET；4：蓝牙/时间；5：ET/时间</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="218" />
        <location filename="../help/eventsliders_help.py" line="142" />
        <source>sets playback DROP mode to 0: off, 1: time, 2: BT, 3: ET</source>
        <translation>将播放 DROP 模式设置为 0：关闭、1：时间、2：BT、3：ET</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="219" />
        <location filename="../help/eventsliders_help.py" line="143" />
        <source>toggles playback per event type n from {1,2,3,4}</source>
        <translation>切换每个事件类型 n 的播放，范围为 {1,2,3,4}</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="220" />
        <location filename="../help/eventsliders_help.py" line="144" />
        <source>toggles playback ramping per event type n from {1,2,3,4}</source>
        <translation>根据事件类型 n 切换播放渐变（从 {1,2,3,4} 开始）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="221" />
        <location filename="../help/eventsliders_help.py" line="145" />
        <source>show/hide slider per event type n from {1,2,3,4}; n=5 toggles the PID SV slider visibility</source>
        <translation>显示/隐藏每个事件类型 n 的滑块（来自 {1,2,3,4}; n=5 可切换 PID SV 滑块的可见性</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="222" />
        <location filename="../help/eventsliders_help.py" line="146" />
        <source>activate/deactivate quantification per event type n from {1,2,3,4}</source>
        <translation>激活/停用每个事件类型 n 的量化（从 {1,2,3,4} 开始）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="223" />
        <location filename="../help/eventsliders_help.py" line="147" />
        <source>set the batch size to the given value. If the value is negative, the batch size is taken from the background profile, if any is loaded</source>
        <translation>将批处理大小设置为给定值。如果值为负数，则批处理大小取自背景配置文件（如果已加载）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="224" />
        <location filename="../help/eventsliders_help.py" line="148" />
        <source>opens the Roast Properties dialog</source>
        <translation>打开烘焙属性对话框</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="225" />
        <location filename="../help/eventsliders_help.py" line="149" />
        <source>loads the .alog profile at the given filepath as background profile</source>
        <translation>在给定的文件路径中加载 .alog 配置文件作为后台配置文件</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="226" />
        <location filename="../help/eventsliders_help.py" line="150" />
        <source>clears the current background profile</source>
        <translation>清除当前背景配置文件</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="227" />
        <location filename="../help/eventsliders_help.py" line="151" />
        <source>activates the alarmset with the given number or label</source>
        <translation>使用给定的数字或标签激活警报集</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="228" />
        <location filename="../help/eventsliders_help.py" line="152" />
        <source>moves the background profile the indicated number of steps towards &lt;direction&gt;, with &lt;direction&gt; one of up, down, left, right</source>
        <translation>将背景配置文件向 &lt;direction&gt; 移动指示的步数，&lt;direction&gt; 为上、下、左、右之一</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="229" />
        <location filename="../help/eventsliders_help.py" line="153" />
        <source>enables/disables keyboard mode</source>
        <translation>启用/禁用键盘模式</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="230" />
        <location filename="../help/eventsliders_help.py" line="154" />
        <source>enables/disables the Keep ON flag</source>
        <translation>启用/禁用 Keep ON 标志</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="231" />
        <location filename="../help/eventsliders_help.py" line="155" />
        <source>shows/hides the curve indicated by &lt;name&gt; which is one of { ET, BT, DeltaET, DeltaBT, BackgroundET, BackgroundBT}</source>
        <translation>显示/隐藏 &lt;name&gt; 指示的曲线，该曲线是 { ET, BT, DeltaET, DeltaBT, BackgroundET, BackgroundBT} 之一</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="232" />
        <location filename="../help/eventsliders_help.py" line="156" />
        <source>shows/hides the &lt;curve&gt; (one of {T1,T2}) of the zero-based &lt;extra_device&gt; number</source>
        <translation>显示/隐藏从零开始的 &lt;extra_device&gt; 数字的 &lt;curve&gt;（{T1,T2} 之一）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="233" />
        <location filename="../help/eventsliders_help.py" line="157" />
        <source>shows/hides the events of &lt;event_type&gt; in [1,..,5]</source>
        <translation>显示/隐藏 [1,..,5] 中 &lt;event_type&gt; 的事件</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="234" />
        <location filename="../help/eventsliders_help.py" line="158" />
        <source>shows/hides the events of the background profile</source>
        <translation>显示/隐藏背景配置文件的事件</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="235" />
        <location filename="../help/eventsliders_help.py" line="159" />
        <source>RC Command</source>
        <translation>RC指令</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="235" />
        <location filename="../help/eventsliders_help.py" line="159" />
        <source>for PHIDGET RC modules: sets the min/max pulse width in microseconds</source>
        <translation>对于 PHIDGET RC 模块：以微秒为单位设置最小/最大脉冲宽度</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="236" />
        <location filename="../help/eventsliders_help.py" line="160" />
        <source>for PHIDGET RC modules: sets the min/max position</source>
        <translation>对于 PHIDGET RC 模块：设置最小/最大位置</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="237" />
        <location filename="../help/eventsliders_help.py" line="161" />
        <source>for PHIDGET RC modules: engage (b=1) or disengage (b = 0)</source>
        <translation>对于 PHIDGET RC 模块：接合 (b=1) 或脱离 (b = 0)</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="238" />
        <location filename="../help/eventsliders_help.py" line="162" />
        <source>for PHIDGET RC modules: activates or deactivates the speed ramping state</source>
        <translation>对于 PHIDGET RC 模块：激活或禁用速度斜坡状态</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="239" />
        <location filename="../help/eventsliders_help.py" line="163" />
        <source>for PHIDGET RC modules: set the voltage to one of 5, 6 or 7.4 in Volt</source>
        <translation>对于 PHIDGET RC 模块：将电压设置为 5、6 或 7.4 in Volt 之一</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="240" />
        <location filename="../help/eventsliders_help.py" line="164" />
        <source>for PHIDGET RC modules: set the acceleration</source>
        <translation>对于 PHIDGET RC 模块：设置加速度</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="241" />
        <location filename="../help/eventsliders_help.py" line="165" />
        <source>for PHIDGET RC modules: set the velocity</source>
        <translation>对于 PHIDGET RC 模块：设置速度</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="242" />
        <location filename="../help/eventsliders_help.py" line="166" />
        <source>for PHIDGET RC modules: set the target position</source>
        <translation>对于 PHIDGET RC 模块：设置目标位置</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="243" />
        <location filename="../help/eventsliders_help.py" line="167" />
        <source>for YOCTOPUCE RC modules: with c:int the channel, b a bool (eg. enabled(0,1) or enabled(0,True))</source>
        <translation>对于 YOCTOPUCE RC 模块：使用 c:int 通道，b a bool（例如启用（0,1）或启用（0,True））</translation>
    </message>
    <message>
        <location filename="../help/eventsliders_help.py" line="168" />
        <source>for YOCTOPUCE RC modules: with c:int the channel, p:int the target position, the optional t the duration in ms</source>
        <translation>对于 YOCTOPUCE RC 模块：使用 c:int 通道，p:int 目标位置，可选的 t 持续时间以毫秒为单位</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="245" />
        <location filename="../help/eventsliders_help.py" line="169" />
        <source>for YOCTOPUCE RC modules: with n an int [0..65000] in us</source>
        <translation>对于 YOCTOPUCE RC 模块：在我们中使用 n 和 int [0..65000]</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="246" />
        <location filename="../help/eventsliders_help.py" line="170" />
        <source>for YOCTOPUCE RC modules: with r an int in %</source>
        <translation>对于 YOCTOPUCE RC 模块：使用 r 和 int，以 % 为单位</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="247" />
        <location filename="../help/eventsliders_help.py" line="171" />
        <source>Stepper Command</source>
        <translation>步进命令</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="247" />
        <location filename="../help/eventsliders_help.py" line="171" />
        <source>for PHIDGET Stepper Motors: set the target position</source>
        <translation>对于 PHIDGET 步进电机：设置目标位置</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="248" />
        <location filename="../help/eventsliders_help.py" line="172" />
        <source>for PHIDGET Stepper Motors: set the rescale factor</source>
        <translation>对于 PHIDGET 步进电机：设置重新缩放因子</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="249" />
        <location filename="../help/eventsliders_help.py" line="173" />
        <source>for PHIDGET Stepper Motors: engage (b=1) or disengage (b = 0)</source>
        <translation>对于 PHIDGET 步进电机：接合（b=1）或脱离（b = 0）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="250" />
        <location filename="../help/eventsliders_help.py" line="174" />
        <source>WebSocket Command</source>
        <translation>WebSocket指令</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="251" />
        <location filename="../help/eventsliders_help.py" line="174" />
        <source>If {} substitutions are used, json brackets need to be duplicated to escape them like in send({{ “value”: {}}})</source>
        <translation>如果使用 {} 替换，则需要复制 json 括号以将它们转义，如 send({{ “value”: {}}})</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="256" />
        <location filename="../help/eventsliders_help.py" line="177" />
        <source>if the `&lt;json&gt;` text respects the JSON format it is send to the connected WebSocket server and the response is bound to the variable `_`</source>
        <translation>如果 `&lt;json&gt;` 文本遵守 JSON 格式，则将其发送到连接的 WebSocket 服务器，并且响应绑定到变量 `_`</translation>
    </message>
    <message>
        <location filename="../help/s7_help.py" line="14" />
        <location filename="../help/modbus_help.py" line="14" />
        <source>PORTS CONFIGURATION</source>
        <translation>端口配置</translation>
    </message>
    <message>
        <location filename="../help/modbus_help.py" line="17" />
        <source>MODBUS SETTINGS</source>
        <translation>MODBUS 设置</translation>
    </message>
    <message>
        <location filename="../help/modbus_help.py" line="18" />
        <source>The MODBUS serial protocols RTU, ASCII, and Binary is using the specified serial port parameters. The MODBUS IP protocol on TCP and UDP is respecting the host IP and port.</source>
        <translation>MODBUS 串行协议 RTU、ASCII 和二进制使用指定的串行端口参数。 TCP 和 UDP 上的 MODBUS IP 协议尊重主机 IP 和端口。</translation>
    </message>
    <message>
        <location filename="../help/modbus_help.py" line="19" />
        <source>The inputs 1+2 configure the MODBUS device, inputs 3+4 configure the MODBUS_34 device and so on.
Inputs with the device id set to 0 are turned off.</source>
        <translation>输入 1+2 配置 MODBUS 设备，输入 3+4 配置 MODBUS_34 设备，依此类推。
设备 ID 设置为 0 的输入将被关闭。</translation>
    </message>
    <message>
        <location filename="../help/modbus_help.py" line="20" />
        <source>Function 1 (Read Coils): registers 0 to 65535 corresponding to numbers 000001 to 065536
Function 2 (Read Discrete Inputs): registers 0 to 65535 corresponding to numbers 100001 to 165536
Function 3 (Read Multiple Holding Registers): registers 0 to 65535 corresponding to numbers 400001 to 465536
Function 4 (Read Input Registers): registers 0 to 65535 corresponding to numbers 300001 to 365536</source>
        <translation>功能 1（读取线圈）：寄存器 0 到 65535 对应数字 000001 到 065536
功能 2（读取离散输入）：寄存器 0 到 65535 对应于数字 100001 到 165536
功能 3（读取多个保持寄存器）：寄存器 0 到 65535 对应编号 400001 到 465536
功能 4（读取输入寄存器）：寄存器 0 到 65535 对应于编号 300001 到 365536</translation>
    </message>
    <message>
        <location filename="../help/modbus_help.py" line="21" />
        <source>Dividers 1/10 and 1/100 can be set to recreate decimals of floats transported as integers multiplied by 10 or 100. Eg. a value of 145.2 might be transmitted as 1452, which is turned back into 145.2 by the 1/10 divider.</source>
        <translation>可以设置除法器 1/10 和 1/100 以重新创建作为整数乘以 10 或 100 的浮点数的小数。 145.2 的值可能会作为 1452 传输，然后通过 1/10 分频器将其转换回 145.2。</translation>
    </message>
    <message>
        <location filename="../help/s7_help.py" line="21" />
        <location filename="../help/modbus_help.py" line="22" />
        <source>Temperature readings are automatically converted based on the specified unit per input channel.</source>
        <translation>温度读数会根据每个输入通道的指定单位自动转换。</translation>
    </message>
    <message>
        <location filename="../help/modbus_help.py" line="23" />
        <source>If a 32bit decoder is set two succeeding 16bit registers are requested and the received 4 bytes are interpreted using the byte and word order as specified by the corresponding flag.</source>
        <translation>如果设置了 32 位解码器，则请求两个后续的 16 位寄存器，并使用相应标志指定的字节和字顺序解释接收到的 4 个字节。</translation>
    </message>
    <message>
        <location filename="../help/modbus_help.py" line="24" />
        <source>The PID Control dialog can operate a connected PID using the given PID registers to set the p-i-d parameters and the set value (SV). MODBUS commands can be specified to turn the PID  on and off from that PID Control dialog. See the help page in the Events Dialog for documentation of available MODBUS write commands.</source>
        <translation>PID 控制对话框可以使用给定的 PID 寄存器来设置 p-i-d 参数和设定值 (SV)，从而操作已连接的 PID。您可以从该 PID 控制对话框中指定 MODBUS 命令来打开和关闭 PID。有关可用的 MODBUS 写入命令的文档，请参阅事件对话框中的帮助页面。</translation>
    </message>
    <message>
        <location filename="../help/s7_help.py" line="24" />
        <location filename="../help/modbus_help.py" line="25" />
        <source>The Scan button opens a simple MODBUS scanner to search for data holding registers in the connected device.</source>
        <translation>Scan 按钮打开一个简单的 MODBUS 扫描仪以搜索连接设备中的数据保存寄存器。</translation>
    </message>
    <message>
        <location filename="../help/s7_help.py" line="25" />
        <location filename="../help/modbus_help.py" line="26" />
        <source>Refer to the User Manual of your MODBUS device for information specific to the setup required for your device.</source>
        <translation>有关您的设备所需设置的特定信息，请参阅您的 MODBUS 设备的用户手册。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="14" />
        <source>EVENT CUSTOM BUTTONS</source>
        <translation>事件自定义按钮</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="18" />
        <source>Button numbers can be drag and dropped to a new position. While holding the ALT key (Windows) / OPTION (macOS) buttons are swapped
</source>
        <translation>按钮编号可以拖放到新位置。按住 ALT 键 (Windows) / OPTION (macOS) 按钮交换
</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="22" />
        <source>Button Label</source>
        <translation>按钮标签</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="22" />
        <source>Enter \n to create labels with multiple lines. \t is substituted by the event type.</source>
        <translation>输入 \n 以创建多行标签。 \t 替换为事件类型。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="23" />
        <source>Event Description</source>
        <translation>活动说明</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="23" />
        <source>Description of the Event to be recorded.</source>
        <translation>要记录的事件的描述。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="24" />
        <source>Event Type</source>
        <translation>事件类型</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="24" />
        <source>Event type to be recorded or leave blank for no event. '±' types add a chosen offset (positive or negative) to the present value of the chosen event.</source>
        <translation>要记录的事件类型，如果没有事件，则留空。 '±' 类型将所选偏移量（正或负）添加到所选事件的当前值。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="25" />
        <source>Event Value</source>
        <translation>事件值</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="25" />
        <source>Value of event (1-100) to be recorded.</source>
        <translation>要记录的事件值 (1-100)。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="26" />
        <source>Perform an action at the time of the event.</source>
        <translation>在事件发生时执行一个动作。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="27" />
        <source>Documentation</source>
        <translation>文档</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="27" />
        <source>The action Command.  Depends on the action type, &amp;#39;{}&amp;#39; is replaced by the event value and the offset in case of a ± event type.</source>
        <translation>行动命令。取决于动作类型，&amp;#39;{}&amp;#39;在 ± 事件类型的情况下，由事件值和偏移量替换。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="28" />
        <source>Button Visibility</source>
        <translation>按钮可见性</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="28" />
        <source>Hides/shows individual button.</source>
        <translation>隐藏/显示单个按钮。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="31" />
        <source>EVENT BUTTONS CONFIGURATION OPTIONS</source>
        <translation>事件按钮配置选项</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="35" />
        <source>Max buttons per row</source>
        <translation>每行最多按钮数</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="35" />
        <source>Sets a maximum number of buttons to display on a single row.</source>
        <translation>设置在单行上显示的最大按钮数。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="36" />
        <source>Button size</source>
        <translation>按钮大小</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="36" />
        <source>Sets a size for the buttons.  Choices are tiny, small and large.</source>
        <translation>设置按钮的大小。选择是微小的，小的和大的。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="37" />
        <source>Color Pattern</source>
        <translation>色彩图案</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="37" />
        <source>Applies one of 99 autogenerated color patterns to the buttons.  Set to "0" to manually choose the button colors.</source>
        <translation>将 99 种自动生成的颜色模式之一应用于按钮。设置为“0”以手动选择按钮颜色。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="38" />
        <source>Mark Last Pressed</source>
        <translation>标记上次按下</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="38" />
        <source>Invert state and color of last button pressed</source>
        <translation>反转按下的最后一个按钮的状态和颜色</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="39" />
        <source>Tooltips</source>
        <translation>工具提示</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="39" />
        <source>Show button specification as tooltips on hovering a button</source>
        <translation>将按钮规范显示为悬停按钮时的工具提示</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="40" />
        <source>Adds a new button to the bottom of the table.</source>
        <translation>新增新按钮至表格底部.</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="41" />
        <source>Inserts a new button above the selected button.</source>
        <translation>在选定按钮上方插入一个新按钮。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="42" />
        <source>Deletes the selected button.</source>
        <translation>删除选定的按钮。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="43" />
        <source>Copy the button table in tab separated format to the clipboard.  Option or ALT click to copy a tabular format to the clipboard.</source>
        <translation>将制表符分隔格式的按钮表复制到剪贴板。 Option 或 ALT 单击以将表格格式复制到剪贴板。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="47" />
        <source>LABELS</source>
        <translation>标签</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="51" />
        <source>The following substitutions are applied to button labels
</source>
        <translation>以下替换应用于按钮标签
</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="54" />
        <source>String</source>
        <translation>字符串</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="54" />
        <source>Substitution</source>
        <translation>替换内容</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="55" />
        <source>New line character</source>
        <translation>换行符</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="56" />
        <source>Event name (translated if using default event names)</source>
        <translation>事件名称（如果使用默认事件名称则进行翻译）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="57" />
        <source>Event type 1</source>
        <translation>事件类型 1</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="58" />
        <source>Event type 2</source>
        <translation>事件类型 2</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="59" />
        <source>Event type 3</source>
        <translation>事件类型 3</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="60" />
        <source>Event type 4</source>
        <translation>事件类型 4</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="61" />
        <source>OFF (translated)</source>
        <translation>关闭（翻译）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="62" />
        <source>ON (translated)</source>
        <translation>ON（翻译）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="63" />
        <source>OFF (translated, respecting button state)</source>
        <translation>OFF（已翻译，尊重按钮状态）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="64" />
        <source>ON (translated, respecting button state)</source>
        <translation>ON（翻译，尊重按钮状态）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="65" />
        <source>STOP (translated)</source>
        <translation>停止（翻译）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="66" />
        <source>START (translated)</source>
        <translation>开始（翻译）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="67" />
        <source>STOP (translated, respecting button state)</source>
        <translation>停止（翻译，尊重按钮状态）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="68" />
        <source>START (translated, respecting button state)</source>
        <translation>开始（翻译，尊重按钮状态）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="69" />
        <source>CLOSE (translated)</source>
        <translation>关闭（翻译）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="70" />
        <source>OPEN (translated)</source>
        <translation>打开（翻译）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="71" />
        <source>CLOSE (translated, respecting button state)</source>
        <translation>关闭（翻译，尊重按钮状态）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="72" />
        <source>OPEN (translated, respecting button state)</source>
        <translation>打开（翻译，尊重按钮状态）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="73" />
        <source>AUTO (translated)</source>
        <translation>自动（翻译）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="74" />
        <source>MANUAL (translated)</source>
        <translation>手册（翻译）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="75" />
        <source>AUTO (translated, respecting button state)</source>
        <translation>AUTO（翻译，尊重按钮状态）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="76" />
        <source>MANUAL (translated, respecting button state)</source>
        <translation>MANUAL（翻译，尊重按钮状态）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="77" />
        <source>STIRRER</source>
        <translation>搅拌器</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="78" />
        <source>FILL</source>
        <translation>充满</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="79" />
        <source>DISCHARGE</source>
        <translation>释放</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="80" />
        <source>RELEASE</source>
        <translation>发布</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="81" />
        <source>HEATING</source>
        <translation>加热</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="82" />
        <source>COOLING</source>
        <translation>冷却</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="83" />
        <source>FLAP</source>
        <translation>挡板</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="84" />
        <source>CONTROL</source>
        <translation>控制</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="85" />
        <source>event value</source>
        <translation>事件值</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="86" />
        <source>event value interpreted as temperature in Fahrenheit converted to the current temperature mode</source>
        <translation>事件值解释为华氏温度，转换为当前温度模式</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="87" />
        <source>event value interpreted as temperature in Celsius converted to the current temperature mode</source>
        <translation>事件值解释为摄氏温度，转换为当前温度模式</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="94" />
        <source>Note: "{}" can be used as a placeholder, it will be substituted by the current button value plus the offset for ± event types.  If a placeholder occurs several times in a description/command, all those occurrences are replaced by the value.
</source>
        <translation>注意：“{}”可以用作占位符，它将被当前按钮值加上±事件类型的偏移量替换。如果占位符在描述/命令中出现多次，则所有这些出现都将替换为该值。
</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="94" />
        <source>Note: Commands can be sequenced, separated by semicolons like in “&lt;cmd1&gt;;&lt;cmd2&gt;;&lt;cmd3&gt;”
</source>
        <translation>注意：命令可以按顺序排列，用分号分隔，如“&lt;cmd1&gt;;&lt;cmd2&gt;;&lt;cmd3&gt;”
</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="94" />
        <source>Note: All characters given as documentation to a Serial Command action are sent as one string to the connected device. If the device can interpret this string as separate commands separated by semicolon this is fine. Otherwise you can use a Multiple Event referencing a number of event buttons (using a comma separated list of event button numbers as documentation string) where each of the referenced event buttons issues one of the commands via a corresponding Serial Command action. Those event buttons can be hidden thus having the same effect as if the Serial Command allowed a sequence of commands.
</source>
        <translation>注意：作为串行命令操作的文档给出的所有字符都将作为一个字符串发送到连接的设备。如果设备可以将此字符串解释为用分号分隔的单独命令，那就没问题。否则，您可以使用引用多个事件按钮的多事件（使用逗号分隔的事件按钮编号列表作为文档字符串），其中每个引用的事件按钮通过相应的串行命令操作发出命令之一。这些事件按钮可以隐藏，因此具有与串行命令允许一系列命令相同的效果。
</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="94" />
        <source>Note: In PHIDGET commands, the optional parameter &lt;sn&gt; has the form &lt;hub_serial&gt;[:&lt;hub_port&gt;] allows to refer to a specific Phidget HUB by given its serial number, and optionally specifying the port number the addressed module is connected to.
</source>
        <translation>注意：在 PHIDGET 命令中，可选参数 &lt;sn&gt; 的格式为 &lt;hub_serial&gt;[:&lt;hub_port&gt;] 允许通过给定序列号来引用特定的 Phidg​​et HUB，并可选择指定寻址模块连接到的端口号。
</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="94" />
        <source>Note: In YOCTOPUCE commands, the optional parameter &lt;sn&gt; holds either the modules serial number or its name</source>
        <translation>注意：在 YOCTOPUCE 命令中，可选参数 &lt;sn&gt; 保存模块序列号或其名称</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="100" />
        <source>Multiple Event</source>
        <translation>多个事件</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="100" />
        <source>button numbers or sleep(&lt;float&gt;) separated by a comma: 1,2,sleep(2.5), 3..</source>
        <translation>按钮数字或 sleep(&lt;float&gt;) 以逗号分隔：1,2,sleep(2.5), 3..</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="100" />
        <source>triggers other buttons</source>
        <translation>触发其他按钮</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="250" />
        <location filename="../help/eventbuttons_help.py" line="186" />
        <location filename="../help/eventbuttons_help.py" line="170" />
        <location filename="../help/eventbuttons_help.py" line="125" />
        <location filename="../help/eventbuttons_help.py" line="102" />
        <source>variable holding the last state of the button pressed (1 or 0)</source>
        <translation>保存按下按钮的最后状态的变量（1 或 0）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="107" />
        <source>reads 1 16bit register from device deviceID using function 3 (Read Multiple Holding Registers) interpreted as unsigned integer. The result is bound to the placeholder `_` and thus can be accessed in later commands.</source>
        <translation>使用函数 3（读取多个保持寄存器）从设备 deviceID 读取 1 个 16 位寄存器，并将其解析为无符号整数。结果绑定到占位符“_”，以便后续命令中访问。</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="119" />
        <source>write 16bit BCD encoded value to register of device with DeviceID</source>
        <translation>将 16 位 BCD 编码值写入具有设备 ID 的设备寄存器</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="123" />
        <source>Insert Data address : value, ex. 4701:1000 and sv is 100. 
Always multiply with 10 if value Unit: 0.1 / ex. 4719:0 stops heating</source>
        <translation>插入数据地址：值，例如。 4701:1000 并且 sv 是 100。
如果值单位：0.1 / ex. 总是乘以 10。 4719:0 停止加热</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="124" />
        <source>variable holding the last result value</source>
        <translation>保存最后一个结果值的变量</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="151" />
        <source>p-i-d</source>
        <translation />
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="151" />
        <source>configures PID to the values &lt;p&gt;;&lt;i&gt;;&lt;d&gt;</source>
        <translation>将 PID 配置为值 &lt;p&gt;;&lt;i&gt;;&lt;d&gt;</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="157" />
        <source>PHIDGET HUB PWM Output ON port &lt;port&gt; to  &lt;value&gt; in [0-100]</source>
        <translation>PHIDGET HUB PWM 输出 ON 端口 &lt;port&gt; 到 &lt;value&gt;（范围：[0-100]）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="158" />
        <source>PHIDGET HUB PWM Output: toggles &lt;port&gt;</source>
        <translation>PHIDGET HUB PWM 输出：切换&lt;port&gt;</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="159" />
        <source>PHIDGET HUB PWM Output:  turn &lt;port&gt; ON for &lt;millis&gt; milliseconds</source>
        <translation>PHIDGET HUB PWM 输出：打开 &lt;port&gt; 并持续 &lt;millis&gt; 毫秒</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="164" />
        <source>for PHIDGET OUTPUT modules: sets voltage voltage range (r=5 for 5V and r=10 for 10V)</source>
        <translation>对于 PHIDGET OUTPUT 模块：设置电压电压范围（5V 时 r=5，10V 时 r=10）</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="180" />
        <source>write value where bits are replaced by those from orMask at positions where andMask bits are not set</source>
        <translation>在未设置 andMask 位的位置写入位被 orMask 中的位替换的值</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="185" />
        <source>Aillio R1 Command</source>
        <translation>Aillio R1指令</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="185" />
        <source>Sends PRS command</source>
        <translation>发送 PRS 命令</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="212" />
        <source>sets button i to pressed if value of b is yes, true, t, or 1, otherwise to normal</source>
        <translation>如果 b 的值为 yes、true、t 或 1，则将按钮 i 设置为按下，否则设置为正常</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="213" />
        <source>activates button &lt;name&gt; from { START, CHARGE, DRY, FCs, FCe, SCs, SCe, DROP, COOL, OFF } ; sets calling button to “pressed” if argument is 1 or True</source>
        <translation>从 { START, CHARGE, DRY, FCs, FCe, SCs, SCe, DROP, COOL, OFF } 激活按钮 &lt;name&gt; ；如果参数为 1 或 True，则将调用按钮设置为“按下”</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="215" />
        <source>sets button i to visible if value of b is yes, true, t, or 1, otherwise to hidden</source>
        <translation>如果 b 的值为 yes、true、t 或 1，则将按钮 i 设置为可见，否则设置为隐藏</translation>
    </message>
    <message>
        <location filename="../help/eventbuttons_help.py" line="244" />
        <source>for YOCTOPUCE RC modules: with c:int the channel, p:int the target position, the optional t the duration in ms, sn the optional modules serial number or logical name</source>
        <translation>对于 YOCTOPUCE RC 模块：c:int 通道，p:int 目标位置，可选 t 持续时间（毫秒），sn 可选模块序列号或逻辑名称</translation>
    </message>
    <message>
        <location filename="../help/s7_help.py" line="17" />
        <source>S7 SETTINGS</source>
        <translation>S7 设置</translation>
    </message>
    <message>
        <location filename="../help/s7_help.py" line="18" />
        <source>The Siemens S7 is respecting the host IP and port.</source>
        <translation>西门子 S7 尊重主机 IP 和端口。</translation>
    </message>
    <message>
        <location filename="../help/s7_help.py" line="19" />
        <source>The inputs 1+2 configure the S7 device, inputs 3+4 configure the S7_34 device and so on.
Inputs with the area set to the empty input are turned off.</source>
        <translation>输入 1+2 配置 S7 设备，输入 3+4 配置 S7_34 设备，依此类推。
区域设置为空输入的输入被关闭。</translation>
    </message>
    <message>
        <location filename="../help/s7_help.py" line="20" />
        <source>Factors 1/10 and 1/100 can be set as dividers to recreate decimals of floats transported as integers multiplied by 10 or 100. Eg. a value of 145.2 might be transmitted as 1452, which is turned back into 145.2 by the 1/10 divider.</source>
        <translation>因子 1/10 和 1/100 可以设置为分隔符，以重新创建作为整数乘以 10 或 100 传输的浮点数的小数。例如。 145.2 的值可能会作为 1452 传输，然后通过 1/10 分频器将其转换回 145.2。</translation>
    </message>
    <message>
        <location filename="../help/s7_help.py" line="22" />
        <source>If mode is set to C or F, readings are automatically converted to the temperature unit set for display.</source>
        <translation>如果模式设置为 C 或 F，读数将自动转换为设置的温度单位以供显示。</translation>
    </message>
    <message>
        <location filename="../help/s7_help.py" line="23" />
        <source>The PID Control dialog can operate a connected PID using the given PID registers to set the p-i-d parameters and the set value (SV). S7 commands can be specified to turn the PID on and off from that PID Control dialog. See the help page in the Events Dialog for documentation of available S7 write commands.</source>
        <translation>PID 控制对话框可以使用给定的 PID 寄存器来设置 p-i-d 参数和设定值 (SV)，从而操作已连接的 PID。可以通过该 PID 控制对话框指定 S7 命令来打开和关闭 PID。有关可用的 S7 写入命令的文档，请参阅事件对话框中的帮助页面。</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="14" />
        <source>EVENT ANNOTATIONS</source>
        <translation>事件注释</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="30" />
        <location filename="../help/eventannotations_help.py" line="17" />
        <source>Prefix Field</source>
        <translation>添加前缀</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="66" />
        <location filename="../help/autosave_help.py" line="30" />
        <location filename="../help/eventannotations_help.py" line="17" />
        <source>Example</source>
        <translation>实例</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="18" />
        <source>The value of Event</source>
        <translation>事件的数值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="25" />
        <location filename="../help/eventannotations_help.py" line="19" />
        <source>ET value</source>
        <translation>ET值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="26" />
        <location filename="../help/eventannotations_help.py" line="20" />
        <source>BT value</source>
        <translation>BT值</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="21" />
        <source>The Description field of the Event</source>
        <translation>事件的描述字段</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="22" />
        <source>The Type field of the Event</source>
        <translation>事件的类型字段</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="23" />
        <source>The value of the Slider Unit for this Event</source>
        <translation>此事件的滑块单元的值</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="24" />
        <source>Number of seconds before or after CHARGE 
Before CHARGE shows negative 
Displays &amp;#39;*&amp;#39; when no CHARGE event exists</source>
        <translation>CHARGE 之前或之后的秒数
在CHARGE显示负数之前
显示 &amp;#39;*&amp;#39;当不存在 CHARGE 事件时</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="25" />
        <source>Time before or after CHARGE in min:sec 
Before CHARGE shows negative 
Displays &amp;#39;*&amp;#39; when no CHARGE event exists</source>
        <translation>CHARGE 之前或之后的时间，以 min:sec 为单位
在CHARGE显示负数之前
显示 &amp;#39;*&amp;#39;当不存在 CHARGE 事件时</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="26" />
        <source>Number of seconds before or after FCs 
Best used inside double quotes (see notes below) 
Negative value before FCs 
Displays &amp;#39;*&amp;#39; when no FCs event exists</source>
        <translation>FC 之前或之后的秒数
最好在双引号内使用（见下面的注释）
FC 之前的负值
显示 &amp;#39;*&amp;#39;当不存在 FCs 事件时</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="27" />
        <source>Time after FCs in min:sec 
Best used inside double quotes (see notes below) 
Negative value before FCs 
Displays &amp;#39;*&amp;#39; when no FCs event exists</source>
        <translation>FC 后的时间（以 min:sec 为单位）
最好在双引号内使用（见下面的注释）
FC 前的负值
显示 &amp;#39;*&amp;#39;当不存在 FCs 事件时</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="28" />
        <source>Number of seconds before FCs 
Best used inside single quotes or back ticks (see notes below) 
Positive value only 
Displays &amp;#39;*&amp;#39; after FCs or when no FCs event exists</source>
        <translation>FC 之前的秒数
最好在单引号或反引号内使用（见下面的注释）
仅正值
显示 &amp;#39;*&amp;#39;在 FC 之后或不存在 FC 事件时</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="29" />
        <source>Time before FCs  in min:sec 
Best used inside single quotes or back ticks (see notes below) 
Positive value only 
Displays &amp;#39;*&amp;#39; after FCs or when no FCs event exists</source>
        <translation>FC 之前的时间（以 min:sec 为单位）
最好在单引号或反引号内使用（见下面的注释）
仅正值
显示 &amp;#39;*&amp;#39;在 FC 之后或不存在 FC 事件时</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="30" />
        <source>Development time ratio (percent). Note: DTR=0 before FCs 
100*(t{Event}-t{FCs})/(t{FCs}-t{CHARGE})</source>
        <translation>开发时间比率（百分比）。注意：FC 前 DTR=0
100*(t{事件}-t{FCs})/(t{FCs}-t{CHARGE})</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="31" />
        <source>The degree symbol</source>
        <translation>学位符号</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="32" />
        <source>Temperature mode (&amp;#39;C&amp;#39; or &amp;#39;F&amp;#39;)</source>
        <translation>温度模式（&amp;#39;C&amp;#39; 或 &amp;#39;F&amp;#39;）</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="33" />
        <source>Degree symbol with Temperature mode</source>
        <translation>带温度模式的度数符号</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="34" />
        <source>ET RoR value
Displays &amp;#39;--&amp;#39; when the RoR value is not available.</source>
        <translation>ET RoR 值
显示 &amp;#39;--&amp;#39;当 RoR 值不可用时。</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="35" />
        <source>BT RoR value
Shows &amp;#39;--&amp;#39; when the RoR value Is not available.</source>
        <translation>BT RoR 值
显示 &amp;#39;--&amp;#39;当 RoR 值不可用时。</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="36" />
        <source>RoR units
Shorthand for &amp;#39;~deg~mode/min&amp;#39;</source>
        <translation>RoR 单位
&amp;#39;~deg~mode/min&amp;#39; 的简写</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="37" />
        <source>ET RoR with units
Field is hidden when the RoR value is not available.</source>
        <translation>ET RoR 带单位
当 RoR 值不可用时，该字段被隐藏。</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="38" />
        <source>BT RoR with units
Field is hidden when the RoR value is not available.</source>
        <translation>BT RoR 带单位
当 RoR 值不可用时，该字段被隐藏。</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="39" />
        <source>Quote symbol</source>
        <translation>报价符号</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="40" />
        <source>Single quote symbol</source>
        <translation>单引号符号</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="123" />
        <location filename="../help/eventannotations_help.py" line="43" />
        <source>EXAMPLES</source>
        <translation>范例</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="47" />
        <source>Assumptions:  The event value is 50.  In the case of Gas the value 50 corresponds to either 5.0kPh or 50%.  
For a sensory milestone (see notes above) the value 50 corresponds to the "Hay" aroma.</source>
        <translation>假设：事件值为 50。在气体的情况下，值 50 对应于 5.0kPh 或 50%。
对于感官里程碑（见上文注释），值 50 对应于“干草”香气.</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="50" />
        <source>Annotation Field</source>
        <translation>注释字段</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="50" />
        <source>Displays</source>
        <translation>显示</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="51" />
        <source>Gas ~E @~Y2~degmode</source>
        <translation>气体 ~E @~Y2~degmode</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="51" />
        <source>Gas 50 @340°F</source>
        <translation>气体 50 @340°F</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="52" />
        <source>Gas ~E% @~Y2~mode</source>
        <translation>气体~E%@~Y2~模式</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="52" />
        <source>Gas 50% @340F</source>
        <translation>气体 50% @340F</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="53" />
        <source>Gas ~E/10kPh @~Y2~mode</source>
        <translation>气体 ~E/10kPh @~Y2~模式</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="53" />
        <source>Gas 5.0kPh @340F</source>
        <translation>气体 5.0kPh @340F</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="54" />
        <source>Gas ~E/10kPh @~Y2~mode and ~R2~degmin</source>
        <translation>气体 ~E/10kPh @~Y2~mode 和 ~R2~degmin</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="54" />
        <source>Gas 5.0kPh @340F and 32.8°F/min</source>
        <translation>气体 5.0kPh @340F 和 32.8°F/min</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="55" />
        <source>Gas ~E% &amp;#39;@~Y2 ~degmode&amp;#39;"@~DTR% DTR"</source>
        <translation>气体~E% &amp;#39;@~Y2 ~degmode&amp;#39;"@~DTR% DTR"</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="55" />
        <source>Before FCs:
Gas 50% @340 °F

After FCs:
Gas 50% @12% DTR</source>
        <translation>FC之前：
气体 50% @340 °F

FC之后：
气体 50% @12% DTR</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="56" />
        <source>Gas ~E% &amp;#39;@~Y2 ~degmode`, ~preFCs sec before FCs`&amp;#39;"@~DTR% DTR"</source>
        <translation />
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="56" />
        <source>More than 90 seconds before FCs:
Gas 50% @340 °F

Less than 90 seconds before FCs:
Gas 50% @340 °F, 50 sec before FCs 

After FCs:
Gas 50% @12% DTR</source>
        <translation>FC 前 90 秒以上：
气体 50% @340 °F

FC 前不到 90 秒：
气体 50% @340 °F，FC 前 50 秒

FC之后：
气体 50% @12% DTR</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="57" />
        <source>{20Fresh Cut Grass|50Hay|80Baking Bread|100A Point} @~Y2~degmode</source>
        <translation>{20鲜切草|50干草|80烤面包|100A点}@~Y2~degmode</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="57" />
        <source>Hay @340 °F</source>
        <translation>干草@340°F</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="60" />
        <source>NOTES:</source>
        <translation>笔记：</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="64" />
        <source>Event annotations apply only for &amp;#39;Step&amp;#39; and &amp;#39;Step+&amp;#39; Events settings</source>
        <translation>事件注释仅适用于 &amp;#39;Step&amp;#39;和&amp;#39;步骤+&amp;#39;活动设置</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="65" />
        <source>Anything between double quotes " will show only after FCs. Example: "~E1 @~DTR%"</source>
        <translation>双引号 " 之间的任何内容仅在 FC 之后显示。示例："~E1 @~DTR%"</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="66" />
        <source>Anything between single quotes &amp;#39; will show only before FCs. Example: &amp;#39;~E1 @~degmode&amp;#39;</source>
        <translation>单引号 &amp;#39; 之间的任何内容只会在 FC 之前显示。示例：&amp;#39;~E1 @~degmode&amp;#39;</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="67" />
        <source>Anything between back ticks ` will show only within 90 seconds before FCs. Example: `~E1 `FCs~dFCs sec`</source>
        <translation>反引号 ` 之间的任何内容将仅在 FC 前 90 秒内显示。示例：`~E1 `FCs~dFCs sec`</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="68" />
        <source>When combining back ticks with single or double quotes the back ticks should be inside the quotes.</source>
        <translation>将反引号与单引号或双引号组合时，反引号应位于引号内。</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="69" />
        <source>Background event annotations can be seen during a roast when &amp;#39;Annotations&amp;#39; is checked in the Profile Background window.</source>
        <translation>当 &amp;#39;Annotations&amp;#39; 在烘焙期间可以看到背景事件注释。已在“配置文件背景”窗口中选中。</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="70" />
        <source>Simple scaling of the event value is possible. Use a single math operator (&amp;#39;*&amp;#39;, &amp;#39;/&amp;#39;, &amp;#39;+&amp;#39; or &amp;#39;-&amp;#39;) immediately following the field name "E". For example: 
&amp;#39;~E/10&amp;#39; will divide the E value by 10. 
&amp;#39;~E+5&amp;#39; adds 5 to the the value of E.</source>
        <translation>事件值的简单缩放是可能的。在字段之后使用单个数学运算符（&amp;#39;*&amp;#39;、&amp;#39;/&amp;#39;、&amp;#39;+&amp;#39; 或 &amp;#39;-&amp;#39;）名称“E”。例如：
&amp;#39;~E/10&amp;#39;将 E 值除以 10。
&amp;#39;~E+5&amp;#39; E 的值加 5。</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="71" />
        <source>Another style of annotations allows to replace an event&amp;#39;s numeric value with a text string, known as a nominal value. One example where this can be useful is when an event is used to record sensory milestones. The value 20 might be used for &amp;#39;Fresh Cut Grass&amp;#39; aroma, 50 for &amp;#39;Hay&amp;#39;, 80 for &amp;#39;Baking Bread&amp;#39;, and 100 to represent the &amp;#39;A Point&amp;#39;.  

This form of annotation must be enclosed in curly brackets &amp;#39;{}&amp;#39;. Entries are numeric values immediately followed by their nominal representation text.  Entries are separated by the vertical bar &amp;#39;|&amp;#39;. The following Annotation string implements this example.   
{~E|20Fresh Cut Grass|50Hay|80Baking Bread|100A Point} 

Note that if the event value  does not match any value in the Annotation definition a blank string will be returned.  In the example above an event value of 30 will return a blank string.  The easiest way to ensure these values match is to use Custom Buttons to for the Event.</source>
        <translation>另一种注释风格允许将事件的数值替换为文本字符串，称为标称值。一个有用的例子是当一个事件被用来记录感官里程碑时。值 20 可能用于 &amp;#39;Fresh Cut Grass&amp;#39;香气，50 代表 &amp;#39;Hay&amp;#39;，80 代表 &amp;#39;Baking Bread&amp;#39;，100 代表 &amp;#39;A Point&amp;#39;。

这种形式的注释必须用大括号 &amp;#39;{}&amp;#39; 括起来。条目是紧跟其名义表示文本的数值。条目由竖线 &amp;#39;|&amp;#39; 分隔。下面的 Annotation 字符串实现了这个例子。
{~E|20鲜切草|50干草|80烤面包|100A点}

请注意，如果事件值与注释定义中的任何值都不匹配，则将返回空白字符串。在上面的示例中，事件值 30 将返回一个空白字符串。确保这些值匹配的最简单方法是对事件使用自定义按钮。</translation>
    </message>
    <message>
        <location filename="../help/eventannotations_help.py" line="72" />
        <source>When annotations overlap to the point they can not be read, try reducing the value of the &amp;#39;Allowed Annotation Overlap&amp;#39; found on the Annotations configuration page.  The default value for this setting is 100%.</source>
        <translation>当注释重叠到无法阅读的程度时，请尝试减小 &amp;#39;Allowed Annotation Overlap&amp;#39; 的值。在注释配置页面上找到。此设置的默认值为 100%。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="14" />
        <source>Energy and CO2 Calculator</source>
        <translation>能源和二氧化碳计算器</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="18" />
        <source>The Energy tab displays a roast&amp;#39;s energy consumption.   CO2 emissions are also calculated to monitor the impact of the roasting operation.  Settings must be made for each energy load.  Loads are the main burners, motors and blowers, and an afterburner if one is used.  The energy used for pre-heating, between batch, and roaster cooling protocols are included in the calculations, and settings are available for them as well.

Note that pre-heating and roaster cooling energy values are applied to the first roast of a roasting session.  Between batch energies are applied to every roast except the first.  Tick the "Between batches after Pre-Heating box to apply the between batch value to the first roast.

Follow the steps below to set the energy inputs for the roast machine and afterburner.</source>
        <translation>能源选项卡显示烘焙的能源消耗。还计算二氧化碳排放量以监测焙烧操作的影响。必须为每个能源负载进行设置。负载是主燃烧器、电机和鼓风机，如果使用了加力燃烧器，则为负载。用于预热、批次之间和烘焙机冷却协议的能源包含在计算中，并且它们也可以设置。

请注意，预热和烘焙机冷却能源值适用于烘焙过程的第一次烘焙。批次之间的能源应用于除第一次之外的每一次烘焙。勾选“预热后批次间”框，将批次间值应用于第一次烘焙。

按照以下步骤设置烘焙机和加力燃烧器的能源输入。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="18" />
        <source>Blank entries  are the same as a zero entry.  Negative values are not allowed.</source>
        <translation>空白条目与零条目相同。不允许使用负值。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="22" />
        <source>Once you set up the Loads sub-tab and the Protocols sub-tab, it is a good idea to click "Save Defaults" on both  sub-tabs (they are saved separately).  When loading a profile with existing energy values, the profile settings will be read and will overwrite the values on the Loads and Profiles sub-tabs.  Having them saved as defaults allow for them to be quickly restored by clicking "Restore Defaults" on each sub-tab.</source>
        <translation>一旦设置了负载子选项卡和协议子选项卡，最好在两个子选项卡上单击“保存默认值”（它们分别保存）。加载具有现有能源值的配置文件时，将读取配置文件设置并将覆盖“负载”和“配置文件”子选项卡上的值。将它们保存为默认值可以通过单击每个子选项卡上的“恢复默认值”来快速恢复它们。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="25" />
        <source>1. Details Sub-Tab</source>
        <translation>1. 详细信息子选项卡</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="29" />
        <source>This sub-tab shows a detailed table of the energy consumption and CO2 production data for the roast.  The values in this table are based on current Profile and the settings made on the Loads and Protocols sub-tabs.  Columns may be sorted by clicking on the column title.  To return to original sort click on the &amp;#39;Kind&amp;#39; column title.</source>
        <translation>该子选项卡显示了烘焙的能耗和二氧化碳产量数据的详细表格。此表中的值基于当前配置文件以及在负载和协议子选项卡上所做的设置。可以通过单击列标题对列进行排序。要返回原始排序，请单击 &amp;#39;Kind&amp;#39;列标题。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="33" />
        <source>Results in</source>
        <translation>特征显示为</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="33" />
        <source>Choose the energy units for the summary displays and the Details sub-tab.</source>
        <translation>为摘要显示和详细信息子选项卡选择能源单位。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="36" />
        <source>2. Loads Sub-Tab</source>
        <translation>2.加载子选项卡</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="40" />
        <source>Begin by making entries on the Loads sub-tab  to define the sources of energy used by this roast. It might be a good idea to save those settings as defaults to be used to calculate the energy consumption of future roasts</source>
        <translation>首先在“负载”子选项卡上输入条目以定义此烘焙使用的能源。将这些设置保存为默认值以用于计算未来烘焙的能耗可能是个好主意</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="40" />
        <source>Power ratings for up to four energy loads may be entered.  Loads will be the main burners or heaters, motors and blowers, and the afterburner if one is used.  Enter one load per line.  Motors and blowers that run continuously may be aggregated and entered as one load.</source>
        <translation>最多可以输入四个能源负载的额定功率。负载将是主燃烧器或加热器、电机和鼓风机，以及加力燃烧器（如果使用的话）。每行输入一个负载。连续运行的电机和鼓风机可以汇总并作为一个负载输入。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="40" />
        <source>Loads are assumed to run continuously. Variable loads, such as the main burner setting, can be recorded in Artisan using one of the four special events.  The settings can be captured from a button, slider or in some cases read directly from the roaster.  The load setup allows linking a load to one of these events.  The energy calculator will then determine the setting percentage and the duration of the setting to calculate the energy consumed.</source>
        <translation>假定负载连续运行。可以使用四个特殊事件之一在 Artisan 中记录可变负载，例如主燃烧器设置。可以从按钮、滑块或在某些情况下直接从烘焙机读取设置。负载设置允许将负载链接到这些事件之一。能源计算器然后将确定设置百分比和设置的持续时间以计算消耗的能源。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="40" />
        <source>Burner entries require knowing the power rating of the burner.  Roasting machine manufacturer&amp;#39;s typically provide this information.  If this information can not be found for your machine this table provides approximate values based on roaster capacities.  https://artisan-scope.org/ratings/</source>
        <translation>燃烧器条目需要知道燃烧器的额定功率。烘焙机制造商通常会提供此信息。如果无法为您的机器找到此信息，此表提供基于烘焙机容量的近似值。 https://artisan-scope.org/ratings/</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="40" />
        <source>Energy Meters</source>
        <translation>电能表</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="40" />
        <source>Artisan allows the direct reading of 2 energy meters to support the use of measured energy consumption values in place of estimated values defined by the Loads. These energy meters could measure gas or electricity. As an energy meter the instantaneous power reading must be accumulated over a period of time.  Energy readings are typically in kWh or BTU, though other units are supported.  Artisan will use the Meter reading at the start of recording and end of recording to calculate energy consumption for the roast batch.  Intermediate reads at major roast events are also used in presenting phase energy consumption.</source>
        <translation>Artisan 允许直接读取 2 个能源表，以支持使用测量的能耗值代替负载定义的估算值。这些能源表可以测量天然气或电力。作为能源表，瞬时功率读数必须在一段时间内累积。能源读数通常以 kWh 或 BTU 为单位，但也支持其他单位。Artisan 将使用记录开始和记录结束时的仪表读数来计算烘焙批次的能耗。主要烘焙事件的中间读数也用于呈现阶段能耗.</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="40" />
        <source>Energy meter data must be recorded in an Extra Device (Config&gt;&gt; Devices&gt;&gt; Extra devices tab).  The Extra Device is then used as the Source for the meter in the Energy tab.  Connectivity to the meter is typically via MODBUS. Some devices, like the YoctoWatt, have direct connection support in Artisan.  The data recorded in the Extra Device must be scaled to one of the units supported in the Energy tab such as kWh, BTU, kJ, kCal or therms (thm).  For instance, an electricity meter that returns energy readings in Wh that must be scaled to kWh buy using the symbolic equation "x/1000".</source>
        <translation>电能表数据必须记录在附加设备中（配置&gt;&gt;设备&gt;&gt;附加设备选项卡）。然后，附加设备将用作电能选项卡中电能表的来源。通常通过 MODBUS 连接电能表。某些设备（如 YoctoWatt）在 Artisan 中支持直接连接。附加设备中记录的数据必须缩放为电能选项卡中支持的单位之一，例如 kWh、BTU、kJ、kCal 或 therms (thm)。例如，返回以 Wh 为单位的能源读数的电能表必须使用符号方程“x/1000”缩放为 kWh.</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="44" />
        <source>Label</source>
        <translation>标签</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="44" />
        <source>Enter your personal description for this burner.  Examples are &amp;#39;Main&amp;#39; and &amp;#39;Afterburner&amp;#39;.</source>
        <translation>输入您对此燃烧器的个人描述。例子是 &amp;#39;Main&amp;#39;和&amp;#39;加力燃烧室&amp;#39;。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="45" />
        <source>Rating</source>
        <translation>额定值</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="45" />
        <source>This is the power rating of the load.  Choose the units in the next column.</source>
        <translation>这是负载的额定功率 选择下一栏中的单位.</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="46" />
        <source>Select the appropriate power unit. Some manufacturers incorrectly use BTU.  In that case use BTU/h for the unit.</source>
        <translation>选择合适的功率单元。一些制造商错误地使用 BTU。在这种情况下，使用 BTU/h 作为单位。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="47" />
        <source>Fuel</source>
        <translation>燃料类型</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="47" />
        <source>Select the type of fuel used by this load  &amp;#39;Elec&amp;#39; is assumed to be electricity generated from dirty coal.  There is a setting below to adjust for renewable clean energy sources.</source>
        <translation>选择此负载使用的燃料类型 &amp;#39;Elec&amp;#39;假设是用脏煤发电。以下设置可针对可再生清洁能源进行调整。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="48" />
        <source>Special Events are often used to record load settings, such as a burner setting, in the roast profile.  Select the Event that corresponds to the load setting here.  

When blank the load is assumed to be at a constant setting, which is the percent &amp;#39;Value 100%&amp;#39; multiplied by the rating.  A 10 kW load at &amp;#39;100% Value&amp;#39;= 60 would thus be 10 kW * 60% = 6 kW. Continuous loads are typically motors and blowers and the afterburner.</source>
        <translation>特殊事件通常用于在烘焙配置文件中记录负载设置，例如燃烧器设置。在此处选择与负载设置对应的事件。

当空白时，假设负载处于恒定设置，即百分比 &amp;#39;Value 100%&amp;#39;乘以评级。因此，&amp;#39;100% Value&amp;#39;= 60 的 10 kW 负载将是 10 kW * 60% = 6 kW。连续负载通常是电机和鼓风机以及加力燃烧室。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="49" />
        <source>Pressure %</source>
        <translation>气压 %</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="49" />
        <source>For gas loads tick this box when  the readings are made in units of pressure.  Some roasters and some controllers provide readings in heat energy.  When the readings are made in heat energy leave this box unticked.</source>
        <translation>对于气体负载，当读数以压力为单位时，请勾选此框。一些烘焙机和一些控制器提供热能读数。当以热能计读数时，不要勾选此框。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="50" />
        <source>Value 0%</source>
        <translation>数值 0%</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="50" />
        <source>When an Event is selected in the previous column this value can be set to match the 0% burner setting to the event setting.  In most cases a 0 Event value will correspond to the 0% load setting.</source>
        <translation>在上一列中选择事件时，可以设置此值以将 0% 燃烧器设置与事件设置相匹配。在大多数情况下，0 事件值将对应于 0% 负载设置。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="51" />
        <source>Value 100%</source>
        <translation>数值 100%</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="51" />
        <source>When an Event is selected this value can be set to match the 100% load setting to the event setting.  This is useful when the 100% load setting is recorded as a different number in the Event.  For instance, maybe the burner event is recorded as 10x the kPa reading on the gas manometer.  An event value of 35 is recoded to signify 3.5 kPa, which is 50% pressure.  If the 100% burner setting corresponds to 7 kPa then the &amp;#39;Value 100%&amp;#39; should be set to 70, which is 7 * 10  = 70.  Thus 3.5 kPa will be seen by he energy calculator as 50%.  For pressure readings be sure to tick the Pressure box.  Heat energy readings are normally 0%-100% and do not require any adjustment to this  setting.</source>
        <translation>选择事件时，可以设置此值以使 100% 负载设置与事件设置相匹配。当 100% 负载设置在事件中记录为不同的数字时，这很有用。例如，燃烧器事件可能被记录为燃气压力计上千帕读数的 10 倍。事件值 35 被重新编码以表示 3.5 kPa，即 50% 压力。如果 100% 燃烧器设置对应于 7 kPa，则 &amp;#39;Value 100%&amp;#39;应设置为 70，即 7 * 10 = 70。因此，能源计算器会将 3.5 kPa 视为 50%。对于压力读数，请务必勾选压力框。热能读数通常为 0%-100%，不需要对此设置进行任何调整。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="52" />
        <source>Meter Label</source>
        <translation>仪表标签</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="52" />
        <source>A user defined label for the meter.</source>
        <translation>仪表的用户定义标签。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="53" />
        <source>Meter Unit</source>
        <translation>仪表单位</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="53" />
        <source>The energy unit for the data read from the Extra Device.</source>
        <translation>从额外设备读取的数据的能源单位。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="54" />
        <source>Meter Type</source>
        <translation>仪表类型</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="54" />
        <source>The type of fuel measured by this meter.</source>
        <translation>该仪表测量的燃料类型。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="55" />
        <source>Meter Source</source>
        <translation>仪表源</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="55" />
        <source>The Extra Device holding the scaled energy data.</source>
        <translation>保存缩放能源数据的额外设备。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="56" />
        <source>Electric Energy Mix</source>
        <translation>电能结构</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="56" />
        <source>This setting allows to set a mix of renewable energy that sources the electric loads.  0% assumes all the energy comes from burning dirty coal and maximizes the CO2 in the calculations.  100% assumes the energy comes only from renewable sources with no CO2 produced.</source>
        <translation>此设置允许设置为电力负载提供来源的可再生能源组合。 0% 假设所有能源都来自燃烧脏煤，并在计算中最大化 CO2。 100% 假设能源仅来自不产生二氧化碳的可再生能源。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="57" />
        <source>Gas Energy Mix</source>
        <translation>天然气能源结构</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="57" />
        <source>This setting allows to set a mix of bio gas in the NG source.  0% thus means no bio gas.  100% bio gas is estimated to reduce GHG emissions by approximately 24%.</source>
        <translation>此设置允许设置 NG 源中的生物气体混合。0% 表示没有生物气体。据估计，100% 生物气体可减少约 24% 的温室气体排放。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="77" />
        <location filename="../help/energy_help.py" line="58" />
        <source>Save Defaults</source>
        <translation>保存默认</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="58" />
        <source>Stores the current settings on this sub-tab as defaults to be recalled later. The default values will be stored when saving settings (Help&gt;Save Settings) to a file.</source>
        <translation>将此子选项卡上的当前设置存储为默认设置，以便稍后调用。将设置（帮助&gt;保存设置）保存到文件时将存储默认值.</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="78" />
        <location filename="../help/energy_help.py" line="59" />
        <source>Restore Defaults</source>
        <translation>恢复默认</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="78" />
        <location filename="../help/energy_help.py" line="59" />
        <source>Overwrites the values on this sub-tab with those stored as the defaults.  When a profile with energy settings is opened, the values on this tab will be read from the profile.   They will be overwritten when clicking Restore Defaults.</source>
        <translation>使用存储为默认值的值覆盖此子选项卡上的值。打开带有能源设置的配置文件时，将从配置文件中读取此选项卡上的值。单击恢复默认值时，它们将被覆盖。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="62" />
        <source>3. Protocol Sub-Tab</source>
        <translation>3. 协议子选项卡</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="66" />
        <source>The Protocol settings allow including Pre-Heating, Between Batch (BBP) and Cooling protocol energy consumption.  There are two ways to specify these values.  The first assumes a constant load setting for a defined period of time.  An example for pre-heating is to set a Duration of 45:00 (45 minutes) at 30% Burner setting.  Percentages must be entered with the percent sign (30%).  When a percentage is entered  a corresponding Duration must be entered.</source>
        <translation>协议设置允许包括预热、批次间 (BBP) 和冷却协议能耗。有两种方法可以指定这些值。第一个假设在定义的时间段内保持恒定的负载设置。预热的一个示例是在 30% 燃烧器设置下设置 45:00（45 分钟）的持续时间。百分比必须使用百分号 (30%) 输入。输入百分比时，必须输入相应的持续时间。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="66" />
        <source>The second type of entry is a "measured" energy value.  This can be any value greater than 1.0.  Artisan can inspect the open profile to determine energy values for each Load that is associated with an Event on the Loads sub-tab.  Click the [...] button for each Protocol to auto fill the Measured Energy fields.   The Artisan measurements for Pre-Heating and Between Batches are made from the start of the profile until CHARGE.  If there is no CHARGE event the measurement is from the start to the end of profile.  The values measured for Pre-Heating and Between Batches are the same.  Be sure you do not use the same profile to enter both values.  The Cooling energy is measured from DROP to the end of the profile.  If there is no DROP event the measurement begins at CHARGE.  If there is no CHARGE event the measurement is from the start to the end of the profile.</source>
        <translation>第二种类型的条目是“测量的”能源值。这可以是任何大于 1.0 的值。 Artisan 可以检查打开的配置文件以确定与负载子选项卡上的事件相关联的每个负载的能源值。单击每个协议的 [...] 按钮以自动填充测量能源字段。预热和批次间的 Artisan 测量从配置文件开始到 CHARGE 进行。如果没有 CHARGE 事件，则测量是从配置文件的开始到结束。预热和批次间测量的值是相同的。确保不要使用相同的配置文件来输入这两个值。冷却能源是从 DROP 到轮廓结束测量的。如果没有 DROP 事件，则测量从 CHARGE 开始。如果没有 CHARGE 事件，则测量是从配置文件的开始到结束。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="66" />
        <source>To use the Artisan energy measurement feature you will need to record one or more profiles that include the protocol of interest.  For example, to measure the Pre-Heating energy, START recording when the roaster is turned on.  Let Artisan record the entire pre-heating procedure.  At the end of the pre-heating you can either STOP recording the profile or go forward with the roast.  The CHARGE event will mark the end of pre-heating when Artisan measures the pre-heat energy.  Similarly a Between Batches protocol can be recorded with START followed by a normal roast.  A Cooling protocol would be captured by not turning the Artisan recording OFF until the roaster is fully cooled.</source>
        <translation>要使用 Artisan 能源测量功能，您需要记录一个或多个包含感兴趣协议的配置文件。例如，要测量预热能源，请在打开烘焙机时开始记录。让 Artisan 记录整个预热过程。在预热结束时，您可以停止记录配置文件或继续烘焙。当 Artisan 测量预热能源时，CHARGE 事件将标志着预热结束。类似地，可以使用 START 记录“批次之间”协议，然后进行正常烘焙。通过在烘焙机完全冷却之前不关闭 Artisan 记录来捕获冷却协议。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="66" />
        <source>The Artisan measurements for Pre-Heating and Between Batches are made from the start of the profile until CHARGE.  If there is no CHARGE event the measurement is from the start to the end of profile.  The values measured for Pre-Heating and Between Batches are the same.  Be sure you do not use the same profile to enter both values.  The Cooling energy is measured from DROP to the end of the profile.  If there is no DROP event the measurement begins at CHARGE.  If there is no CHARGE event the measurement is from the start to the end of the profile.</source>
        <translation>预热和批次间的 Artisan 测量从配置文件开始到 CHARGE 进行。如果没有 CHARGE 事件，则测量是从配置文件的开始到结束。预热和批次间测量的值是相同的。确保不要使用相同的配置文件来输入这两个值。冷却能源是从 DROP 到轮廓结束测量的。如果没有 DROP 事件，则测量从 CHARGE 开始。如果没有 CHARGE 事件，则测量是从配置文件的开始到结束。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="70" />
        <source>Pre-Heating</source>
        <translation>预热</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="70" />
        <source>This row sets the values for pre-heating energy.  Percentage or measured values may be entered for each burner.  When a percentage is used the Duration field must be set.

Pre-Heating energy is applied only to the first batch of a roasting session.</source>
        <translation>此行设置预热能源的值。可以为每个燃烧器输入百分比或测量值。当使用百分比时，必须设置持续时间字段。

预热能源仅适用于烘焙过程的第一批。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="71" />
        <source>Between Batches</source>
        <translation>批次间</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="71" />
        <source>This row sets the values for between batches protocol for the roasting session.  Percentage or measured values may be entered for each burner.  When a percentage is used the Duration field must be set.

Between Batches energy is applied to each batch of the roasting session, except the first batch.  Tick the &amp;#39;Between Batches after Pre-Heating&amp;#39; box to apply Between Batches energies to the first batch of the session too.</source>
        <translation>此行设置烘焙会话的批次间规程的值。可为每个燃烧器输入百分比或测量值。当使用百分比时，必须设置持续时间字段。

批次间能源应用于每批次的烘焙，第一批次除外。勾选“预热后批次间”框也将批次之间的能源应用于第一批会话。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="72" />
        <source>Cooling</source>
        <translation>冷却</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="72" />
        <source>This row sets the values for the energy used for cooling.  Most common loads are motors and blowers that consume energy during the roaster cool down period.  Percentage or measured values may be entered for each burner.  When a percentage is used the Duration field must be set.

Pre-Heating energy is applied only to the first batch of a roasting session.</source>
        <translation>此行设置用于冷却的能源值。最常见的负载是在烘焙机冷却期间消耗能源的电机和鼓风机。可以为每个燃烧器输入百分比或测量值。当使用百分比时，必须设置持续时间字段。

预热能源仅适用于烘焙过程的第一批。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="73" />
        <source>Duration</source>
        <translation>持续时间</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="73" />
        <source>The length (mm:ss) of protocol.  It is used with a burner&amp;#39;s percentage setting to calculate the energy consumed  by that burner.  When a percentage entry is made for the burner, the Duration field must be set.</source>
        <translation>协议的长度 (mm:ss)。它与燃烧器的百分比设置一起使用，以计算该燃烧器消耗的能源。当为燃烧器输入百分比时，必须设置持续时间字段。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="74" />
        <source>Measured Energy or Output %</source>
        <translation>测量能源或输出 %</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="74" />
        <source>The value is either the measured energy for the protocol or the burner constant percentage setting for the length of the Duration field.</source>
        <translation>该值是协议的测量能源或持续时间字段长度的燃烧器常数百分比设置。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="75" />
        <source>Measure Profile [...]</source>
        <translation>测量配置文件 [...]</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="75" />
        <source>Energy is measured from the open profile for each load where an event is specified on the Loads tab.  Click OK to auto fill in the associated Measured Energy field.</source>
        <translation>能源是从在负载选项卡上指定事件的每个负载的打开配置文件中测量的。单击确定以自动填写相关的测量能源字段。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="76" />
        <source>Between Batches after Pre-Heating</source>
        <translation>预热后 批次间</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="76" />
        <source>This box should be ticked when a Between Batches protocol run is done after the Pre-heating and before the roast.</source>
        <translation>当在预热之后和烘焙之前完成批次间规程运行时，应勾选此框。</translation>
    </message>
    <message>
        <location filename="../help/energy_help.py" line="77" />
        <source>Stores the current settings on this sub-tab as defaults to be recalled later.  The default values will be stored when saving settings (Help&gt;Save Settings) to a file.  </source>
        <translation>将此子选项卡上的当前设置存储为默认设置，以便稍后调用。将设置（帮助&gt;保存设置）保存到文件时将存储默认值.  </translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="14" />
        <source>AUTOSAVE DIALOG</source>
        <translation>自动保存对话框</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="17" />
        <source>Dialog Field</source>
        <translation>对话框字段</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="18" />
        <source>Autosave [a]</source>
        <translation>自动保存 [a]</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="18" />
        <source>Turn Autosave ON or OFF.  When sampling, the keyboard &amp;#39;a&amp;#39; will save the profile at that moment.
NOTE: Files with the same file name will be silently overwritten.  Use ~currdatetime in the file name prefix to get unique file names.</source>
        <translation>打开或关闭自动保存。采样时，键盘 &amp;#39;a&amp;#39;将在那时保存配置文件。
注意：具有相同文件名的文件将被静默覆盖。在文件名前缀中使用 ~currdatetime 来获取唯一的文件名。</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="19" />
        <source>Add to recent file list</source>
        <translation>添加到最近的文件列表</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="19" />
        <source>When checked, Autosaved files will be added to the Files&gt;&gt; Open Recent files list.</source>
        <translation>选中后，自动保存的文件将添加到文件&gt;&gt;打开最近的文件列表中。</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="20" />
        <source>File Name Prefix</source>
        <translation>文件名前缀</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="20" />
        <source>Defines the file name to use for Autosave.  See the Autosave Fields section below.</source>
        <translation>定义用于自动保存的文件名。请参阅下面的自动保存字段部分。</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="21" />
        <source>Preview:</source>
        <translation>预览:</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="21" />
        <source>Shows an example of the file name based on the File Name Prefix field.
A &amp;#39;While Recording:&amp;#39; example will also be shown if the file name will be different when the scope is sampling.</source>
        <translation>显示基于文件名前缀字段的文件名示例。
A &amp;#39;在录音时：&amp;#39;如果在范围采样时文件名不同，也会显示示例。</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="24" />
        <location filename="../help/autosave_help.py" line="22" />
        <source>Path</source>
        <translation>路径</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="22" />
        <source>Where to store the Autosaved files.</source>
        <translation>存储自动保存文件的位置。</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="23" />
        <source>Save Also</source>
        <translation>另存为</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="23" />
        <source>Allows to save an additional file.  Choose the file type from the pull-down menu.</source>
        <translation>允许保存附加文件。从下拉菜单中选择文件类型。</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="24" />
        <source>Where to store the additional files.</source>
        <translation>存储附加文件的位置。</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="27" />
        <source>AUTOSAVE FIELDS</source>
        <translation>自动保存失败</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="31" />
        <source>The batch prefix set in Config&gt;Batch&gt;Prefix</source>
        <translation>批次路径设置在 配置&gt;批次&gt;路径 里</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="32" />
        <source>The current batch number</source>
        <translation>目前批次号</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="33" />
        <source>Same as "~batchprefix~batchnum"</source>
        <translation>类似于'~批次路径~批次号</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="34" />
        <source>The current batch position, or "Roast of the Day"</source>
        <translation>当前批次位置,或'烘焙日期'</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="35" />
        <source>Same as Batch field in Roast Properties
"~batchprefix~batchnum (~batchposition)"</source>
        <translation>与烘焙属性中的批次字段相同
“~batchprefix~batchnum (~batchposition)”</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="36" />
        <source>From Roast&gt;Properties&gt;Title</source>
        <translation>来自 烘焙&gt;属性&gt;标题</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="37" />
        <source>Replace “nn” with 10, 15, 20, 25, or 30 to show the first “nn” characters of the Beans field.
From Roast&gt;Properties&gt;Beans</source>
        <translation>将“nn”替换为 10、15、20、25 或 30 以显示 Beans 字段的第一个“nn”字符。
从烘焙&gt;属性&gt;豆子</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="38" />
        <source>The entire first line From Roast&gt;Properties&gt;Beans</source>
        <translation>整个第一行来自 烘焙&gt;属性&gt;豆名</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="39" />
        <source>Roast date in format yy-MM-dd</source>
        <translation>烘焙日期格式为 yy-MM-dd</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="40" />
        <source>Roast date in format yyyy-MM-dd</source>
        <translation>烘焙日期格式为 yyyy-MM-dd</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="41" />
        <source>Roast time in format hhmm</source>
        <translation>烘焙时间格式为 hhmm</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="42" />
        <source>Roast date and time in format yy-MM-dd_hhmm</source>
        <translation>烘焙日期和时间格式为 yy-MM-dd_hhmm</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="43" />
        <source>Roast date and time in format yyyy-MM-dd_hhmm</source>
        <translation>烘焙日期和时间格式为 yyyy-MM-dd_hhmm</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="44" />
        <source>Roast year in format yyyy</source>
        <translation>格式为 yyyy 的烘焙年份</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="45" />
        <source>Roast year in format yy</source>
        <translation>格式为 yy 的烘焙年份</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="46" />
        <source>Roast month in format MMM (localized)</source>
        <translation>MMM 格式的烘焙月（本地化）</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="47" />
        <source>Roast month in format MM</source>
        <translation>MM 格式的烘焙月份</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="48" />
        <source>Roast day in format ddd (localized)</source>
        <translation>ddd 格式的烘焙日（本地化）</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="49" />
        <source>Roast day in format dd</source>
        <translation>dd 格式的烘焙日</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="50" />
        <source>Roast hour in format hh</source>
        <translation>格式为 hh 的烘焙时间</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="51" />
        <source>Roast minute in format mm</source>
        <translation>烘焙分钟格式 mm</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="52" />
        <source>Current date and time with seconds in format yy-MM-dd_hhmmss. Not the same as roast time.</source>
        <translation>当前日期和时间，格式为 yy-MM-dd_hhmmss。不一样的烘焙时间.</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="53" />
        <source>From Roast&gt;Properties&gt;Operator</source>
        <translation>来自 烘焙&gt;属性&gt;烘焙师</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="54" />
        <source>From Roast&gt;Properties&gt;Organization</source>
        <translation>从 Roast&gt;Properties&gt;Organization</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="55" />
        <source>From Roast&gt;Properties&gt;Machine</source>
        <translation>从烘焙&gt;属性&gt;机器</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="56" />
        <source>From Roast&gt;Properties&gt;Weight Green</source>
        <translation>来自 Roast&gt;Properties&gt;Weight Green</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="57" />
        <source>From Roast&gt;Properties&gt;Weight Roasted</source>
        <translation>来自 Roast&gt;Properties&gt;Weight Roasted</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="58" />
        <source>From Roast&gt;Properties&gt;Weight</source>
        <translation>从烘焙&gt;属性&gt;重量</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="59" />
        <source>Calculated weight loss in percent (the  “-” sign is not shown, it can be added manually in front of the field if desired)</source>
        <translation>以百分比计算的重量损失（“-”号未显示，如果需要，可以在字段前手动添加）</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="60" />
        <source>From Roast&gt;Properties&gt;Volume Green</source>
        <translation>来自 Roast&gt;Properties&gt;Volume Green</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="61" />
        <source>From Roast&gt;Properties&gt;Volume Roasted</source>
        <translation>从 Roast&gt;Properties&gt;Volume Roasted</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="62" />
        <source>From Roast&gt;Properties&gt;Volume</source>
        <translation>从 Roast&gt;Properties&gt;Volume</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="63" />
        <source>Calculated volume gain in percent</source>
        <translation>以百分比计算的体积增益</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="64" />
        <source>From Roast&gt;Properties&gt;Density Green</source>
        <translation>来自 Roast&gt;Properties&gt;Density Green</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="65" />
        <source>From Roast&gt;Properties&gt;Density Roasted</source>
        <translation>来自 烘焙&gt;属性&gt;熟豆密度</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="66" />
        <source>From Roast&gt;Properties&gt;Density</source>
        <translation>从烘焙&gt;属性&gt;密度</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="67" />
        <source>Calculated density loss in percent (the  “-” sign is not shown, it can be added manually in front of the field if desired)</source>
        <translation>以百分比计算的密度损失（“-”号未显示，如果需要，可以在字段前手动添加）</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="68" />
        <source>From Roast&gt;Properties&gt;Moisture Green</source>
        <translation>从烘焙&gt;属性&gt;生豆水分含量</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="69" />
        <source>From Roast&gt;Properties&gt;Defects</source>
        <translation>烘焙&gt;特性&gt;缺陷</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="70" />
        <source>From Roast&gt;Properties&gt;Yield</source>
        <translation>烘焙&gt;特性&gt;产量</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="71" />
        <source>Calculated defects loss in percent (the  “-” sign is not shown, it can be added manually in front of the field if desired)</source>
        <translation>计算的缺陷损失百分比（“-”号未显示，如果需要，可以在字段前面手动添加）</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="72" />
        <source>Calculated total loss in percent (the  “-” sign is not shown, it can be added manually in front of the field if desired)</source>
        <translation>计算的总损失百分比（未显示“-”号，如果需要，可以在字段前面手动添加）</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="73" />
        <source>From Roast&gt;Properties&gt;Moisture Roasted</source>
        <translation>来自 烘焙&gt;属性&gt;熟豆水含量</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="74" />
        <source>Calculated moisture loss in percent (the  “-” sign is not shown, it can be added manually in front of the field if desired)</source>
        <translation>以百分比计算的水分损失（“-”号未显示，如果需要，可以在田地前面手动添加）</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="75" />
        <source>From Roast&gt;Properties&gt;Drum Speed</source>
        <translation>来自 Roast&gt;Properties&gt;Drum Speed</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="76" />
        <source>From Roast&gt;Properties&gt;Color Whole</source>
        <translation>来自 烘焙&gt;属性&gt;整豆色值</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="77" />
        <source>From Roast&gt;Properties&gt;Color Ground</source>
        <translation>来自 烘焙&gt;属性&gt;咖啡粉值</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="78" />
        <source>From Roast&gt;Properties&gt;Color System</source>
        <translation>来自 烘焙&gt;属性&gt;色值系统</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="79" />
        <source>From Roast&gt;Properties&gt;Screen Min</source>
        <translation>来自 烘焙&gt;属性&gt;豆目 最小</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="80" />
        <source>From Roast&gt;Properties&gt;Screen Max</source>
        <translation>来自 烘焙&gt;属性&gt;豆目 最大</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="81" />
        <source>From Roast&gt;Properties&gt;(Green) Beans Temperature</source>
        <translation>来自 烘焙&gt;属性&gt;生豆温度</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="82" />
        <source>From Roast&gt;Properties&gt;Ambient Temperature</source>
        <translation>来自 烘焙&gt;属性&gt;环境温度</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="83" />
        <source>From Roast&gt;Properties&gt;Ambient Humidity</source>
        <translation>来自 烘焙&gt;属性&gt;环境湿度</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="84" />
        <source>From Roast&gt;Properties&gt;Ambient Pressure</source>
        <translation>来自 烘焙&gt;属性&gt;环境气压</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="85" />
        <source>Calculated time from FCs to DROP in seconds</source>
        <translation>从 FC 到 DROP 的计算时间（以秒为单位）</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="86" />
        <source>Calculated time from FCs to DROP in min_secs</source>
        <translation>从 FC 到 DROP 的计算时间（以 min_secs 为单位）</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="87" />
        <source>From Profile Statistics - DTR (in percent)</source>
        <translation>来自曲线统计 - DTR(百分比)</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="88" />
        <source>From the Profile Statistics - AUC</source>
        <translation>来自曲线统计 - AUC</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="89" />
        <source>From the Profile Statistics - AUC Base</source>
        <translation>基准曲线下面积（AUC Base）</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="90" />
        <source>From Config&gt;Temperature - the current temperature mode C or F</source>
        <translation>从 配置&gt;温度单位 - 当前温度模式 C 或 F</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="91" />
        <source>From the Profile - ET at CHARGE</source>
        <translation>从个人资料 - ET at CHARGE</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="92" />
        <source>From the Profile - BT at CHARGE</source>
        <translation>来自个人资料 - BT at CHARGE</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="93" />
        <source>From the Profile - ET at FCs</source>
        <translation>来自个人资料 - FCs 的 ET</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="94" />
        <source>From the Profile -BT at FCs</source>
        <translation>来自 FCs 的简介 -BT</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="95" />
        <source>From the Profile - FCs time in seconds</source>
        <translation>从配置文件 - 以秒为单位的 FCs 时间</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="96" />
        <source>From the Profile - FCs time in min_secs</source>
        <translation>从配置文件 - 以 min_secs 为单位的 FCs 时间</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="97" />
        <source>From the Profile - ET at DROP</source>
        <translation>来自个人资料 - ET at DROP</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="98" />
        <source>From the Profile - BT at DROP</source>
        <translation>来自个人资料 - BT at DROP</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="99" />
        <source>From the Profile - DROP time in seconds</source>
        <translation>从配置文件 - 以秒为单位的 DROP 时间</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="100" />
        <source>From the Profile - DROP time in min_secs</source>
        <translation>来自配置文件 - 以 min_secs 为单位的 DROP 时间</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="101" />
        <source>From the Profile - BT temperature change from TP to DRY</source>
        <translation>从配置文件 - BT 温度从 TP 到 DRY 的变化</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="102" />
        <source>From the Profile - BT temperature change from DRY to FCs</source>
        <translation>从配置文件 - BT 温度从 DRY 到 FCs 的变化</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="103" />
        <source>From the Profile - BT temperature change from FCs to DROP</source>
        <translation>从配置文件 - BT 温度从 FC 到 DROP 的变化</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="104" />
        <source>Replace “nn” with 10, 15, 20, 25, or 30 to show the first “nn” characters of the Roasting Notes field.
From Roast&gt;Properties&gt;Roasting Notes</source>
        <translation>将“nn”替换为 10、15、20、25 或 30 以显示 Roasting Notes 字段的第一个“nn”字符。
来自 Roast&gt;Properties&gt;Roasting Notes</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="105" />
        <source>The entire first line From Roast&gt;Properties&gt;Roasting Notes</source>
        <translation>整个第一行从 Roast&gt;Properties&gt;Roasting Notes</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="106" />
        <source>Replace “nn” with 10, 15, 20, 25, or 30 to show the first “nn” characters of the Cupping Notes field.
From Roast&gt;Properties&gt;Cupping Notes</source>
        <translation>将“nn”替换为 10、15、20、25 或 30 以显示 Cupping Notes 字段的第一个“nn”字符。
从烘焙&gt;属性&gt;杯测笔记</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="107" />
        <source>The entire first line From Roast&gt;Properties&gt;Cupping Notes</source>
        <translation>整个第一行从 Roast&gt;Properties&gt;Cupping Notes</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="108" />
        <source>From the Profile Energy Use - Total energy used by the batch in BTU</source>
        <translation>来自 Profile Energy Use - BTU 中批次使用的总能源</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="109" />
        <source>From the Profile Energy Use - CO2 produced by the batch in g</source>
        <translation>来自 Profile Energy Use - 以 g 为单位的批次产生的 CO2</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="110" />
        <source>From the Profile Energy Use - Energy used during preheat in BTU</source>
        <translation>来自 Profile Energy Use - BTU 预热期间使用的能源</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="111" />
        <source>From the Profile Energy Use - CO2 produced during preheat in g</source>
        <translation>来自 Profile Energy Use - 在 g 中预热期间产生的 CO2</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="112" />
        <source>From the Profile Energy Use - Energy used during Between Batch Protocol in BTU</source>
        <translation>来自配置文件能源使用 - BTU 中批处理协议期间使用的能源</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="113" />
        <source>From the Profile Energy Use - CO2 produced during Between Batch Protocol in g</source>
        <translation>来自 Profile Energy Use - 在批次间规程期间产生的 CO2 in g</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="114" />
        <source>From the Profile Energy Use - Energy used from CHARGE to DROP in BTU</source>
        <translation>从 Profile Energy Use - BTU 中从 CHARGE 到 DROP 使用的能源</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="115" />
        <source>From the Profile Energy Use - CO2 produced from CHARGE to DROP in g</source>
        <translation>从 Profile Energy Use - CO2 产生的 CHARGE 到 DROP in g</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="116" />
        <source>From the Profile Energy Use - CO2 produced per kg of green beans in g</source>
        <translation>从简介能源使用 - 每公斤生豆产生的二氧化碳（以克为单位）</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="127" />
        <source>Data used to replace the fields in the Autosave File Name Prefix are pulled from the current Roast Properties.</source>
        <translation>用于替换自动保存文件名前缀中的字段的数据是从当前烘焙属性中提取的.</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="130" />
        <source>Autosave Field</source>
        <translation>自动保存字段</translation>
    </message>
    <message>
        <location filename="../help/autosave_help.py" line="130" />
        <source>Example File Name</source>
        <translation>示例文件名</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="14" />
        <source>SYMBOLIC VARIABLES</source>
        <translation>符号变量</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="18" />
        <source>Note: All symbolic variables are case sensitive!</source>
        <translation>注意：所有符号变量都区分大小写！</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="192" />
        <location filename="../help/symbolic_help.py" line="180" />
        <location filename="../help/symbolic_help.py" line="142" />
        <location filename="../help/symbolic_help.py" line="129" />
        <location filename="../help/symbolic_help.py" line="117" />
        <location filename="../help/symbolic_help.py" line="108" />
        <location filename="../help/symbolic_help.py" line="98" />
        <location filename="../help/symbolic_help.py" line="86" />
        <location filename="../help/symbolic_help.py" line="79" />
        <location filename="../help/symbolic_help.py" line="21" />
        <source>Symbol</source>
        <translation>象征</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="21" />
        <source>Can  shift?
(see below)</source>
        <translation>能转吗？
（见下文）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="22" />
        <source>Absolute time (seconds) from begin of recording (not only the time after CHARGE!)</source>
        <translation>从记录开始的绝对时间（秒）（不仅是 CHARGE 之后的时间！）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="52" />
        <location filename="../help/symbolic_help.py" line="51" />
        <location filename="../help/symbolic_help.py" line="50" />
        <location filename="../help/symbolic_help.py" line="49" />
        <location filename="../help/symbolic_help.py" line="37" />
        <location filename="../help/symbolic_help.py" line="36" />
        <location filename="../help/symbolic_help.py" line="35" />
        <location filename="../help/symbolic_help.py" line="34" />
        <location filename="../help/symbolic_help.py" line="33" />
        <location filename="../help/symbolic_help.py" line="32" />
        <location filename="../help/symbolic_help.py" line="31" />
        <location filename="../help/symbolic_help.py" line="30" />
        <location filename="../help/symbolic_help.py" line="29" />
        <location filename="../help/symbolic_help.py" line="28" />
        <location filename="../help/symbolic_help.py" line="27" />
        <location filename="../help/symbolic_help.py" line="26" />
        <location filename="../help/symbolic_help.py" line="25" />
        <location filename="../help/symbolic_help.py" line="23" />
        <location filename="../help/symbolic_help.py" line="22" />
        <source>Yes</source>
        <translation>是的</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="23" />
        <source>Absolute time (seconds) from begin of recording of the background profile</source>
        <translation>从背景曲线记录开端起的绝对时间(秒)</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="24" />
        <source>Current channel reading (not available in the Plotter)</source>
        <translation>当前通道读数（在绘图仪中不可用）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="27" />
        <source>Extra #1 T1 value</source>
        <translation>额外 #T1 值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="28" />
        <source>Extra #1 T2 value</source>
        <translation>额外 #1 T2 值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="29" />
        <source>Extra #2 T1 value</source>
        <translation>额外 #2 T1 值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="30" />
        <source>Extra #2 T2 value</source>
        <translation>额外 #2 T2 值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="43" />
        <location filename="../help/symbolic_help.py" line="37" />
        <location filename="../help/symbolic_help.py" line="31" />
        <source>...and so forth</source>
        <translation>...等等</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="32" />
        <source>ET background</source>
        <translation>ET背景曲线</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="33" />
        <source>BT background</source>
        <translation>BT背景曲线</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="34" />
        <source>ExtraBackground #1-A</source>
        <translation>额外背景 #1-A</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="35" />
        <source>ExtraBackground #1-B</source>
        <translation>额外背景 #1-B</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="36" />
        <source>ExtraBackground #2-A</source>
        <translation>额外背景 #1-A {2-?}</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="38" />
        <source>ET tare value</source>
        <translation>ET皮重值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="39" />
        <source>BT tare value</source>
        <translation>BT 皮重值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="40" />
        <source>Extra Device #1 channel 1 tare value</source>
        <translation>额外设备 #1 通道 1 皮重值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="41" />
        <source>Extra Device #1 channel 2 tare value</source>
        <translation>额外设备 #1 通道 2 皮重值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="42" />
        <source>Extra Device #2 channel 1 tare value</source>
        <translation>额外设备 #2 通道 1 皮重值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="44" />
        <source>Last event value of the first event type</source>
        <translation>第一个事件类型的最后一个事件值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="45" />
        <source>Last event value of the second event type</source>
        <translation>第二种事件类型的最后一个事件值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="46" />
        <source>Last event value of the third event type</source>
        <translation>第三个事件类型的最后一个事件值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="47" />
        <source>Last event value of the fourth event type</source>
        <translation>第四种事件类型的最后一个事件值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="49" />
        <source>ET rate of rise (smoothed)</source>
        <translation>ET RoR（平滑）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="50" />
        <source>BT rate of rise  (smoothed)</source>
        <translation>BT RoR（平滑）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="51" />
        <source>Background ET rate of rise  (smoothed)</source>
        <translation>背景ET RoR（平滑）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="52" />
        <source>Background BT rate of rise  (smoothed)</source>
        <translation>背景BT RoR（平滑）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="56" />
        <source>Note: Smoothing is normally applied to all Extra Devices.  Smoothing is not applied when an Extra Device symbolic equation includes a rate of rise variable (R1, R2, RB1 or RB2).  Rate of rise variables already have smoothing applied.</source>
        <translation>注意：所有附加设备通常都会应用平滑处理。当附加设备符号方程包含上升率变量（R1、R2、RB1 或 RB2）时，不会应用平滑处理。上升率变量已应用平滑处理。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="59" />
        <source>SHIFTED SYMBOLIC VARIABLES</source>
        <translation>移位符号变量</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="63" />
        <source>The symbolic variables t, b, Y&lt;n&gt;, B&lt;n&gt; and R&lt;n&gt; evaluate to the current value of a sequence of values that define a roast profile. To access earlier or later values one can apply a shift value.</source>
        <translation>符号变量 t、b、Y&lt;n&gt;、B&lt;n&gt; 和 R&lt;n&gt; 评估为定义烘焙配置文件的一系列值的当前值。要访问更早或更晚的值，可以应用移位值。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="63" />
        <source>
For example, while "Y2" returns the current bean temperature (BT), "Y2[-1]" returns the previous BT temperature and "Y2[-2]" the one before that. Formulas used in the Plotter are applied in sequence to all values, thus there "Y2" points to the current BT temperature processed, "Y2[-1]" the previous BT temperature processed and "Y2[+1]" the next BT temperature to be processed. A positive shift is only available in the Plotter, obviously not during recording.</source>
        <translation>
例如，“Y2”返回当前的咖啡豆温度 (BT)，“Y2[-1]”返回之前的 BT 温度，“Y2[-2]”返回之前的温度。绘图仪中使用的公式按顺序应用于所有值，因此“Y2”指向当前处理的 BT 温度，“Y2[-1]”表示处理的前一个 BT 温度，“Y2[+1]”表示下一个 BT 温度待处理。正向偏移仅在绘图仪中可用，显然在记录期间不可用。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="67" />
        <source>Time one index ahead (plotter only)</source>
        <translation>提前一个索引（仅绘图仪）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="68" />
        <source>Time three indexes delayed</source>
        <translation>三个指示器的延迟时间</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="69" />
        <source>ET value delayed by 2 indexes</source>
        <translation>ET值延迟2个指标</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="70" />
        <source>BT value index advanced by one index (plotter only)</source>
        <translation>BT 值指数增加一个指数（仅限绘图仪）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="71" />
        <source>ExtraBackground #1-B delayed 6 indexes</source>
        <translation>额外背景 #1-B 延迟6个指标</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="72" />
        <source>ExtraBackground #2-A advanced 2 indexes (plotter only)</source>
        <translation>ExtraBackground #2-A 高级 2 个索引（仅限绘图仪）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="73" />
        <source>ET rate of rise delayed two indexes</source>
        <translation>ET RoR 延迟了两个指标</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="76" />
        <source>INDEXED SYMBOLIC VARIABLES</source>
        <translation>索引符号变量</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="80" />
        <source>t, b, Y&lt;n&gt;, B&lt;n&gt; and R&lt;n&gt;</source>
        <translation>t、b、Y&lt;n&gt;、B&lt;n&gt; 和 R&lt;n&gt;</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="80" />
        <source>Previously recorded data assigned to the symbolic variables t, b, Y&lt;n&gt;, B&lt;n&gt; and R&lt;n&gt; can also directly accessed by index. "Y2{0}" evaluates to the first recorded bean temperature (BT) and "Y2{CHARGE}" to the bean temperature at CHARGE. Additionally, the symbolic variable b can be used to access the recording time at a certain index of the background profile. Thus "b{CHARGE}" returns the recording time at CHARGE of the background profile.</source>
        <translation>分配给符号变量 t、b、Y&lt;n&gt;、B&lt;n&gt; 和 R&lt;n&gt; 的先前记录的数据也可以通过索引直接访问。 “Y2{0}”计算为第一个记录的咖啡豆温度 (BT)，“Y2{CHARGE}”计算为 CHARGE 时的咖啡豆温度。此外，符号变量 b 可用于在背景配置文件的某个索引处访问记录时间。因此，“b{CHARGE}”返回背景配置文件的 CHARGE 记录时间。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="83" />
        <source>AXIS MAPPING</source>
        <translation>轴映射</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="87" />
        <source>Scaling factor from RoR to Temp axis. The range of the temperature scale divided by the range of the delta scale.</source>
        <translation>从 RoR 到 Temp 轴的比例因子。温标范围除以增量标度范围.</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="88" />
        <source>Offset from RoR to Temp axis.</source>
        <translation>从 RoR 到 Temp 轴的偏移量.</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="92" />
        <source>Note: RoR values r can be scaled to the temperature axis using a linear approximation of the form "r*k + o". As the variables k and o depend on the actual axis settings which can be changed by the user without triggering a recomputation, those variable are less useful for use in a recording, but useful in the Plotter to plot w.r.t. the RoR y-axis instead of the temperature y-axis.</source>
        <translation>注意：RoR 值 r 可以使用“r*k + o”形式的线性近似值缩放到温度轴。由于变量 k 和 o 取决于用户可以在不触发重新计算的情况下更改的实际轴设置，因此这些变量在记录中的用处不大，但在绘图仪中用于绘制 w.r.t. RoR y 轴而不是温度 y 轴。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="95" />
        <source>EVENT INDEX and TIME DELTA</source>
        <translation>事件索引和时间增量</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="99" />
        <source>Index of the corresponding event of the profile to retrieve time and values from the corresponding data structures. Evaluates to -1 if not set.</source>
        <translation>配置文件的相应事件的索引，用于从相应的数据结构中检索时间和值。如果未设置，则评估为 -1。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="100" />
        <source>Index of the corresponding event of the background profile to retrieve time and values from the corresponding data structures. Evaluates to -1 if not set.</source>
        <translation>后台配置文件的相应事件的索引，用于从相应的数据结构中检索时间和值。如果未设置，则评估为 -1。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="102" />
        <source>Time distance in seconds after the corresponding event. Thus dCHARGE is bound to the current roast time (after CHARGE) in seconds while t is bound to the time in seconds from the start of the recording.</source>
        <translation>相应事件后的时间距离（以秒为单位）。因此，dCHARGE 绑定到当前烘焙时间（CHARGE 之后），以秒为单位，而 t 绑定到从录制开始开始的时间（以秒为单位）。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="105" />
        <source>AREA UNDER THE CURVE (AUC)</source>
        <translation>曲线下面积 (AUC)</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="109" />
        <source>AUC base temperature (could be from the selected event, if set)</source>
        <translation>AUC 基础温度（可能来自所选事件，如果已设置）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="110" />
        <source>AUC target value (could be from the background profile, if set)</source>
        <translation>AUC目标值(如设置，可源自背景曲线)</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="111" />
        <source>the current AUC value. -1 if none available.</source>
        <translation>当前的 AUC 值。 -1 如果没有可用。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="114" />
        <source>PREDICTIONS</source>
        <translation>预测</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="118" />
        <source>Prediction of the time distance to the DRY event based on the current RoR. Evaluates to -1 on negative RoR and to 0 if the DRY event is already set.</source>
        <translation>基于当前 RoR 预测到 DRY 事件的时间距离。如果已经设置了 DRY 事件，则在负 RoR 上评估为 -1，并评估为 0。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="119" />
        <source>Same as pDRY, just for the FCs event.</source>
        <translation>与 pDRY 相同，仅适用于 FCs 事件。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="123" />
        <source>Note: The same rules as for the corresponding PhasesLCDs apply to pDRY and pFCs:</source>
        <translation>注意：与对应的 PhasesLCD 相同的规则适用于 pDRY 和 pFC：</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="123" />
        <source>
If there is no background profile the DRY or FCs bean temperature used for the prediction is taken from the Config&gt;Phases setup.</source>
        <translation>
如果没有背景配置文件，用于预测的DRY或FCs豆温取自Config&gt;Phases设置.</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="123" />
        <source>
If there is a background profile and there is DRY or FCs event in the background profile, the DRY or FCs bean temperature used for the prediction is taken from the background profile.</source>
        <translation>
如果存在背景配置文件并且背景配置文件中存在 DRY 或 FCs 事件，则用于预测的 DRY 或 FCs 豆子温度取自背景配置文件。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="123" />
        <source>
Exception to the above for DRY only: if AutoDRY is checked the DRY temperature used for the prediction is taken from the Config&gt;Phases setup.  This does not apply to FCs and AutoFCs.</source>
        <translation>
上述仅适用于 DRY 的例外情况：如果选中 AutoDRY，则用于预测的 DRY 温度取自 Config&gt;Phases 设置。这不适用于 FC 和 AutoFC。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="123" />
        <source>
The prediction value is the calculated time in seconds to reach the DRY or FCs temperature.</source>
        <translation>
预测值是达到 DRY 或 FCs 温度的计算时间（以秒为单位）。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="126" />
        <source>AMBIENT</source>
        <translation>周围</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="130" />
        <source>ambient temperature (default 0)</source>
        <translation>环境温度（默认 0）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="131" />
        <source>ambient humidity (default 0)</source>
        <translation>环境湿度（默认 0）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="132" />
        <source>ambient pressure (default 0)</source>
        <translation>环境压力（默认 0）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="136" />
        <source>Note: The data is (re-)sampled some seconds after the start of recording</source>
        <translation>注意：数据在记录开始几秒钟后（重新）采样</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="139" />
        <source>ROAST PROPERTIES</source>
        <translation>烘焙特性</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="143" />
        <source>batch size (g)</source>
        <translation>批量大小（克）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="144" />
        <source>green moisture (%)</source>
        <translation>生豆含水率（%）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="145" />
        <source>temperature unit (Celsius: 0, Fahrenheit: 1)</source>
        <translation>温度单位（摄氏度：0，华氏度：1）</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="148" />
        <source>EXPRESSIONS</source>
        <translation>表达式</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="151" />
        <source>Expression</source>
        <translation>表达</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="152" />
        <source>Conditional. Evaluates to the value of the expression &lt;true-expr&gt; if the condition &lt;cond&gt; holds, otherwise to the value of the expression &lt;false-expr&gt;. The rules of Python are applied to decide if a value holds or not. Thus the boolean values "True" and "False" have the obvious semantic. Any number unequal to 0 evaluates to True and 0 evaluates to False. The value "None" is also evaluated to False.</source>
        <translation>有条件的。如果条件 &lt;cond&gt; 成立，则计算表达式 &lt;true-expr&gt; 的值，否则计算表达式 &lt;false-expr&gt; 的值。 Python 的规则用于决定一个值是否成立。因此布尔值“True”和“False”具有明显的语义。任何不等于 0 的数字都计算为 True，0 计算为 False。值“None”也被评估为 False。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="155" />
        <source>MATHEMATICAL FORMULAS</source>
        <translation>数学公式</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="158" />
        <source>Formula</source>
        <translation>公式</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="159" />
        <source>Return the absolute value of x.</source>
        <translation>返回 x 的绝对值。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="160" />
        <source>Return the arc cosine (measured in radians) of x.</source>
        <translation>返回 x 的反余弦值（以弧度为单位）。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="161" />
        <source>Return the arc sine (measured in radians) of x.</source>
        <translation>返回 x 的反正弦值（以弧度为单位）。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="162" />
        <source>Return the arc tangent (measured in radians) of x.</source>
        <translation>返回 x 的反正切值（以弧度为单位）。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="163" />
        <source>Return the cosine of x (measured in radians).</source>
        <translation>返回 x 的余弦值（x 以弧度为单位）。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="164" />
        <source>Convert angle x from radians to degrees.</source>
        <translation>将角度 x 从弧度转换为度。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="165" />
        <source>Return e raised to the power of x.</source>
        <translation>返回 e 的 x 次方。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="166" />
        <source>Return the logarithm of x to the given base.</source>
        <translation>将 x 的对数返回到给定的底数。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="167" />
        <source>Return the minimum of the given values.</source>
        <translation>返回给定值的最小值。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="168" />
        <source>Return the maximum of the given values.</source>
        <translation>返回给定值的最大值。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="169" />
        <source>Return x**y (x to the power of y).</source>
        <translation>返回 x 的 y 次方（x 的 y 次幂）。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="170" />
        <source>Convert angle x from degrees to radians.</source>
        <translation>将角度 x 从度转换为弧度。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="171" />
        <source>Return the sine of x (measured in radians).</source>
        <translation>返回 x 的正弦值（x 以弧度为单位）。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="172" />
        <source>Return the square root of x.</source>
        <translation>返回 x 的平方根。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="173" />
        <source>Return the tangent of x (measured in radians).</source>
        <translation>返回 x 的正切值（以弧度为单位）。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="174" />
        <source>Return 1 if the bit n of value x (interpreted as integer) is set, otherwise 0.</source>
        <translation>如果值 x（解释为整数）的位 n 已设置，则返回 1，则返回 0。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="177" />
        <source>MATHEMATICAL CONSTANTS</source>
        <translation>数学常数</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="180" />
        <source>Value</source>
        <translation>数值</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="185" />
        <source>PLOTTER EXTENSIONS</source>
        <translation>绘图仪扩展</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="189" />
        <source>Note:  This section applies only to the Plotter
Using math formulas in the plotter also allows to use the symbolic variables P and F (see Signals, Symbolic Assignments and the Plotter).</source>
        <translation>注意：本节仅适用于绘图仪
在绘图仪中使用数学公式还允许使用符号变量 P 和 F（请参阅信号、符号分配和绘图仪）。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="193" />
        <source>The variables P1,..,P9 represent the results from plot #1,..,#9. You can perform calculations in a later plot on variables of an earlier plot. That way, the plot variables P1,..,P9 allow the cascading or intermediate results. For example, plot #3 can refer to the results of plot 1 using the variable P1.</source>
        <translation>变量 P1,..,P9 代表绘图 #1,..,#9 的结果。您可以在稍后的绘图中对较早绘图的变量执行计算。这样，绘图变量 P1,..,P9 允许级联或中间结果。例如，情节 #3 可以使用变量 P1 引用情节 1 的结果。</translation>
    </message>
    <message>
        <location filename="../help/symbolic_help.py" line="194" />
        <source>F1 refers to the previous result of the actual formula to realize a feedback loop. This is useful in filter designs. Similarly, F2 refers to the second previous result etc.</source>
        <translation>F1参考实际公式的前一个结果来实现一个反馈循环。这在滤波器设计中很有用。同样，F2 指的是第二个先前的结果等。</translation>
    </message>
    <message>
        <source>show/hide slider per event type n from {1,2,3,4}</source>
        <translation type="vanished">显示/隐藏每个事件类型 n 的滑块（来自 {1,2,3,4}）</translation>
    </message>
    <message>
        <source>Toggle Playback Events
(Expert and Standard modes)</source>
        <translation type="vanished">切换播放事件
（专家和标准模式）</translation>
    </message>
    <message>
        <source>sets playback mode to 0: off, 1: time, 2: BT, 3: ET</source>
        <translation type="vanished">将播放模式设置为 0：关闭，1：时间，2：BT，3：ET</translation>
    </message>
    <message>
        <source>Current date and time with seconds in format yy-MM-dd_hhmmss.  Not the same as roast time</source>
        <translation type="vanished">当前日期和时间，格式为 yy-MM-dd_hhmmss。不一样的烘焙时间</translation>
    </message>
    <message>
        <source>Data used to replace the fields in the Autosave File Name Prefix are pulled from the current Roast Properties.  </source>
        <translation type="vanished">用于替换自动保存文件名前缀中的字段的数据是从当前烘焙属性中提取的.  </translation>
    </message>
    <message>
        <source>Scaling factor from RoR to Temp axis. The range of the temperature scale divided by the range of the delta scale. </source>
        <translation type="vanished">从 RoR 到 Temp 轴的比例因子。温标范围除以增量标度范围. </translation>
    </message>
    <message>
        <source>Offset from RoR to Temp axis. </source>
        <translation type="vanished">从 RoR 到 Temp 轴的偏移量. </translation>
    </message>
    <message>
        <source>Commands for alarms with an action go here.  Anything after a &amp;#39;#&amp;#39; character is considered a comment and is ignored when processing the alarm.  </source>
        <translation type="vanished">带有操作的警报命令放在此处。'#'字符后的任何内容被视为注释，在处理警报时将被忽略.  </translation>
    </message>
    <message>
        <source>Toggle Full Screen Mode                                                                                                                                             </source>
        <translation type="vanished">切换全屏模式</translation>
    </message>
    <message>
        <source>write 16bit BCD encoded value to register of device with DeviceID </source>
        <translation type="vanished">将 16 位 BCD 编码值写入具有 DeviceID 的设备寄存器</translation>
    </message>
    <message>
        <source>Assumptions:  The event value is 50.  In the case of Gas the value 50 corresponds to either 5.0kPh or 50%.  
For a sensory milestone (see notes above) the value 50 corresponds to the "Hay" aroma. </source>
        <translation type="vanished">假设：事件值为 50。在气体的情况下，值 50 对应于 5.0kPh 或 50%。
对于感官里程碑（见上文注释），值 50 对应于“干草”香气.</translation>
    </message>
    <message>
        <source>Artisan allows the direct reading of 2 energy meters to support the use of measured energy consumption values in place of estimated values defined by the Loads. These energy meters could measure gas or electricity. As an energy meter the instantaneous power reading must be accumulated over a period of time.  Energy readings are typically in kWh or BTU, though other units are supported.  Artisan will use the Meter reading at the start of recording and end of recording to calculate energy consumption for the roast batch.  Intermediate reads at major roast events are also used in presenting phase energy consumption.  </source>
        <translation type="vanished">Artisan 允许直接读取 2 个能源表，以支持使用测量的能耗值代替负载定义的估算值。这些能源表可以测量天然气或电力。作为能源表，瞬时功率读数必须在一段时间内累积。能源读数通常以 kWh 或 BTU 为单位，但也支持其他单位。Artisan 将使用记录开始和记录结束时的仪表读数来计算烘焙批次的能耗。主要烘焙事件的中间读数也用于呈现阶段能耗.  </translation>
    </message>
    <message>
        <source>Energy meter data must be recorded in an Extra Device (Config&gt;&gt; Devices&gt;&gt; Extra devices tab).  The Extra Device is then used as the Source for the meter in the Energy tab.  Connectivity to the meter is typically via MODBUS. Some devices, like the YoctoWatt, have direct connection support in Artisan.  The data recorded in the Extra Device must be scaled to one of the units supported in the Energy tab such as kWh, BTU, kJ, kCal or therms (thm).  For instance, an electricity meter that returns energy readings in Wh that must be scaled to kWh buy using the symbolic equation "x/1000". </source>
        <translation type="vanished">电能表数据必须记录在附加设备中（配置&gt;&gt;设备&gt;&gt;附加设备选项卡）。然后，附加设备将用作电能选项卡中电能表的来源。通常通过 MODBUS 连接电能表。某些设备（如 YoctoWatt）在 Artisan 中支持直接连接。附加设备中记录的数据必须缩放为电能选项卡中支持的单位之一，例如 kWh、BTU、kJ、kCal 或 therms (thm)。例如，返回以 Wh 为单位的能源读数的电能表必须使用符号方程“x/1000”缩放为 kWh.</translation>
    </message>
    <message>
        <source>This is the power rating of the load  Choose the units in the next column.  </source>
        <translation type="vanished">这是负载的额定功率 选择下一栏中的单位.</translation>
    </message>
    <message>
        <source>Current date and time with seconds in format yy-MM-dd_hhmmss.  Not the same as roast time. </source>
        <translation type="vanished">当前日期和时间，格式为 yy-MM-dd_hhmmss。不一样的烘焙时间. </translation>
    </message>
    <message>
        <source>From Config&gt;Temperature - the current temperature mode C or F.  </source>
        <translation type="vanished">从 Config&gt;Temperature - 当前温度模式 C 或 F.  </translation>
    </message>
    <message>
        <source>Load alarms</source>
        <translation type="vanished">载入警报</translation>
    </message>
    <message>
        <source>Changes Event Button Palettes</source>
        <translation type="vanished">更改事件按钮面板</translation>
    </message>
    <message>
        <source>Application ScreenShot</source>
        <translation type="vanished">应用程序截图</translation>
    </message>
    <message>
        <source>Desktop ScreenShot</source>
        <translation type="vanished">桌面截图</translation>
    </message>
    <message>
        <source>Simulator</source>
        <translation type="vanished">模拟器</translation>
    </message>
    <message>
        <source>Graph/Simulator</source>
        <translation type="vanished">图形/模拟器</translation>
    </message>
    <message>
        <source>Config</source>
        <translation type="vanished">配置</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="vanished">工具</translation>
    </message>
    <message>
        <source>Change roast event key focus</source>
        <translation type="vanished">更改烘焙事件的关键焦点</translation>
    </message>
    <message>
        <source>Shows/Hides Mini Event editor (on recording)</source>
        <translation type="vanished">显示/隐藏迷你事件编辑器（录制时）</translation>
    </message>
    <message>
        <source>Inc/dec PID lookahead</source>
        <translation type="vanished">Inc/dec PID 前瞻</translation>
    </message>
    <message>
        <source>Inc/dec graph resolution</source>
        <translation type="vanished">Inc/dec 图形分辨率</translation>
    </message>
    <message>
        <source>Double Click on Background Profile Title</source>
        <translation type="vanished">双击背景配置文件标题</translation>
    </message>
    <message>
        <source>In  OFF state this changes the Artisan Settings, in ON/START states the change is temporary until OFF state</source>
        <translation type="vanished">在 OFF 状态下，这会更改 Artisan 设置，在 ON/START 状态下，更改是暂时的，直到 OFF 状态</translation>
    </message>
    <message>
        <source>Device = &lt;all others&gt;, Control enabled in Config&gt;&gt; Device</source>
        <translation type="vanished">设备 = &lt;所有其他&gt;，在配置中启用控制&gt;&gt;设备</translation>
    </message>
    <message>
        <source>Requires Keyboard Control enabled in Config&gt;&gt; Events
Keyboard Shortcuts must be turned off (ENTER)</source>
        <translation type="vanished">需要在配置 &gt;&gt; 事件中启用键盘控制
必须关闭键盘快捷键 (ENTER)</translation>
    </message>
    <message>
        <source>Requires Keyboard Control enabled in Config&gt;&gt; Events
Keyboard Shortcuts must be disabled (ENTER)</source>
        <translation type="vanished">需要在配置 &gt;&gt; 事件中启用键盘控制
必须禁用键盘快捷键 (ENTER)</translation>
    </message>
    <message>
        <source>Simulator speed may be changd while paused (hold shift  (1x), OPTION/ALT (2x) or COMMAND/CTRL (4x) on restart).</source>
        <translation type="vanished">模拟器速度可以在暂停时更改（重新启动时按住 Shift (1x)、OPTION/ALT (2x) 或 COMMAND/CTRL (4x)）。</translation>
    </message>
    <message>
        <source>&lt;button number&gt;</source>
        <translation type="vanished">&lt;按钮编号&gt;</translation>
    </message>
    <message>
        <source>triggers the button, the button number comes from the Events Buttons configuration</source>
        <translation type="vanished">触发按钮，按钮编号来自Events Buttons配置</translation>
    </message>
    <message>
        <source>sets the PID lookahead</source>
        <translation type="vanished">设置 PID 前瞻</translation>
    </message>
</context><context>
    <name>Label</name>
    <message>
        <location filename="../artisanlib/events.py" line="3846" />
        <location filename="../artisanlib/events.py" line="1035" />
        <location filename="../artisanlib/events.py" line="769" />
        <location filename="../artisanlib/pid_dialogs.py" line="550" />
        <location filename="../artisanlib/pid_dialogs.py" line="489" />
        <location filename="../artisanlib/pid_dialogs.py" line="340" />
        <location filename="../artisanlib/axis.py" line="151" />
        <location filename="../artisanlib/axis.py" line="79" />
        <location filename="../artisanlib/axis.py" line="77" />
        <location filename="../artisanlib/axis.py" line="75" />
        <source>Max</source>
        <translation>最大</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="3845" />
        <location filename="../artisanlib/events.py" line="1033" />
        <location filename="../artisanlib/events.py" line="767" />
        <location filename="../artisanlib/pid_dialogs.py" line="542" />
        <location filename="../artisanlib/pid_dialogs.py" line="480" />
        <location filename="../artisanlib/pid_dialogs.py" line="339" />
        <location filename="../artisanlib/axis.py" line="160" />
        <location filename="../artisanlib/axis.py" line="80" />
        <location filename="../artisanlib/axis.py" line="78" />
        <location filename="../artisanlib/axis.py" line="76" />
        <source>Min</source>
        <translation>最小</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="81" />
        <source>100% Event Step</source>
        <translation>100% 事件阶段</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="160" />
        <source>RECORD</source>
        <translation>记录</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1037" />
        <location filename="../artisanlib/events.py" line="773" />
        <location filename="../artisanlib/axis.py" line="266" />
        <location filename="../artisanlib/axis.py" line="256" />
        <location filename="../artisanlib/axis.py" line="207" />
        <source>Step</source>
        <translation>步长</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="711" />
        <location filename="../artisanlib/events.py" line="337" />
        <location filename="../artisanlib/axis.py" line="292" />
        <source>Style</source>
        <translation>风格</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="877" />
        <location filename="../artisanlib/axis.py" line="305" />
        <source>Width</source>
        <translation>宽度</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="110" />
        <location filename="../artisanlib/axis.py" line="312" />
        <source>Opaqueness</source>
        <translation>不透明度</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="923" />
        <location filename="../artisanlib/wheels.py" line="63" />
        <source>Ratio</source>
        <translation>纵横比</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6249" />
        <location filename="../artisanlib/main.py" line="6146" />
        <location filename="../artisanlib/wheels.py" line="70" />
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="77" />
        <source>Edge</source>
        <translation>边缘</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="874" />
        <location filename="../artisanlib/wheels.py" line="83" />
        <source>Line</source>
        <translation>线条</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="95" />
        <source>Color pattern</source>
        <translation>颜色图案</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="447" />
        <source> dg</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19107" />
        <location filename="../artisanlib/canvas.py" line="19097" />
        <location filename="../artisanlib/canvas.py" line="9592" />
        <location filename="../artisanlib/canvas.py" line="9536" />
        <location filename="../artisanlib/main.py" line="18758" />
        <location filename="../artisanlib/main.py" line="6191" />
        <location filename="../artisanlib/main.py" line="6185" />
        <location filename="../artisanlib/main.py" line="6161" />
        <location filename="../artisanlib/main.py" line="6137" />
        <location filename="../artisanlib/main.py" line="6131" />
        <location filename="../artisanlib/main.py" line="3724" />
        <location filename="../artisanlib/main.py" line="3415" />
        <location filename="../artisanlib/main.py" line="3405" />
        <location filename="../artisanlib/curves.py" line="2243" />
        <location filename="../artisanlib/curves.py" line="1581" />
        <location filename="../artisanlib/curves.py" line="1343" />
        <location filename="../artisanlib/curves.py" line="550" />
        <location filename="../artisanlib/curves.py" line="513" />
        <location filename="../artisanlib/curves.py" line="450" />
        <location filename="../artisanlib/curves.py" line="430" />
        <location filename="../artisanlib/curves.py" line="342" />
        <location filename="../artisanlib/designer.py" line="219" />
        <location filename="../artisanlib/designer.py" line="74" />
        <location filename="../artisanlib/events.py" line="293" />
        <location filename="../artisanlib/events.py" line="293" />
        <location filename="../artisanlib/events.py" line="290" />
        <location filename="../artisanlib/events.py" line="288" />
        <location filename="../artisanlib/comm.py" line="188" />
        <location filename="../artisanlib/comparator.py" line="845" />
        <source>BT</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19104" />
        <location filename="../artisanlib/canvas.py" line="19093" />
        <location filename="../artisanlib/canvas.py" line="9563" />
        <location filename="../artisanlib/canvas.py" line="9513" />
        <location filename="../artisanlib/main.py" line="18751" />
        <location filename="../artisanlib/main.py" line="6188" />
        <location filename="../artisanlib/main.py" line="6182" />
        <location filename="../artisanlib/main.py" line="6158" />
        <location filename="../artisanlib/main.py" line="6140" />
        <location filename="../artisanlib/main.py" line="6134" />
        <location filename="../artisanlib/main.py" line="3723" />
        <location filename="../artisanlib/main.py" line="3410" />
        <location filename="../artisanlib/main.py" line="3400" />
        <location filename="../artisanlib/curves.py" line="2238" />
        <location filename="../artisanlib/curves.py" line="1590" />
        <location filename="../artisanlib/curves.py" line="1340" />
        <location filename="../artisanlib/curves.py" line="549" />
        <location filename="../artisanlib/curves.py" line="507" />
        <location filename="../artisanlib/curves.py" line="449" />
        <location filename="../artisanlib/curves.py" line="430" />
        <location filename="../artisanlib/curves.py" line="337" />
        <location filename="../artisanlib/designer.py" line="218" />
        <location filename="../artisanlib/designer.py" line="76" />
        <location filename="../artisanlib/events.py" line="632" />
        <location filename="../artisanlib/events.py" line="293" />
        <location filename="../artisanlib/comparator.py" line="861" />
        <source>ET</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comparator.py" line="893" />
        <location filename="../artisanlib/comparator.py" line="876" />
        <source>Events</source>
        <translation>事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/comparator.py" line="1008" />
        <source>Align</source>
        <translation>对齐</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19460" />
        <location filename="../artisanlib/canvas.py" line="15343" />
        <location filename="../artisanlib/canvas.py" line="15277" />
        <location filename="../artisanlib/canvas.py" line="13021" />
        <location filename="../artisanlib/canvas.py" line="12700" />
        <location filename="../artisanlib/canvas.py" line="11194" />
        <location filename="../artisanlib/canvas.py" line="8937" />
        <location filename="../artisanlib/canvas.py" line="8932" />
        <location filename="../artisanlib/canvas.py" line="4431" />
        <location filename="../artisanlib/canvas.py" line="1421" />
        <location filename="../artisanlib/transposer.py" line="1197" />
        <location filename="../artisanlib/devices.py" line="1170" />
        <location filename="../artisanlib/alarms.py" line="912" />
        <location filename="../artisanlib/alarms.py" line="846" />
        <location filename="../artisanlib/statistics.py" line="97" />
        <location filename="../artisanlib/curves.py" line="2124" />
        <location filename="../artisanlib/designer.py" line="628" />
        <location filename="../artisanlib/designer.py" line="341" />
        <location filename="../artisanlib/designer.py" line="44" />
        <location filename="../artisanlib/roast_properties.py" line="4455" />
        <location filename="../artisanlib/roast_properties.py" line="657" />
        <location filename="../artisanlib/background.py" line="1060" />
        <location filename="../artisanlib/background.py" line="96" />
        <location filename="../artisanlib/ports.py" line="1351" />
        <location filename="../artisanlib/events.py" line="1306" />
        <location filename="../artisanlib/events.py" line="594" />
        <location filename="../artisanlib/events.py" line="583" />
        <location filename="../artisanlib/events.py" line="579" />
        <location filename="../artisanlib/events.py" line="576" />
        <location filename="../artisanlib/events.py" line="573" />
        <location filename="../artisanlib/pid_dialogs.py" line="841" />
        <location filename="../artisanlib/comparator.py" line="1010" />
        <source>CHARGE</source>
        <translation>投豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="8246" />
        <location filename="../artisanlib/main.py" line="8240" />
        <location filename="../artisanlib/main.py" line="8073" />
        <location filename="../artisanlib/main.py" line="8041" />
        <location filename="../artisanlib/main.py" line="3831" />
        <location filename="../artisanlib/statistics.py" line="98" />
        <location filename="../artisanlib/events.py" line="632" />
        <location filename="../artisanlib/events.py" line="623" />
        <location filename="../artisanlib/comparator.py" line="1011" />
        <source>TP</source>
        <translation>回温点</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="11196" />
        <location filename="../artisanlib/canvas.py" line="1422" />
        <location filename="../artisanlib/devices.py" line="1171" />
        <location filename="../artisanlib/main.py" line="8247" />
        <location filename="../artisanlib/main.py" line="8133" />
        <location filename="../artisanlib/main.py" line="8131" />
        <location filename="../artisanlib/main.py" line="8119" />
        <location filename="../artisanlib/main.py" line="8098" />
        <location filename="../artisanlib/main.py" line="3849" />
        <location filename="../artisanlib/background.py" line="97" />
        <location filename="../artisanlib/ports.py" line="1416" />
        <location filename="../artisanlib/comparator.py" line="1012" />
        <source>DRY</source>
        <translation>脱水</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="1423" />
        <location filename="../artisanlib/devices.py" line="1172" />
        <location filename="../artisanlib/main.py" line="8248" />
        <location filename="../artisanlib/main.py" line="8211" />
        <location filename="../artisanlib/main.py" line="8207" />
        <location filename="../artisanlib/main.py" line="8203" />
        <location filename="../artisanlib/main.py" line="8184" />
        <location filename="../artisanlib/main.py" line="8168" />
        <location filename="../artisanlib/main.py" line="8018" />
        <location filename="../artisanlib/main.py" line="8009" />
        <location filename="../artisanlib/main.py" line="3867" />
        <location filename="../artisanlib/background.py" line="98" />
        <location filename="../artisanlib/ports.py" line="1418" />
        <location filename="../artisanlib/comparator.py" line="1013" />
        <source>FCs</source>
        <translation>第一次爆裂</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="1424" />
        <location filename="../artisanlib/devices.py" line="1173" />
        <location filename="../artisanlib/background.py" line="99" />
        <location filename="../artisanlib/ports.py" line="1420" />
        <location filename="../artisanlib/comparator.py" line="1014" />
        <source>FCe</source>
        <translation>一爆结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="1425" />
        <location filename="../artisanlib/devices.py" line="1174" />
        <location filename="../artisanlib/background.py" line="100" />
        <location filename="../artisanlib/ports.py" line="1422" />
        <location filename="../artisanlib/comparator.py" line="1015" />
        <source>SCs</source>
        <translation>第二次爆裂</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="1426" />
        <location filename="../artisanlib/devices.py" line="1175" />
        <location filename="../artisanlib/background.py" line="101" />
        <location filename="../artisanlib/ports.py" line="1424" />
        <location filename="../artisanlib/comparator.py" line="1016" />
        <source>SCe</source>
        <translation>二爆结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19478" />
        <location filename="../artisanlib/canvas.py" line="12701" />
        <location filename="../artisanlib/canvas.py" line="11201" />
        <location filename="../artisanlib/canvas.py" line="4437" />
        <location filename="../artisanlib/canvas.py" line="1427" />
        <location filename="../artisanlib/transposer.py" line="1201" />
        <location filename="../artisanlib/transposer.py" line="1130" />
        <location filename="../artisanlib/devices.py" line="1176" />
        <location filename="../artisanlib/alarms.py" line="909" />
        <location filename="../artisanlib/alarms.py" line="853" />
        <location filename="../artisanlib/curves.py" line="2131" />
        <location filename="../artisanlib/designer.py" line="634" />
        <location filename="../artisanlib/designer.py" line="347" />
        <location filename="../artisanlib/designer.py" line="57" />
        <location filename="../artisanlib/roast_properties.py" line="4473" />
        <location filename="../artisanlib/roast_properties.py" line="740" />
        <location filename="../artisanlib/background.py" line="1078" />
        <location filename="../artisanlib/background.py" line="102" />
        <location filename="../artisanlib/ports.py" line="1353" />
        <location filename="../artisanlib/events.py" line="1366" />
        <location filename="../artisanlib/events.py" line="632" />
        <location filename="../artisanlib/events.py" line="604" />
        <location filename="../artisanlib/events.py" line="601" />
        <location filename="../artisanlib/pid_dialogs.py" line="838" />
        <location filename="../artisanlib/comparator.py" line="1017" />
        <source>DROP</source>
        <translation>排豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/comparator.py" line="1322" />
        <location filename="../artisanlib/comparator.py" line="1204" />
        <source>/min</source>
        <translation>/分钟</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26472" />
        <location filename="../artisanlib/main.py" line="26471" />
        <location filename="../artisanlib/main.py" line="26470" />
        <location filename="../artisanlib/ports.py" line="1137" />
        <location filename="../artisanlib/ports.py" line="672" />
        <location filename="../artisanlib/events.py" line="1386" />
        <location filename="../artisanlib/comparator.py" line="1560" />
        <source>ON</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23100" />
        <location filename="../artisanlib/main.py" line="21756" />
        <location filename="../artisanlib/main.py" line="6173" />
        <location filename="../artisanlib/statistics.py" line="196" />
        <location filename="../artisanlib/roast_properties.py" line="830" />
        <location filename="../artisanlib/comparator.py" line="1561" />
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="162" />
        <source>Scheduling</source>
        <translation>增益调度</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="165" />
        <source>PV</source>
        <translation>PV</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="8473" />
        <location filename="../artisanlib/main.py" line="4140" />
        <location filename="../artisanlib/ports.py" line="1051" />
        <location filename="../artisanlib/ports.py" line="587" />
        <location filename="../artisanlib/events.py" line="778" />
        <location filename="../artisanlib/pid_dialogs.py" line="4763" />
        <location filename="../artisanlib/pid_dialogs.py" line="437" />
        <location filename="../artisanlib/pid_dialogs.py" line="168" />
        <source>SV</source>
        <translation>SV</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="233" />
        <source>Cycle</source>
        <translation>循环</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="245" />
        <source>Sync</source>
        <translation>同步</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1454" />
        <location filename="../artisanlib/ports.py" line="989" />
        <location filename="../artisanlib/pid_dialogs.py" line="287" />
        <source>Input</source>
        <translation>输入</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="321" />
        <source>Positive</source>
        <translatorcomment>加熱</translatorcomment>
        <translation>加热</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="329" />
        <source>Negative</source>
        <translatorcomment>冷卻</translatorcomment>
        <translation>冷却</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6246" />
        <location filename="../artisanlib/pid_dialogs.py" line="469" />
        <location filename="../artisanlib/pid_dialogs.py" line="337" />
        <source>Slider</source>
        <translation>控制滑块</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="338" />
        <source>Limit</source>
        <translation>限制</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="404" />
        <source>Invert Control</source>
        <translatorcomment>反向控制</translatorcomment>
        <translation>反向控制</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="402" />
        <location filename="../artisanlib/pid_dialogs.py" line="2869" />
        <location filename="../artisanlib/pid_dialogs.py" line="2068" />
        <location filename="../artisanlib/pid_dialogs.py" line="446" />
        <source>Lookahead</source>
        <translatorcomment>測量導數</translatorcomment>
        <translation>前瞻</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="783" />
        <location filename="../artisanlib/ports.py" line="1445" />
        <location filename="../artisanlib/ports.py" line="965" />
        <location filename="../artisanlib/ports.py" line="485" />
        <location filename="../artisanlib/pid_dialogs.py" line="454" />
        <source>Mode</source>
        <translation>模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="456" />
        <source>Manual</source>
        <translation>手动</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="457" />
        <source>Ramp/Soak</source>
        <translatorcomment>積分抗飽和</translatorcomment>
        <translation>缓升/恒温</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2744" />
        <location filename="../artisanlib/canvas.py" line="2742" />
        <location filename="../artisanlib/devices.py" line="3384" />
        <location filename="../artisanlib/devices.py" line="3370" />
        <location filename="../artisanlib/main.py" line="6246" />
        <location filename="../artisanlib/main.py" line="6240" />
        <location filename="../artisanlib/main.py" line="6231" />
        <location filename="../artisanlib/main.py" line="6224" />
        <location filename="../artisanlib/main.py" line="6198" />
        <location filename="../artisanlib/main.py" line="6165" />
        <location filename="../artisanlib/main.py" line="6162" />
        <location filename="../artisanlib/main.py" line="6161" />
        <location filename="../artisanlib/main.py" line="6159" />
        <location filename="../artisanlib/main.py" line="6158" />
        <location filename="../artisanlib/main.py" line="6156" />
        <location filename="../artisanlib/main.py" line="6153" />
        <location filename="../artisanlib/main.py" line="6150" />
        <location filename="../artisanlib/main.py" line="6147" />
        <location filename="../artisanlib/main.py" line="6144" />
        <location filename="../artisanlib/main.py" line="6141" />
        <location filename="../artisanlib/main.py" line="6138" />
        <location filename="../artisanlib/main.py" line="6135" />
        <location filename="../artisanlib/main.py" line="6132" />
        <location filename="../artisanlib/pid_dialogs.py" line="458" />
        <source>Background</source>
        <translation>背景曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="465" />
        <source>Buttons</source>
        <translation>控制按钮</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="558" />
        <source>SV Filter</source>
        <translation>SV 滤波器</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="582" />
        <source>Duty Filter</source>
        <translation>输出低通滤波器</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="598" />
        <source>Steps</source>
        <translatorcomment>步長</translatorcomment>
        <translation>步长</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="625" />
        <source>β</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="635" />
        <source>γ</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="646" />
        <source>Derivative Filter</source>
        <translation>微分滤波器</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="654" />
        <source>PoE</source>
        <translation>按误差比例</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="656" />
        <source>PoM</source>
        <translation>按比例测量</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="659" />
        <source>DoE</source>
        <translatorcomment>誤差導數</translatorcomment>
        <translation>误差导数</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="661" />
        <source>DoM</source>
        <translatorcomment>測量導數</translatorcomment>
        <translation>测量导数</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="694" />
        <source>ILF</source>
        <translatorcomment>積分限制因子</translatorcomment>
        <translation>积分限制因子</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="703" />
        <source>Dlimit</source>
        <translatorcomment>導數限制</translatorcomment>
        <translation>导数限制</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="727" />
        <source>IWP</source>
        <translatorcomment>積分抗飽和</translatorcomment>
        <translation>积分抗饱和</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="730" />
        <source>IRoC</source>
        <translatorcomment>設定點變化時重置積分</translatorcomment>
        <translation>设定点变化时重置积分</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="873" />
        <location filename="../artisanlib/alarms.py" line="139" />
        <location filename="../artisanlib/roast_properties.py" line="2963" />
        <location filename="../artisanlib/roast_properties.py" line="2962" />
        <location filename="../artisanlib/roast_properties.py" line="2941" />
        <location filename="../artisanlib/pid_dialogs.py" line="984" />
        <location filename="../artisanlib/pid_dialogs.py" line="795" />
        <source>Label</source>
        <translation>标签</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19463" />
        <location filename="../artisanlib/canvas.py" line="4432" />
        <location filename="../artisanlib/transposer.py" line="1198" />
        <location filename="../artisanlib/transposer.py" line="1127" />
        <location filename="../artisanlib/alarms.py" line="904" />
        <location filename="../artisanlib/alarms.py" line="848" />
        <location filename="../artisanlib/statistics.py" line="99" />
        <location filename="../artisanlib/curves.py" line="2126" />
        <location filename="../artisanlib/curves.py" line="999" />
        <location filename="../artisanlib/curves.py" line="967" />
        <location filename="../artisanlib/designer.py" line="629" />
        <location filename="../artisanlib/designer.py" line="342" />
        <location filename="../artisanlib/designer.py" line="47" />
        <location filename="../artisanlib/roast_properties.py" line="4458" />
        <location filename="../artisanlib/roast_properties.py" line="668" />
        <location filename="../artisanlib/background.py" line="1063" />
        <location filename="../artisanlib/events.py" line="1316" />
        <location filename="../artisanlib/pid_dialogs.py" line="833" />
        <source>DRY END</source>
        <translation>脱水结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19466" />
        <location filename="../artisanlib/canvas.py" line="4433" />
        <location filename="../artisanlib/transposer.py" line="1199" />
        <location filename="../artisanlib/transposer.py" line="1128" />
        <location filename="../artisanlib/alarms.py" line="905" />
        <location filename="../artisanlib/alarms.py" line="849" />
        <location filename="../artisanlib/statistics.py" line="100" />
        <location filename="../artisanlib/curves.py" line="2127" />
        <location filename="../artisanlib/designer.py" line="630" />
        <location filename="../artisanlib/designer.py" line="343" />
        <location filename="../artisanlib/designer.py" line="49" />
        <location filename="../artisanlib/roast_properties.py" line="4461" />
        <location filename="../artisanlib/roast_properties.py" line="682" />
        <location filename="../artisanlib/background.py" line="1066" />
        <location filename="../artisanlib/events.py" line="1326" />
        <location filename="../artisanlib/pid_dialogs.py" line="834" />
        <source>FC START</source>
        <translation>第一次爆裂</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19469" />
        <location filename="../artisanlib/canvas.py" line="4434" />
        <location filename="../artisanlib/alarms.py" line="906" />
        <location filename="../artisanlib/alarms.py" line="850" />
        <location filename="../artisanlib/curves.py" line="2128" />
        <location filename="../artisanlib/designer.py" line="631" />
        <location filename="../artisanlib/designer.py" line="344" />
        <location filename="../artisanlib/designer.py" line="51" />
        <location filename="../artisanlib/roast_properties.py" line="4464" />
        <location filename="../artisanlib/roast_properties.py" line="697" />
        <location filename="../artisanlib/background.py" line="1069" />
        <location filename="../artisanlib/events.py" line="1336" />
        <location filename="../artisanlib/pid_dialogs.py" line="835" />
        <source>FC END</source>
        <translation>一爆结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19472" />
        <location filename="../artisanlib/canvas.py" line="4435" />
        <location filename="../artisanlib/transposer.py" line="1200" />
        <location filename="../artisanlib/transposer.py" line="1129" />
        <location filename="../artisanlib/alarms.py" line="907" />
        <location filename="../artisanlib/alarms.py" line="851" />
        <location filename="../artisanlib/curves.py" line="2129" />
        <location filename="../artisanlib/designer.py" line="632" />
        <location filename="../artisanlib/designer.py" line="345" />
        <location filename="../artisanlib/designer.py" line="53" />
        <location filename="../artisanlib/roast_properties.py" line="4467" />
        <location filename="../artisanlib/roast_properties.py" line="711" />
        <location filename="../artisanlib/background.py" line="1072" />
        <location filename="../artisanlib/events.py" line="1346" />
        <location filename="../artisanlib/pid_dialogs.py" line="836" />
        <source>SC START</source>
        <translation>第二次爆裂</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19475" />
        <location filename="../artisanlib/canvas.py" line="4436" />
        <location filename="../artisanlib/alarms.py" line="908" />
        <location filename="../artisanlib/alarms.py" line="852" />
        <location filename="../artisanlib/curves.py" line="2130" />
        <location filename="../artisanlib/designer.py" line="633" />
        <location filename="../artisanlib/designer.py" line="346" />
        <location filename="../artisanlib/designer.py" line="55" />
        <location filename="../artisanlib/roast_properties.py" line="4470" />
        <location filename="../artisanlib/roast_properties.py" line="725" />
        <location filename="../artisanlib/background.py" line="1075" />
        <location filename="../artisanlib/events.py" line="1356" />
        <location filename="../artisanlib/pid_dialogs.py" line="837" />
        <source>SC END</source>
        <translation>第二爆结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1911" />
        <source>Ramp Soak HH:MM&lt;BR&gt;(1-4)</source>
        <translation>缓升 恒温 HH:MM&lt;BR&gt;(1-4)</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1915" />
        <source>Ramp Soak HH:MM&lt;BR&gt;(5-8)</source>
        <translation>缓升 恒温 HH:MM&lt;BR&gt;(5-8)</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1916" />
        <source>Ramp/Soak Pattern</source>
        <translation>缓升/恒温 程式</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2948" />
        <location filename="../artisanlib/pid_dialogs.py" line="1956" />
        <source>SV Buttons</source>
        <translation>SV 按钮</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2951" />
        <location filename="../artisanlib/pid_dialogs.py" line="1959" />
        <source>SV Slider</source>
        <translation>SV 控制滑块</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1973" />
        <location filename="../artisanlib/pid_dialogs.py" line="1969" />
        <source>WARNING</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1970" />
        <source>Writing eeprom memory</source>
        <translation>写入EEPROM内存</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1971" />
        <source>&lt;u&gt;Max life&lt;/u&gt; 10,000 writes</source>
        <translation>&lt;u&gt;最大耐久度&lt;/u&gt; 写入10,000</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1972" />
        <source>Infinite read life.</source>
        <translation>无限的读取耐久度.</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1974" />
        <source>After &lt;u&gt;writing&lt;/u&gt; an adjustment,&lt;br&gt;never power down the pid&lt;br&gt;for the next 5 seconds &lt;br&gt;or the pid may never recover.</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1975" />
        <source>Read operations manual</source>
        <translation>阅读操作手册</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3134" />
        <location filename="../artisanlib/pid_dialogs.py" line="2014" />
        <source>NOTE: BT Thermocouple type is not stored in the Artisan settings</source>
        <translation>注意: BT热电偶类型不会储存在Artisan设置里</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3171" />
        <location filename="../artisanlib/pid_dialogs.py" line="2049" />
        <source>Artisan uses 1 decimal point</source>
        <translation>Artisan使用1位小数点</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3287" />
        <location filename="../artisanlib/pid_dialogs.py" line="2146" />
        <source>ET Thermocouple type</source>
        <translation>ET热电偶类型</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3294" />
        <location filename="../artisanlib/pid_dialogs.py" line="2153" />
        <source>BT Thermocouple type</source>
        <translation>BT热电偶类型</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2747" />
        <source>Ramp Soak (MM:SS)&lt;br&gt;(1-7)</source>
        <translation>缓升 恒温 (MM:SS)&lt;br&gt;(1-7)</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2753" />
        <source>Ramp Soak (MM:SS)&lt;br&gt;(8-16)</source>
        <translation>缓升 恒温 (MM:SS)&lt;br&gt;(8-16)</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2803" />
        <source>Pattern</source>
        <translation>图案</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2875" />
        <source>SV (7-0)</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3010" />
        <location filename="../artisanlib/pid_dialogs.py" line="2881" />
        <source>Write</source>
        <translation>写入</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2960" />
        <source>SV min</source>
        <translation>最小SV</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2967" />
        <source>SV max</source>
        <translation>最大SV</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1082" />
        <location filename="../artisanlib/ports.py" line="618" />
        <location filename="../artisanlib/pid_dialogs.py" line="2992" />
        <source>P</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1088" />
        <location filename="../artisanlib/ports.py" line="624" />
        <location filename="../artisanlib/pid_dialogs.py" line="2998" />
        <source>I</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1094" />
        <location filename="../artisanlib/ports.py" line="630" />
        <location filename="../artisanlib/pid_dialogs.py" line="3004" />
        <source>D</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3173" />
        <source>Artisan Fuji PXG uses MINUTES:SECONDS units in Ramp/Soaks</source>
        <translation>Artisan Fuji PXG在使用缓升/恒温上使用分钟:秒钟单位</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3175" />
        <source>Artisan Fuji PXF uses MINUTES:SECONDS units in Ramp/Soaks</source>
        <translation>Artisan Fuji PXF 在缓升/恒温中使用分钟:秒钟单位</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="50" />
        <source>Preview:</source>
        <translation>预览:</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="86" />
        <source>File Name Prefix</source>
        <translation>文件名前缀</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="186" />
        <source>While recording:</source>
        <translation>当记录时:</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="163" />
        <source>Show</source>
        <translation>显示</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="167" />
        <source>Annotation</source>
        <translation>说明</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="172" />
        <source>Example before FCs</source>
        <translation>第一次爆裂之前 示例</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="176" />
        <source>Example after FCs</source>
        <translation>第一次爆裂之后 示例</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="250" />
        <source>Allowed Annotation Overlap</source>
        <translation>允许重叠说明</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6143" />
        <location filename="../artisanlib/events.py" line="317" />
        <source>Markers</source>
        <translation>标记</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2101" />
        <location filename="../artisanlib/roast_properties.py" line="1069" />
        <location filename="../artisanlib/events.py" line="474" />
        <source>Color</source>
        <translation>颜色测量</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="476" />
        <source>Text Color</source>
        <translation>文字颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="879" />
        <location filename="../artisanlib/designer.py" line="70" />
        <location filename="../artisanlib/events.py" line="478" />
        <source>Marker</source>
        <translation>标记</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="480" />
        <source>Thickness</source>
        <translation>厚度</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1359" />
        <location filename="../artisanlib/events.py" line="482" />
        <source>Opacity</source>
        <translation>不透明度</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="881" />
        <location filename="../artisanlib/events.py" line="484" />
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26496" />
        <location filename="../artisanlib/main.py" line="26495" />
        <location filename="../artisanlib/main.py" line="26491" />
        <location filename="../artisanlib/events.py" line="1432" />
        <location filename="../artisanlib/events.py" line="594" />
        <location filename="../artisanlib/events.py" line="583" />
        <source>START</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="16891" />
        <location filename="../artisanlib/canvas.py" line="16882" />
        <location filename="../artisanlib/events.py" line="628" />
        <source>MET</source>
        <translation>最大环境温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="656" />
        <source>Max Buttons Per Row</source>
        <translation>每行最大按钮数</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="663" />
        <source>Button Size</source>
        <translation>按钮大小</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="717" />
        <source>Color Pattern</source>
        <translation>色彩图案</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="729" />
        <source>current:</source>
        <translation>当前：</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6249" />
        <location filename="../artisanlib/main.py" line="6243" />
        <location filename="../artisanlib/main.py" line="6240" />
        <location filename="../artisanlib/roast_properties.py" line="2949" />
        <location filename="../artisanlib/ports.py" line="1411" />
        <location filename="../artisanlib/events.py" line="1029" />
        <location filename="../artisanlib/events.py" line="757" />
        <source>Event</source>
        <translation>事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="775" />
        <location filename="../artisanlib/events.py" line="759" />
        <source>Action</source>
        <translation>动作</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1319" />
        <location filename="../artisanlib/events.py" line="761" />
        <source>Command</source>
        <translation>指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="3850" />
        <location filename="../artisanlib/events.py" line="763" />
        <source>Offset</source>
        <translation>补偿</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="966" />
        <location filename="../artisanlib/events.py" line="3849" />
        <location filename="../artisanlib/events.py" line="765" />
        <source>Factor</source>
        <translation>因子</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="771" />
        <source>Bernoulli</source>
        <translation>伯努利数</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="781" />
        <source>Temp</source>
        <translation>温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2965" />
        <location filename="../artisanlib/roast_properties.py" line="2964" />
        <location filename="../artisanlib/roast_properties.py" line="2945" />
        <location filename="../artisanlib/roast_properties.py" line="114" />
        <location filename="../artisanlib/events.py" line="783" />
        <source>Unit</source>
        <translation>单位</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2969" />
        <location filename="../artisanlib/roast_properties.py" line="2968" />
        <location filename="../artisanlib/events.py" line="1031" />
        <source>Source</source>
        <translation>来源</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1193" />
        <source>Cluster</source>
        <translation>群组</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26472" />
        <location filename="../artisanlib/main.py" line="26471" />
        <location filename="../artisanlib/main.py" line="26469" />
        <location filename="../artisanlib/ports.py" line="1134" />
        <location filename="../artisanlib/ports.py" line="669" />
        <location filename="../artisanlib/events.py" line="1401" />
        <source>OFF</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1424" />
        <source>RESET</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12698" />
        <location filename="../artisanlib/main.py" line="12274" />
        <location filename="../artisanlib/main.py" line="6255" />
        <location filename="../artisanlib/events.py" line="3133" />
        <location filename="../artisanlib/events.py" line="3114" />
        <source>Event button</source>
        <translation>事件按钮</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6255" />
        <location filename="../artisanlib/events.py" line="3133" />
        <location filename="../artisanlib/events.py" line="3114" />
        <source>its text</source>
        <translation>其文本</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="3847" />
        <source>Slider Value</source>
        <translation>滑块值</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="3848" />
        <source>Target Value</source>
        <translation>目标数值</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="582" />
        <location filename="../artisanlib/ports.py" line="480" />
        <location filename="../artisanlib/ports.py" line="72" />
        <source>Device</source>
        <translation>设备</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="481" />
        <location filename="../artisanlib/ports.py" line="78" />
        <source>Register</source>
        <translation>注册</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1040" />
        <location filename="../artisanlib/ports.py" line="961" />
        <location filename="../artisanlib/ports.py" line="240" />
        <source>Area</source>
        <translation>区域</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1046" />
        <location filename="../artisanlib/ports.py" line="962" />
        <location filename="../artisanlib/ports.py" line="247" />
        <source>DB#</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7438" />
        <location filename="../artisanlib/curves.py" line="1044" />
        <location filename="../artisanlib/ports.py" line="963" />
        <location filename="../artisanlib/ports.py" line="254" />
        <source>Start</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="437" />
        <location filename="../artisanlib/ports.py" line="394" />
        <source>Comm Port</source>
        <translation>通信端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="443" />
        <location filename="../artisanlib/ports.py" line="398" />
        <source>Baud Rate</source>
        <translation>传输速率</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="452" />
        <location filename="../artisanlib/ports.py" line="404" />
        <source>Byte Size</source>
        <translation>字节大小</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="458" />
        <location filename="../artisanlib/ports.py" line="410" />
        <source>Parity</source>
        <translation>校验</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="465" />
        <location filename="../artisanlib/ports.py" line="417" />
        <source>Stopbits</source>
        <translation>停止位</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="727" />
        <location filename="../artisanlib/ports.py" line="471" />
        <location filename="../artisanlib/ports.py" line="423" />
        <source>Timeout</source>
        <translation>超时</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="426" />
        <source>Settings for non-Modbus devices</source>
        <translation>无协议设备设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="482" />
        <source>Decode</source>
        <translation>解码</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="483" />
        <source>Function</source>
        <translation>功能</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="484" />
        <source>Divider</source>
        <translation>分频器</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="550" />
        <source>little-endian</source>
        <translation>小端序</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="714" />
        <location filename="../artisanlib/devices.py" line="708" />
        <location filename="../artisanlib/devices.py" line="382" />
        <location filename="../artisanlib/devices.py" line="178" />
        <location filename="../artisanlib/roast_properties.py" line="2967" />
        <location filename="../artisanlib/roast_properties.py" line="2966" />
        <location filename="../artisanlib/roast_properties.py" line="2947" />
        <location filename="../artisanlib/ports.py" line="1059" />
        <location filename="../artisanlib/ports.py" line="964" />
        <location filename="../artisanlib/ports.py" line="558" />
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1247" />
        <location filename="../artisanlib/devices.py" line="1241" />
        <location filename="../artisanlib/devices.py" line="1230" />
        <location filename="../artisanlib/devices.py" line="1205" />
        <location filename="../artisanlib/devices.py" line="1156" />
        <location filename="../artisanlib/devices.py" line="939" />
        <location filename="../artisanlib/ports.py" line="1214" />
        <location filename="../artisanlib/ports.py" line="923" />
        <location filename="../artisanlib/ports.py" line="570" />
        <source>Host</source>
        <translation>主机</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1780" />
        <location filename="../artisanlib/devices.py" line="1733" />
        <location filename="../artisanlib/devices.py" line="1235" />
        <location filename="../artisanlib/devices.py" line="1211" />
        <location filename="../artisanlib/devices.py" line="1162" />
        <location filename="../artisanlib/devices.py" line="951" />
        <location filename="../artisanlib/curves.py" line="1291" />
        <location filename="../artisanlib/ports.py" line="1219" />
        <location filename="../artisanlib/ports.py" line="928" />
        <location filename="../artisanlib/ports.py" line="575" />
        <source>Port</source>
        <translation>端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1068" />
        <location filename="../artisanlib/ports.py" line="604" />
        <source>SV Factor</source>
        <translation>SV 因子</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1075" />
        <location filename="../artisanlib/ports.py" line="611" />
        <source>pid Factor</source>
        <translation>pid 因子</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="700" />
        <source>Delay</source>
        <translation>延迟</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="734" />
        <location filename="../artisanlib/ports.py" line="707" />
        <source>Retries</source>
        <translation>重试</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="934" />
        <source>Rack</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="940" />
        <source>Slot</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1225" />
        <source>Path</source>
        <translation>路径</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1231" />
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1280" />
        <source>Connect</source>
        <translation>连接</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1283" />
        <source>Reconnect</source>
        <translation>重连</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1443" />
        <location filename="../artisanlib/ports.py" line="1286" />
        <source>Request</source>
        <translation>请求</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1315" />
        <source>Message ID</source>
        <translation>信息 ID</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1317" />
        <source>Machine ID</source>
        <translation>机器ID</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1321" />
        <source>Data</source>
        <translation>数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1323" />
        <source>Message</source>
        <translation>信息</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1335" />
        <source>Data Request</source>
        <translation>请求数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1444" />
        <location filename="../artisanlib/ports.py" line="1413" />
        <source>Node</source>
        <translation>节点</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="1428" />
        <location filename="../artisanlib/background.py" line="103" />
        <source>ALL</source>
        <translation>全部</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="136" />
        <source>Extra 1</source>
        <translation>额外 1</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="145" />
        <source>Extra 2</source>
        <translation>额外 2</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="211" />
        <location filename="../artisanlib/background.py" line="198" />
        <source>by time</source>
        <translation>按时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="212" />
        <location filename="../artisanlib/background.py" line="199" />
        <source>by BT</source>
        <translation>按BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="213" />
        <location filename="../artisanlib/background.py" line="200" />
        <source>by ET</source>
        <translation>按ET</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="201" />
        <source>by time/BT</source>
        <translation>按时间/BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="202" />
        <source>by time/ET</source>
        <translation>按时间/ET</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="239" />
        <source>Text Warning</source>
        <translation>文字警告</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="241" />
        <source>sec</source>
        <translation>秒</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="400" />
        <source>Ramp</source>
        <translation>缓升</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="121" />
        <source>ml</source>
        <translation>毫升</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="214" />
        <location filename="../artisanlib/roast_properties.py" line="141" />
        <source>Unit Weight</source>
        <translation>重量单位</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="219" />
        <location filename="../artisanlib/roast_properties.py" line="146" />
        <source>g</source>
        <translation>克</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2049" />
        <location filename="../plus/blend.py" line="157" />
        <location filename="../artisanlib/canvas.py" line="12804" />
        <location filename="../artisanlib/large_lcds.py" line="851" />
        <location filename="../artisanlib/roast_properties.py" line="906" />
        <location filename="../artisanlib/roast_properties.py" line="221" />
        <location filename="../artisanlib/roast_properties.py" line="148" />
        <source>Weight</source>
        <translation>重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="967" />
        <location filename="../artisanlib/roast_properties.py" line="236" />
        <location filename="../artisanlib/roast_properties.py" line="163" />
        <source>Volume</source>
        <translation>体积</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="4066" />
        <location filename="../artisanlib/canvas.py" line="12804" />
        <location filename="../artisanlib/canvas.py" line="12753" />
        <location filename="../artisanlib/canvas.py" line="12748" />
        <location filename="../artisanlib/roast_properties.py" line="904" />
        <location filename="../artisanlib/roast_properties.py" line="206" />
        <source>Green</source>
        <translation>生豆</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="4068" />
        <location filename="../plus/schedule.py" line="2222" />
        <location filename="../artisanlib/roast_properties.py" line="905" />
        <location filename="../artisanlib/roast_properties.py" line="279" />
        <source>Roasted</source>
        <translation>熟豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="866" />
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="3162" />
        <location filename="../artisanlib/roast_properties.py" line="871" />
        <source>Batch</source>
        <translation>批次</translation>
    </message>
    <message>
        <location filename="../plus/blend.py" line="343" />
        <location filename="../artisanlib/statistics.py" line="202" />
        <location filename="../artisanlib/roast_properties.py" line="1094" />
        <location filename="../artisanlib/roast_properties.py" line="897" />
        <source>Beans</source>
        <translation>生豆</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2091" />
        <location filename="../artisanlib/canvas.py" line="12748" />
        <location filename="../artisanlib/roast_properties.py" line="998" />
        <source>Density</source>
        <translation>密度</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1051" />
        <source>Screen</source>
        <translation>生豆筛网目数</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1070" />
        <source>Whole</source>
        <translation>整豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1077" />
        <source>Ground</source>
        <translation>咖啡粉</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2111" />
        <location filename="../artisanlib/canvas.py" line="12753" />
        <location filename="../artisanlib/roast_properties.py" line="1106" />
        <source>Moisture</source>
        <translation>含水量</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1134" />
        <location filename="../artisanlib/roast_properties.py" line="1107" />
        <source>%</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1132" />
        <source>Ambient Conditions</source>
        <translation>环境条件</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2122" />
        <location filename="../plus/schedule.py" line="2121" />
        <location filename="../artisanlib/statistics.py" line="213" />
        <location filename="../artisanlib/roast_properties.py" line="1180" />
        <source>Roasting Notes</source>
        <translation>烘焙笔记</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2134" />
        <location filename="../plus/schedule.py" line="2133" />
        <location filename="../artisanlib/statistics.py" line="215" />
        <location filename="../artisanlib/roast_properties.py" line="1184" />
        <source>Cupping Notes</source>
        <translation>杯测笔记</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1362" />
        <source>Stock</source>
        <translation>库存</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1364" />
        <source>Store</source>
        <translation>商店</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1366" />
        <source>Blend</source>
        <translation>混合物</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2081" />
        <location filename="../artisanlib/main.py" line="23709" />
        <location filename="../artisanlib/roast_properties.py" line="1723" />
        <source>Defects</source>
        <translation>瑕疵</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2071" />
        <location filename="../artisanlib/statistics.py" line="231" />
        <location filename="../artisanlib/roast_properties.py" line="1724" />
        <source>Yield</source>
        <translation>产量</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1934" />
        <source>Template</source>
        <translation>模板</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2379" />
        <location filename="../artisanlib/devices.py" line="2320" />
        <location filename="../artisanlib/roast_properties.py" line="2753" />
        <source>edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2901" />
        <source>Results in</source>
        <translation>特征显示为</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2943" />
        <source>Rating</source>
        <translation>额定值</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2951" />
        <source>Pressure %</source>
        <translation>气压 %</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2953" />
        <source>Electric Energy Mix:</source>
        <translation>电力 火力 混合：</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2959" />
        <location filename="../artisanlib/roast_properties.py" line="2955" />
        <source>Gas Energy Mix:</source>
        <translation>天然气能源结构：</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2958" />
        <location filename="../artisanlib/roast_properties.py" line="2957" />
        <source>Renewable</source>
        <translation>可再生</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2960" />
        <source>Meter 1</source>
        <translation>仪表 1</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2961" />
        <source>Meter 2</source>
        <translation>仪表 2</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="5770" />
        <location filename="../artisanlib/roast_properties.py" line="2975" />
        <source>Pre-Heating</source>
        <translation>预热</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="5780" />
        <location filename="../artisanlib/roast_properties.py" line="2976" />
        <source>Between Batches</source>
        <translation>批次间</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="5790" />
        <location filename="../artisanlib/roast_properties.py" line="2977" />
        <source>Cooling</source>
        <translation>冷却</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2978" />
        <source>Between Batches after Pre-Heating</source>
        <translation>预热后 批次间</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2983" />
        <source>(mm:ss)</source>
        <translation>(mm:ss)</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7439" />
        <location filename="../artisanlib/roast_properties.py" line="2988" />
        <source>Duration</source>
        <translation>持续时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2989" />
        <source>Measured Energy or Output %</source>
        <translation>测量能源或输出 %</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="3590" />
        <location filename="../artisanlib/roast_properties.py" line="3561" />
        <source>Preheat</source>
        <translation>预热</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="3592" />
        <location filename="../artisanlib/roast_properties.py" line="3563" />
        <source>BBP</source>
        <translation>BBP</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="17015" />
        <location filename="../artisanlib/roast_properties.py" line="3599" />
        <location filename="../artisanlib/roast_properties.py" line="3594" />
        <location filename="../artisanlib/roast_properties.py" line="3570" />
        <location filename="../artisanlib/roast_properties.py" line="3565" />
        <source>Roast</source>
        <translation>烘焙</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="3608" />
        <location filename="../artisanlib/roast_properties.py" line="3579" />
        <source>per kg green coffee</source>
        <translation>每公斤生豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="3639" />
        <source>Load</source>
        <translation>载入</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="4149" />
        <source>Organization</source>
        <translation>组织</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="4150" />
        <source>Operator</source>
        <translation>烘焙师</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="4151" />
        <source>Machine</source>
        <translation>机器</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1655" />
        <location filename="../artisanlib/devices.py" line="1584" />
        <location filename="../artisanlib/roast_properties.py" line="4152" />
        <source>Model</source>
        <translation>型号</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6006" />
        <location filename="../artisanlib/roast_properties.py" line="4153" />
        <source>Heating</source>
        <translation>热源</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="201" />
        <location filename="../artisanlib/roast_properties.py" line="4154" />
        <source>Drum Speed</source>
        <translation>滚筒转速</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="5184" />
        <source>organic material</source>
        <translation>有机物质</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="1027" />
        <location filename="../artisanlib/statistics.py" line="226" />
        <location filename="../artisanlib/phases.py" line="46" />
        <source>Drying</source>
        <translation>脱水</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="1028" />
        <location filename="../artisanlib/statistics.py" line="225" />
        <location filename="../artisanlib/phases.py" line="47" />
        <source>Maillard</source>
        <translation>梅纳反应</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="1029" />
        <location filename="../artisanlib/statistics.py" line="224" />
        <location filename="../artisanlib/phases.py" line="48" />
        <source>Finishing</source>
        <translation>完成</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="651" />
        <location filename="../artisanlib/curves.py" line="435" />
        <location filename="../artisanlib/phases.py" line="49" />
        <source>min</source>
        <comment>abbrev of minimum</comment>
        <translation>最小</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="652" />
        <location filename="../artisanlib/curves.py" line="436" />
        <location filename="../artisanlib/phases.py" line="50" />
        <source>max</source>
        <translation>最大</translation>
    </message>
    <message>
        <location filename="../artisanlib/phases.py" line="138" />
        <source>Phases
LCDs Mode</source>
        <translation>阶段
LCD模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/phases.py" line="140" />
        <source>Phases
LCDs All</source>
        <translation>所有
阶段LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/logs.py" line="105" />
        <source>Number of errors found {0}</source>
        <translation>找到的错误数 {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="1293" />
        <location filename="../artisanlib/designer.py" line="72" />
        <source>Time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/designer.py" line="217" />
        <source>Curviness</source>
        <translation>曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/designer.py" line="718" />
        <source>temp</source>
        <translation>温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/designer.py" line="723" />
        <source>time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="45" />
        <source>Enter two times along profile</source>
        <translation>输入配置文件的两个时间点</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="48" />
        <source>Start (00:00)</source>
        <translation>开始 (00:00)</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="49" />
        <source>End (00:00)</source>
        <translation>结束 (00:00)</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="68" />
        <source>Fahrenheit</source>
        <translation>华氏度</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="69" />
        <source>Celsius</source>
        <translation>摄氏度</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="123" />
        <source>Yield (%)</source>
        <translation>产量 (%)</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="124" />
        <source>Grounds (g)</source>
        <translation>咖啡粉 (g)</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="125" />
        <source>TDS (%)</source>
        <translation>TDS (%)</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="126" />
        <source>Coffee (g)</source>
        <translation>咖啡液 (g)</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="235" />
        <source>Error: End time smaller than Start time</source>
        <translation>错误: 结束时间小于开始时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="250" />
        <source>Best approximation was made from {0} to {1}</source>
        <translation>最佳近似值为 {0} 到 {1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="251" />
        <source>&lt;b&gt;{0}&lt;/b&gt; {1}/sec, &lt;b&gt;{2}&lt;/b&gt; {3}/min</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="255" />
        <source>Time syntax error. Time not valid</source>
        <translation>时间规则错误.时间无效</translation>
    </message>
    <message>
        <location filename="../artisanlib/calculator.py" line="260" />
        <source>No profile found</source>
        <translation>没有发现配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/sampling.py" line="40" />
        <source>Keep ON</source>
        <translation>保存打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/sampling.py" line="44" />
        <source>Open Completed Roast in Viewer</source>
        <translation>在查看器中打开完成的烘焙</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="63" />
        <source>Data precision</source>
        <translation>数据精确度</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="123" />
        <source>No plotter data found.</source>
        <translation>找不到绘图仪数据.</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="343" />
        <source>Smoothing</source>
        <translation>平滑</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="370" />
        <source>Smooth Curves</source>
        <translation>平滑曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="470" />
        <source>Delta Span</source>
        <translation>范围差值</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="252" />
        <location filename="../artisanlib/curves.py" line="578" />
        <source>ET Y(x)</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="253" />
        <location filename="../artisanlib/curves.py" line="579" />
        <source>BT Y(x)</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="699" />
        <source>Path Effects</source>
        <translation>路径效果</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="718" />
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="762" />
        <source>P1</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="763" />
        <source>P2</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="764" />
        <source>P3</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="765" />
        <source>P4</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="766" />
        <source>P5</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="767" />
        <source>P6</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="768" />
        <source>P7</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="769" />
        <source>P8</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="770" />
        <source>P9</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="961" />
        <source>Offset seconds from CHARGE</source>
        <translation>从投豆起计算补偿时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="966" />
        <source>Start of Analyze interval of interest</source>
        <translation>分析间隔开始</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1008" />
        <location filename="../artisanlib/curves.py" line="976" />
        <source>Custom offset seconds from CHARGE</source>
        <translation>自定义投豆后的时间补偿秒数</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="985" />
        <source>Number of samples considered significant</source>
        <translation>有效值数量</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="991" />
        <source>Delta RoR Actual-to-Fit considered significant</source>
        <translation>实际拟合的ROR差值需要慎重考虑</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="998" />
        <source>Start of Curve Fit window</source>
        <translation>屏幕上曲线的拟合起点</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1024" />
        <source>deg</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1045" />
        <source>End</source>
        <translation>结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1947" />
        <location filename="../artisanlib/curves.py" line="1331" />
        <source>Not available in ArtisanViewer</source>
        <translation>在ArtisanViewer中无效</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="4455" />
        <location filename="../artisanlib/curves.py" line="2137" />
        <source>EVENT</source>
        <translation>事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="95" />
        <source>From</source>
        <translation>来自</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="109" />
        <source>Base</source>
        <translation>基础</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="125" />
        <source>Target</source>
        <translation>目标</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="200" />
        <source>Roaster</source>
        <translation>烘焙机</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2127" />
        <location filename="../artisanlib/statistics.py" line="214" />
        <source>Cupping Score</source>
        <translation>杯测分数</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="228" />
        <source>Cupping Correction</source>
        <translation>杯测矫正</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="229" />
        <source>Defects Weight</source>
        <translation>缺陷重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="230" />
        <source>Defects Loss</source>
        <translation>缺陷损失</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="232" />
        <source>Total Loss</source>
        <translation>烘焙总损失</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="253" />
        <source>Max characters per line</source>
        <translation>每行最多字符数</translation>
    </message>
    <message>
        <location filename="../artisanlib/dialogs.py" line="187" />
        <source>Enter text to search</source>
        <translation>输入要搜索的文本</translation>
    </message>
    <message>
        <location filename="../artisanlib/dialogs.py" line="202" />
        <source>For more details visit</source>
        <translation>访问更多细节</translation>
    </message>
    <message>
        <location filename="../artisanlib/dialogs.py" line="693" />
        <source>container</source>
        <translation>容器</translation>
    </message>
    <message>
        <location filename="../artisanlib/dialogs.py" line="774" />
        <source>Choose how to convert the profile</source>
        <translation>选择如何将曲线文件转换为设计器模式：</translation>
    </message>
    <message>
        <location filename="../artisanlib/dialogs.py" line="779" />
        <source>More nodes: better fit but harder to edit
Fewer nodes: simpler curve but may lose detail</source>
        <translation>节点越多: 拟合效果更好但更难编辑 
节点越少 = 曲线越简单但可能丢失细节</translation>
    </message>
    <message>
        <location filename="../artisanlib/dialogs.py" line="792" />
        <source>Number of spline nodes</source>
        <translation>样条节点数</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="137" />
        <source>Pop Up Timeout</source>
        <translation>弹窗超时</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="184" />
        <source>Alarm Sets</source>
        <translation>警报设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="189" />
        <source>Current Alarm Set</source>
        <translation>当前警报设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="938" />
        <location filename="../artisanlib/alarms.py" line="483" />
        <source>Enter description</source>
        <translation>输入说明</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3420" />
        <location filename="../artisanlib/large_lcds.py" line="579" />
        <source>PID SV</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3424" />
        <location filename="../artisanlib/large_lcds.py" line="587" />
        <source>PID %</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/large_lcds.py" line="856" />
        <source>Total</source>
        <translation>总重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="875" />
        <source>Line style</source>
        <translation>线型</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="876" />
        <source>Draw style</source>
        <translation>画风</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="878" />
        <source>Color (RGBA)</source>
        <translation>颜色 (RGBA)</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="880" />
        <source>Symbol</source>
        <translation>象征</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="882" />
        <source>Face color (RGBA)</source>
        <translation>面部颜色 (RGBA)</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="883" />
        <source>Edge color (RGBA)</source>
        <translation>边缘颜色 (RGBA)</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23621" />
        <location filename="../artisanlib/main.py" line="1236" />
        <source>roasted</source>
        <translation>熟豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="16892" />
        <location filename="../artisanlib/canvas.py" line="16879" />
        <location filename="../artisanlib/main.py" line="7921" />
        <location filename="../artisanlib/main.py" line="7047" />
        <location filename="../artisanlib/main.py" line="7045" />
        <location filename="../artisanlib/main.py" line="3876" />
        <source>AUC</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6149" />
        <source>Time Guide</source>
        <translation>时间指引</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6152" />
        <source>Background ET</source>
        <translation>背景曲线ET</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6155" />
        <source>Background BT</source>
        <translation>背景曲线BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6164" />
        <source>Background Extra</source>
        <translation>背景曲线额外</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6167" />
        <source>X Label</source>
        <translation>X轴标签</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6174" />
        <location filename="../artisanlib/main.py" line="6171" />
        <location filename="../artisanlib/main.py" line="6168" />
        <source>Canvas</source>
        <translation>画布</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6170" />
        <source>Y Label</source>
        <translation>Y轴标签</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6176" />
        <source>SpecialEventText</source>
        <translation>特别事件文字</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6177" />
        <source>SpecialEventBox</source>
        <translation>特别事件标记</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6179" />
        <source>Bg SpecialEventText</source>
        <translation>背景曲线特别事件文字</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6180" />
        <source>Bg SpecialEventBox</source>
        <translation>背景曲线特别事件标记</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3385" />
        <location filename="../artisanlib/devices.py" line="3371" />
        <location filename="../artisanlib/main.py" line="6243" />
        <location filename="../artisanlib/main.py" line="6234" />
        <location filename="../artisanlib/main.py" line="6227" />
        <location filename="../artisanlib/main.py" line="6192" />
        <location filename="../artisanlib/main.py" line="6189" />
        <location filename="../artisanlib/main.py" line="6186" />
        <location filename="../artisanlib/main.py" line="6183" />
        <source>Legend bkgnd</source>
        <translation>背景曲线图例</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6194" />
        <source>MET Text</source>
        <translation>最大环境温度文字</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6197" />
        <location filename="../artisanlib/main.py" line="6195" />
        <source>MET Box</source>
        <translation>最大环境温度标记</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6201" />
        <source>Timer LCD Digits</source>
        <translation>数显LCD计时器</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6202" />
        <source>Timer LCD Background</source>
        <translation>背景曲线LCD计时器</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6210" />
        <location filename="../artisanlib/main.py" line="6204" />
        <source>ET LCD Digits</source>
        <translation>ET数显LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6211" />
        <location filename="../artisanlib/main.py" line="6205" />
        <source>ET LCD Background</source>
        <translation>ET背景曲线LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6213" />
        <location filename="../artisanlib/main.py" line="6207" />
        <source>BT LCD Digits</source>
        <translation>BT数显LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6214" />
        <location filename="../artisanlib/main.py" line="6208" />
        <source>BT LCD Background</source>
        <translation>BT背景曲线LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6216" />
        <source>Extra/PID LCD Digits</source>
        <translation>额外/PID 数显LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6217" />
        <source>Extra/PID LCD Background</source>
        <translation>背景曲线额外/PID 数显LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7049" />
        <source>AUC FCs</source>
        <translation>AUC 第一次爆裂</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="18410" />
        <location filename="../artisanlib/main.py" line="27265" />
        <location filename="../artisanlib/main.py" line="7416" />
        <source>ln()</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27263" />
        <location filename="../artisanlib/main.py" line="27261" />
        <location filename="../artisanlib/main.py" line="7419" />
        <location filename="../artisanlib/main.py" line="7418" />
        <source>x</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27259" />
        <location filename="../artisanlib/main.py" line="27210" />
        <location filename="../artisanlib/main.py" line="7420" />
        <source>Bkgnd</source>
        <translation>背景曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7431" />
        <location filename="../artisanlib/main.py" line="7427" />
        <location filename="../artisanlib/main.py" line="7423" />
        <source>On</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7433" />
        <location filename="../artisanlib/main.py" line="7429" />
        <location filename="../artisanlib/main.py" line="7425" />
        <source>Off</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7440" />
        <source>Max Delta</source>
        <translation>最大差值</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7441" />
        <source>Swing</source>
        <translation>波动值</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7442" />
        <source>ABC/secs</source>
        <translation>曲线间面积/秒</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7453" />
        <source>Segment Analysis (rise, crash and flick)</source>
        <translation>片段分析 (暴增, 失温, 和波动)</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7458" />
        <source>Background Align</source>
        <translation>背景对齐</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7472" />
        <source>Curve Fit</source>
        <translation>曲线优化</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7473" />
        <source>Samples Threshold</source>
        <translation>采样阈</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7473" />
        <source>Delta Threshold</source>
        <translation>差值阈</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7474" />
        <source>Sample rate (secs)</source>
        <translation>采样率(秒)</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7474" />
        <source>Smooth Curves/Spikes</source>
        <translation>曲线/峰值平滑度</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7475" />
        <source>Delta Span/Smoothing</source>
        <translation>范围差值</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7475" />
        <source>Polyfit/Optimal Smoothing</source>
        <translation>多项式拟合/最佳平滑</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7476" />
        <source>Fit RoRoR (C/min/min)</source>
        <translation>优化RoRoR (C/min/min)</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7476" />
        <source>Actual RoR at FCs</source>
        <translation>第一次爆裂时的真实ROR</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="8008" />
        <source>ALL FINISHING MODE</source>
        <translation>全部完成模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="8173" />
        <location filename="../artisanlib/main.py" line="8027" />
        <source>DEV%</source>
        <translation>发展%</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="8243" />
        <location filename="../artisanlib/main.py" line="8059" />
        <source>DRY%</source>
        <translation>脱水%</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="8202" />
        <location filename="../artisanlib/main.py" line="8201" />
        <location filename="../artisanlib/main.py" line="8167" />
        <location filename="../artisanlib/main.py" line="8166" />
        <location filename="../artisanlib/main.py" line="8097" />
        <source>TIME MODE</source>
        <translation>时间模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="8206" />
        <location filename="../artisanlib/main.py" line="8205" />
        <location filename="../artisanlib/main.py" line="8172" />
        <location filename="../artisanlib/main.py" line="8171" />
        <location filename="../artisanlib/main.py" line="8101" />
        <source>PERCENTAGE MODE</source>
        <translation>百分比模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="8110" />
        <source>RAMP%</source>
        <translation>缓升%</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="8210" />
        <location filename="../artisanlib/main.py" line="8209" />
        <location filename="../artisanlib/main.py" line="8183" />
        <location filename="../artisanlib/main.py" line="8182" />
        <location filename="../artisanlib/main.py" line="8113" />
        <source>TEMP MODE</source>
        <translation>温度模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="15017" />
        <source>Start recording</source>
        <translation>开始记录</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="15031" />
        <source>Charge the beans</source>
        <translation>[ 投豆 ]</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23601" />
        <source>/m</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23617" />
        <source>greens</source>
        <translation>生豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26487" />
        <location filename="../artisanlib/main.py" line="26474" />
        <location filename="../artisanlib/main.py" line="26473" />
        <source>AUTO</source>
        <translation>自动</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26487" />
        <location filename="../artisanlib/main.py" line="26486" />
        <location filename="../artisanlib/main.py" line="26474" />
        <source>MANUAL</source>
        <translation>手动</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26475" />
        <source>FLAP</source>
        <translation>瓣膜</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26489" />
        <location filename="../artisanlib/main.py" line="26477" />
        <location filename="../artisanlib/main.py" line="26476" />
        <source>CLOSE</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26489" />
        <location filename="../artisanlib/main.py" line="26488" />
        <location filename="../artisanlib/main.py" line="26477" />
        <source>OPEN</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26478" />
        <source>CONTROL</source>
        <translation>控制</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26479" />
        <source>DISCHARGE</source>
        <translation>释放</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26481" />
        <source>HEATING</source>
        <translation>加热</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26482" />
        <source>STIRRER</source>
        <translation>搅拌器</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26483" />
        <source>FILL</source>
        <translation>充满</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26485" />
        <source>COOLING</source>
        <translation>冷却</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26496" />
        <location filename="../artisanlib/main.py" line="26491" />
        <location filename="../artisanlib/main.py" line="26490" />
        <source>STOP</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26494" />
        <source>RELEASE</source>
        <translation>发布</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27252" />
        <source>Fit</source>
        <comment>Curve Fit Type</comment>
        <translatorcomment>擬合曲線</translatorcomment>
        <translation>拟合曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27253" />
        <source>RMSE BT</source>
        <translation>均方根误差</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27254" />
        <source>MSE BT</source>
        <translation>均方误差</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="16892" />
        <location filename="../artisanlib/canvas.py" line="16881" />
        <location filename="../artisanlib/main.py" line="27255" />
        <source>RoR</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27255" />
        <source>@FCs</source>
        <translation>爆开始时</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27256" />
        <source>Max+/Max- RoR</source>
        <translation>最大+/最大- RoR</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27266" />
        <source>Curve Fit Analysis</source>
        <translation>曲线拟合分析</translation>
    </message>
    <message>
        <location filename="../artisanlib/batches.py" line="51" />
        <source>Prefix</source>
        <translation>前缀</translation>
    </message>
    <message>
        <location filename="../artisanlib/batches.py" line="54" />
        <source>Counter</source>
        <translation>计数器</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="114" />
        <source>Logging</source>
        <translation>绘制中</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="117" />
        <source>Control</source>
        <translation>控制</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="166" />
        <source>Control ET</source>
        <translation>控制ET</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="173" />
        <source>Read BT</source>
        <translation>读取BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="179" />
        <source>RS485 Unit ID</source>
        <translation>RS485 地址码</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="198" />
        <source>ET Channel</source>
        <translation>ET通道</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="201" />
        <source>BT Channel</source>
        <translation>BT通道</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="227" />
        <source>AT Channel</source>
        <translation>环境温度通道</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="236" />
        <source>Filter</source>
        <translation>筛选器</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="920" />
        <location filename="../artisanlib/devices.py" line="716" />
        <location filename="../artisanlib/devices.py" line="710" />
        <location filename="../artisanlib/devices.py" line="557" />
        <location filename="../artisanlib/devices.py" line="431" />
        <location filename="../artisanlib/devices.py" line="383" />
        <source>Async</source>
        <translation>异步</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="922" />
        <location filename="../artisanlib/devices.py" line="717" />
        <location filename="../artisanlib/devices.py" line="711" />
        <location filename="../artisanlib/devices.py" line="432" />
        <location filename="../artisanlib/devices.py" line="384" />
        <source>Change</source>
        <translation>改变</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="921" />
        <location filename="../artisanlib/devices.py" line="718" />
        <location filename="../artisanlib/devices.py" line="712" />
        <location filename="../artisanlib/devices.py" line="558" />
        <location filename="../artisanlib/devices.py" line="433" />
        <location filename="../artisanlib/devices.py" line="385" />
        <source>Rate</source>
        <translation>比率</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1011" />
        <location filename="../artisanlib/devices.py" line="452" />
        <source>Emissivity</source>
        <translation>放射率</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="555" />
        <source>Gain</source>
        <translation>增加</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="715" />
        <location filename="../artisanlib/devices.py" line="709" />
        <location filename="../artisanlib/devices.py" line="556" />
        <source>Wiring</source>
        <translation>连线</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="782" />
        <source>Power</source>
        <translation>电源</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="924" />
        <source>Range</source>
        <translation>范围</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="944" />
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="955" />
        <source>Remote Only</source>
        <translation>仅远程</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1004" />
        <source>VirtualHub</source>
        <translation>虚拟交换机</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1073" />
        <source>Ambient Source</source>
        <translation>环境源</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1123" />
        <source>MASL</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1124" />
        <source>Temperature</source>
        <translation>温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1125" />
        <source>Humidity</source>
        <translation>湿度</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1126" />
        <source>Pressure</source>
        <translation>气压</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1127" />
        <source>Elevation</source>
        <translation>海拔</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1187" />
        <source>Serial</source>
        <translation>串行</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1217" />
        <location filename="../artisanlib/devices.py" line="1191" />
        <source>WiFi</source>
        <translation>WiFi</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1195" />
        <source>Bluetooth</source>
        <translation>蓝牙</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1253" />
        <source>Mean Filter</source>
        <translation>均值滤波器</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1258" />
        <source>Median Filter</source>
        <translation>中值滤波器</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1660" />
        <location filename="../artisanlib/devices.py" line="1589" />
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1885" />
        <source>Accuracy</source>
        <translation>准确性</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="143" />
        <source>Mapping</source>
        <translation>映射</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2553" />
        <source>Preheat Measured</source>
        <translation>预热值</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2554" />
        <source>Preheat %</source>
        <translation>预热 %</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2555" />
        <source>BBP Measured</source>
        <translation>BBP值</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2556" />
        <source>BBP %</source>
        <translation>BBP %</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2557" />
        <source>Cooling Measured</source>
        <translation>冷却值</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2558" />
        <source>Cooling %</source>
        <translation>冷却 %</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2559" />
        <source>Continuous Roast</source>
        <translation>连续烘焙</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2560" />
        <source>Roast Event</source>
        <translation>烘焙事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2561" />
        <source>Meter Batch</source>
        <translation>批次计量</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2562" />
        <source>PID Duty %</source>
        <translation>PID 占空比百分比</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2563" />
        <source>Meter Preheat</source>
        <translation>预热计量</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2564" />
        <source>Meter BBP</source>
        <translation>BBP 计量</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2565" />
        <source>Meter Roast</source>
        <translation>烘焙计量</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2566" />
        <source>Meter Cooling</source>
        <translation>冷却计量</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2567" />
        <source>PID Duty % BBP</source>
        <translation>PID 占空比 BBP</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2568" />
        <source>PID Duty % Roast</source>
        <translation>PID 占空比 BBP</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2569" />
        <source>PID Duty % Cooling</source>
        <translation>PID 占空比 冷却</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2570" />
        <source>Preheat Event</source>
        <translation>预热阶段触发事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2571" />
        <source>BBP Event</source>
        <translation>BBP 事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2572" />
        <source>Cooling Event</source>
        <translation>冷却事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2573" />
        <source>PID Duty % Preheat</source>
        <translation>PID 预热占空比</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2574" />
        <source>Continuous Batch</source>
        <translation>连续批次</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2575" />
        <source>Continuous Preheat</source>
        <translation>连续预热</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2576" />
        <source>Continuous BBP</source>
        <translation>连续 BBP</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2577" />
        <source>Continuous Cooling</source>
        <translation>连续冷却</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2578" />
        <source>Event Batch</source>
        <translation>事件批次</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="4428" />
        <location filename="../artisanlib/canvas.py" line="4426" />
        <source>at</source>
        <translation>在</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="4438" />
        <source>COOL</source>
        <translation>冷却</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="9934" />
        <source>% / RPM</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="10339" />
        <source>BackgroundXT</source>
        <translation>背景曲线XT</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="10396" />
        <source>BackgroundYT</source>
        <translation>背景YT</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19072" />
        <location filename="../artisanlib/canvas.py" line="10430" />
        <source>BackgroundET</source>
        <translation>背景曲线ET</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19076" />
        <location filename="../artisanlib/canvas.py" line="10461" />
        <source>BackgroundBT</source>
        <translation>背景曲线BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="10487" />
        <source>BackgroundDeltaET</source>
        <translation>背景曲线DeltaET</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="10506" />
        <source>BackgroundDeltaBT</source>
        <translation>背景曲线DeltaBT</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12200" />
        <source>ETprojection</source>
        <translation>ET推测</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12207" />
        <source>DeltaETprojection</source>
        <translation>DeltaET推测</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12213" />
        <source>BTprojection</source>
        <translation>BT推测</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12220" />
        <source>DeltaBTprojection</source>
        <translation>DeltaBT推测</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12224" />
        <source>TIMEguide</source>
        <translation>时间指引</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12229" />
        <source>AUCguide</source>
        <translation>AUC指引</translation>
    </message>
    <message>
        <location filename="../artisanlib/cup_profile.py" line="81" />
        <location filename="../artisanlib/canvas.py" line="13873" />
        <location filename="../artisanlib/canvas.py" line="13708" />
        <location filename="../artisanlib/canvas.py" line="12871" />
        <source>Correction</source>
        <translation>杯测更正</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="16674" />
        <source>Event #&lt;b&gt;{0} &lt;/b&gt;</source>
        <translation>事件 #&lt;b&gt;{0} &lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="16894" />
        <location filename="../artisanlib/canvas.py" line="16885" />
        <source>CM</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="16896" />
        <location filename="../artisanlib/canvas.py" line="16887" />
        <source>FC</source>
        <translation>一爆</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19043" />
        <source>Designer</source>
        <translation>曲线设计器</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19856" />
        <source>BT {0} {1}/min for {2}</source>
        <translation>{2}BT {0} {1}/分钟</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19869" />
        <source>ET {0} {1}/min for {2}</source>
        <translation>{2}ET {0} {1}/分钟</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="48" />
        <source>Profile Colors</source>
        <translation>曲线颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="50" />
        <source>Background Profile Colors</source>
        <translation>背景曲线颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/cup_profile.py" line="62" />
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <location filename="../artisanlib/cup_profile.py" line="113" />
        <source>Aspect Ratio</source>
        <translation>纵横比</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2126" />
        <source>Score</source>
        <translation>分数</translation>
    </message>
    <message>
        <source>Continuous</source>
        <translation type="vanished">持续</translation>
    </message>
    <message>
        <source>Meter</source>
        <translation type="vanished">仪表</translation>
    </message>
</context><context>
    <name>MAC_APPLICATION_MENU</name>
    <message>
        <location filename="../artisanlib/main.py" line="2018" />
        <source>Services</source>
        <translation>服务</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2019" />
        <source>Hide {0}</source>
        <translation>隐藏 {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2020" />
        <source>Hide Others</source>
        <translation>隐藏其他</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2021" />
        <source>Show All</source>
        <translation>全部显示</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2022" />
        <source>Preferences...</source>
        <translation>偏好...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2417" />
        <location filename="../artisanlib/main.py" line="2023" />
        <source>Quit {0}</source>
        <translation>退出 {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2736" />
        <location filename="../artisanlib/main.py" line="2734" />
        <location filename="../artisanlib/main.py" line="2024" />
        <source>About {0}</source>
        <translation>关于 {0}</translation>
    </message>
</context><context>
    <name>Marker</name>
    <message>
        <location filename="../artisanlib/events.py" line="429" />
        <source>Circle</source>
        <translation>圆形</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="430" />
        <source>Square</source>
        <translation>方格</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="431" />
        <source>Pentagon</source>
        <translation>五角形</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="432" />
        <source>Diamond</source>
        <translation>菱形</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="433" />
        <source>Star</source>
        <translation>星形</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="434" />
        <source>Hexagon 1</source>
        <translation>六边形1</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="435" />
        <source>Hexagon 2</source>
        <translation>六边形2</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="436" />
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="437" />
        <source>x</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="438" />
        <source>None</source>
        <translation>无</translation>
    </message>
</context><context>
    <name>Menu</name>
    <message>
        <location filename="../artisanlib/main.py" line="4374" />
        <location filename="../artisanlib/pid_dialogs.py" line="751" />
        <source>Config</source>
        <translation>配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2692" />
        <location filename="../artisanlib/large_lcds.py" line="351" />
        <source>Main LCDs</source>
        <translation>主要信息LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2698" />
        <location filename="../artisanlib/large_lcds.py" line="518" />
        <source>Delta LCDs</source>
        <translation>变化率 LCDs</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2703" />
        <location filename="../artisanlib/large_lcds.py" line="572" />
        <source>PID LCDs</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2708" />
        <location filename="../artisanlib/large_lcds.py" line="620" />
        <source>Extra LCDs</source>
        <translation>额外LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2713" />
        <location filename="../artisanlib/large_lcds.py" line="742" />
        <source>Phases LCDs</source>
        <translation>阶段LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2718" />
        <location filename="../artisanlib/large_lcds.py" line="844" />
        <source>Scale LCDs</source>
        <translation>电子秤 LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5723" />
        <location filename="../artisanlib/main.py" line="2040" />
        <source>New</source>
        <translation>新建</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2044" />
        <source>Open...</source>
        <translation>打开...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2051" />
        <source>Open Recent</source>
        <translation>最近打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2061" />
        <source>Import</source>
        <translation>导入</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2159" />
        <source>Convert From</source>
        <translation>转换自</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2160" />
        <source>Cropster XLS...</source>
        <translation>Cropster XLS...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2164" />
        <source>Giesen CSV...</source>
        <translation>吉森 CSV...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2168" />
        <source>HiBean JSON...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2172" />
        <source>IKAWA CSV...</source>
        <translation>伊川 CSV...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2176" />
        <source>Kaleido CSV...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2180" />
        <source>Loring CSV...</source>
        <translation>洛林 CSV...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2184" />
        <source>Petroncini CSV...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2188" />
        <source>ROEST CSV...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2192" />
        <source>Rubase CSV...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2196" />
        <source>Stronghold XLSX...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2200" />
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2206" />
        <source>Save As...</source>
        <translation>保存为...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2213" />
        <source>Save a Copy As...</source>
        <translation>另存为...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2216" />
        <source>Export</source>
        <translation>导出</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2260" />
        <location filename="../artisanlib/main.py" line="2219" />
        <source>Artisan CSV...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2264" />
        <location filename="../artisanlib/main.py" line="2223" />
        <source>Artisan JSON...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2395" />
        <location filename="../artisanlib/main.py" line="2378" />
        <location filename="../artisanlib/main.py" line="2254" />
        <location filename="../artisanlib/main.py" line="2229" />
        <source>Excel...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2270" />
        <location filename="../artisanlib/main.py" line="2235" />
        <source>Probat Pilot...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2274" />
        <location filename="../artisanlib/main.py" line="2239" />
        <source>RoastLogger...</source>
        <translation>烘焙记录...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2243" />
        <source>Convert To</source>
        <translation>转换为</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2244" />
        <source>Fahrenheit...</source>
        <translation>华氏度...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2248" />
        <source>Celsius...</source>
        <translation>摄氏度...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2311" />
        <location filename="../artisanlib/main.py" line="2280" />
        <source>PNG...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2284" />
        <source>JPEG...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2288" />
        <source>SVG...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2400" />
        <location filename="../artisanlib/main.py" line="2384" />
        <location filename="../artisanlib/main.py" line="2367" />
        <location filename="../artisanlib/main.py" line="2354" />
        <location filename="../artisanlib/main.py" line="2292" />
        <source>PDF...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2296" />
        <source>Roast Report PDF...</source>
        <translation>烘焙报告PDF...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2302" />
        <source>Save Graph</source>
        <translation>保存图表</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2351" />
        <source>Report</source>
        <translation>报告</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4362" />
        <location filename="../artisanlib/main.py" line="2352" />
        <source>Roast</source>
        <translation>烘焙</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2389" />
        <location filename="../artisanlib/main.py" line="2372" />
        <location filename="../artisanlib/main.py" line="2360" />
        <source>Web...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2365" />
        <source>Batches</source>
        <translation>批次</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2392" />
        <location filename="../artisanlib/main.py" line="2375" />
        <source>CSV...</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2382" />
        <source>Ranking</source>
        <translation>排名</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2407" />
        <source>Print...</source>
        <translation>打印...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2423" />
        <source>Cut</source>
        <translation>剪切</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2426" />
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2429" />
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2434" />
        <source>Properties...</source>
        <translation>烘焙属性...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2439" />
        <source>Background...</source>
        <translation>背景曲线...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2443" />
        <source>Cup Profile...</source>
        <translation>杯测记录...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2446" />
        <source>Switch Profiles</source>
        <translation>切换曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2450" />
        <source>Switch ET&lt;-&gt;BT</source>
        <translation>切换ET&lt;-&gt;BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2456" />
        <source>Machine</source>
        <translation>机器</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2461" />
        <source>Device...</source>
        <translation>设备...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2465" />
        <source>Port...</source>
        <translation>端口...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2468" />
        <source>Sampling...</source>
        <translation>采样...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2471" />
        <source>Curves...</source>
        <translation>曲线...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2475" />
        <source>Events...</source>
        <translation>事件...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2479" />
        <source>Alarms...</source>
        <translation>警报...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2487" />
        <source>Phases...</source>
        <translation>阶段...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2490" />
        <source>Statistics...</source>
        <translation>统计...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2493" />
        <source>Axes...</source>
        <translation>坐标轴...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2497" />
        <source>Colors...</source>
        <translation>颜色...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2500" />
        <source>Themes</source>
        <translation>主题</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2506" />
        <source>Autosave...</source>
        <translation>自动保存...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2509" />
        <source>Batch...</source>
        <translation>批次...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2512" />
        <source>Temperature</source>
        <translation>温度单位</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2516" />
        <source>Fahrenheit Mode</source>
        <translation>华氏模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2519" />
        <source>Celsius Mode</source>
        <translation>摄氏模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2523" />
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4558" />
        <location filename="../artisanlib/main.py" line="2565" />
        <source>Mode</source>
        <translation>模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4552" />
        <location filename="../artisanlib/main.py" line="2566" />
        <source>Production</source>
        <translation>生产模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4556" />
        <location filename="../artisanlib/main.py" line="2572" />
        <source>Standard</source>
        <translation>标准</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4554" />
        <location filename="../artisanlib/main.py" line="2578" />
        <source>Expert</source>
        <translation>专家模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2587" />
        <source>Analyzer</source>
        <translation>分析</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2588" />
        <source>Auto All</source>
        <translation>全自动</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2599" />
        <location filename="../artisanlib/main.py" line="2596" />
        <location filename="../artisanlib/main.py" line="2593" />
        <source>Fit BT to</source>
        <translation>拟合BT曲线为</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2603" />
        <source>Fit BT to Bkgnd</source>
        <translation>拟合BT到背景曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2607" />
        <source>Clear results</source>
        <translation>清除结果</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2612" />
        <source>Comparator</source>
        <translation>比较器</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2617" />
        <source>Designer</source>
        <translation>曲线设计器</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2622" />
        <source>Simulator</source>
        <translation>模拟器</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2627" />
        <source>Wheel Graph</source>
        <translation>风味轮</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2632" />
        <source>Transposer</source>
        <translation>曲线配置转换</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2635" />
        <source>Convert Profile Temperature</source>
        <translation>转换配置温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2636" />
        <source>Convert to Fahrenheit</source>
        <translation>转换为华氏</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2639" />
        <source>Convert to Celsius</source>
        <translation>转换为摄氏</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2650" />
        <source>Calculator</source>
        <translation>烘焙计算器</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2655" />
        <source>Controls</source>
        <translation>控制按钮</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2661" />
        <source>Readings</source>
        <translation>显示仪表</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2667" />
        <source>Events Editor</source>
        <translation>事件 编辑器</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2673" />
        <source>Buttons</source>
        <translation>控制按钮</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2679" />
        <source>Sliders</source>
        <translation>控制滑块</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2427" />
        <location filename="../artisanlib/main.py" line="2685" />
        <source>Schedule</source>
        <translation>烘焙计划</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2723" />
        <source>Full Screen</source>
        <translation>全屏</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2742" />
        <source>About Qt</source>
        <translation>关于 Qt</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2746" />
        <source>Documentation</source>
        <translation>帮助文档</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2752" />
        <source>Keyboard Shortcuts</source>
        <translation>键盘快捷键</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2755" />
        <source>Check for Updates</source>
        <translation>检查更新</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2759" />
        <source>Errors</source>
        <translation>错误记录</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2762" />
        <source>Messages</source>
        <translation>历史信息</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2765" />
        <source>Serial</source>
        <translation>串行日志</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2769" />
        <source>Platform</source>
        <translation>Artisan 平台</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2775" />
        <source>Load Settings...</source>
        <translation>载入设置...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="2779" />
        <source>Load Recent Settings</source>
        <translation>载入近期设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5842" />
        <location filename="../artisanlib/main.py" line="2784" />
        <source>Save Settings...</source>
        <translation>保存设置...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5842" />
        <location filename="../artisanlib/main.py" line="2788" />
        <source>Factory Reset</source>
        <translation>恢复出厂设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4326" />
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4355" />
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4411" />
        <source>Tools</source>
        <translation>工具</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4430" />
        <source>View</source>
        <translation>查看</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5841" />
        <location filename="../artisanlib/main.py" line="4465" />
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6098" />
        <source>Load Theme...</source>
        <translation>载入主题...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6102" />
        <source>Save Theme...</source>
        <translation>保存主题...</translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="vanished">默认模式</translation>
    </message>
</context><context>
    <name>Message</name>
    <message>
        <location filename="../artisanlib/axis.py" line="914" />
        <source>xlimit = ({2},{3}) ylimit = ({0},{1}) zlimit = ({4},{5})</source>
        <translation>x范围 = ({2},{3}) y范围 = ({0},{1}) z范围 = ({4},{5})</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="638" />
        <source>Save Wheel graph</source>
        <translation>保存风味轮 Speichern</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="642" />
        <source>Wheel Graph saved</source>
        <translation>已保存风味轮</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19998" />
        <location filename="../artisanlib/wheels.py" line="648" />
        <source>Open Wheel Graph</source>
        <translation>打开风味轮</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="14264" />
        <location filename="../artisanlib/canvas.py" line="14251" />
        <location filename="../artisanlib/canvas.py" line="14245" />
        <location filename="../artisanlib/canvas.py" line="14225" />
        <location filename="../artisanlib/canvas.py" line="14217" />
        <location filename="../artisanlib/canvas.py" line="14202" />
        <location filename="../artisanlib/canvas.py" line="14184" />
        <location filename="../artisanlib/main.py" line="4575" />
        <location filename="../artisanlib/comm.py" line="1813" />
        <location filename="../artisanlib/comm.py" line="1070" />
        <location filename="../artisanlib/wsport.py" line="282" />
        <source>{} connected</source>
        <translation>{} 连接的</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="14265" />
        <location filename="../artisanlib/canvas.py" line="14252" />
        <location filename="../artisanlib/canvas.py" line="14246" />
        <location filename="../artisanlib/canvas.py" line="14226" />
        <location filename="../artisanlib/canvas.py" line="14218" />
        <location filename="../artisanlib/canvas.py" line="14203" />
        <location filename="../artisanlib/canvas.py" line="14185" />
        <location filename="../artisanlib/main.py" line="4582" />
        <location filename="../artisanlib/comm.py" line="1814" />
        <location filename="../artisanlib/comm.py" line="1071" />
        <location filename="../artisanlib/wsport.py" line="333" />
        <location filename="../artisanlib/wsport.py" line="318" />
        <location filename="../artisanlib/wsport.py" line="311" />
        <source>{} disconnected</source>
        <translation>{} 断开连接</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1355" />
        <source>Load Ramp/Soak Table</source>
        <translation>读取 缓升/恒温 表</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1461" />
        <source>Save Ramp/Soak Table</source>
        <translation>保存 缓升/恒温 表</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4396" />
        <location filename="../artisanlib/pid_dialogs.py" line="4384" />
        <location filename="../artisanlib/pid_dialogs.py" line="4372" />
        <location filename="../artisanlib/pid_dialogs.py" line="4360" />
        <location filename="../artisanlib/pid_dialogs.py" line="4351" />
        <location filename="../artisanlib/pid_dialogs.py" line="4348" />
        <location filename="../artisanlib/pid_dialogs.py" line="4345" />
        <location filename="../artisanlib/pid_dialogs.py" line="4339" />
        <location filename="../artisanlib/pid_dialogs.py" line="4336" />
        <location filename="../artisanlib/pid_dialogs.py" line="4333" />
        <location filename="../artisanlib/pid_dialogs.py" line="4327" />
        <location filename="../artisanlib/pid_dialogs.py" line="4324" />
        <location filename="../artisanlib/pid_dialogs.py" line="4321" />
        <location filename="../artisanlib/pid_dialogs.py" line="4315" />
        <location filename="../artisanlib/pid_dialogs.py" line="4312" />
        <location filename="../artisanlib/pid_dialogs.py" line="4309" />
        <location filename="../artisanlib/pid_dialogs.py" line="2469" />
        <location filename="../artisanlib/pid_dialogs.py" line="2457" />
        <location filename="../artisanlib/pid_dialogs.py" line="2445" />
        <location filename="../artisanlib/pid_dialogs.py" line="2433" />
        <location filename="../artisanlib/pid_dialogs.py" line="2424" />
        <location filename="../artisanlib/pid_dialogs.py" line="2421" />
        <location filename="../artisanlib/pid_dialogs.py" line="2418" />
        <location filename="../artisanlib/pid_dialogs.py" line="2412" />
        <location filename="../artisanlib/pid_dialogs.py" line="2409" />
        <location filename="../artisanlib/pid_dialogs.py" line="2406" />
        <location filename="../artisanlib/pid_dialogs.py" line="2400" />
        <location filename="../artisanlib/pid_dialogs.py" line="2397" />
        <location filename="../artisanlib/pid_dialogs.py" line="2394" />
        <location filename="../artisanlib/pid_dialogs.py" line="2388" />
        <location filename="../artisanlib/pid_dialogs.py" line="2385" />
        <location filename="../artisanlib/pid_dialogs.py" line="2382" />
        <source>OFF</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4389" />
        <location filename="../artisanlib/pid_dialogs.py" line="4383" />
        <location filename="../artisanlib/pid_dialogs.py" line="4376" />
        <location filename="../artisanlib/pid_dialogs.py" line="4370" />
        <location filename="../artisanlib/pid_dialogs.py" line="4365" />
        <location filename="../artisanlib/pid_dialogs.py" line="4364" />
        <location filename="../artisanlib/pid_dialogs.py" line="4359" />
        <location filename="../artisanlib/pid_dialogs.py" line="4358" />
        <location filename="../artisanlib/pid_dialogs.py" line="4341" />
        <location filename="../artisanlib/pid_dialogs.py" line="4335" />
        <location filename="../artisanlib/pid_dialogs.py" line="4328" />
        <location filename="../artisanlib/pid_dialogs.py" line="4322" />
        <location filename="../artisanlib/pid_dialogs.py" line="4317" />
        <location filename="../artisanlib/pid_dialogs.py" line="4316" />
        <location filename="../artisanlib/pid_dialogs.py" line="4311" />
        <location filename="../artisanlib/pid_dialogs.py" line="4310" />
        <location filename="../artisanlib/pid_dialogs.py" line="2462" />
        <location filename="../artisanlib/pid_dialogs.py" line="2456" />
        <location filename="../artisanlib/pid_dialogs.py" line="2449" />
        <location filename="../artisanlib/pid_dialogs.py" line="2443" />
        <location filename="../artisanlib/pid_dialogs.py" line="2438" />
        <location filename="../artisanlib/pid_dialogs.py" line="2437" />
        <location filename="../artisanlib/pid_dialogs.py" line="2432" />
        <location filename="../artisanlib/pid_dialogs.py" line="2431" />
        <location filename="../artisanlib/pid_dialogs.py" line="2414" />
        <location filename="../artisanlib/pid_dialogs.py" line="2408" />
        <location filename="../artisanlib/pid_dialogs.py" line="2401" />
        <location filename="../artisanlib/pid_dialogs.py" line="2395" />
        <location filename="../artisanlib/pid_dialogs.py" line="2390" />
        <location filename="../artisanlib/pid_dialogs.py" line="2389" />
        <location filename="../artisanlib/pid_dialogs.py" line="2384" />
        <location filename="../artisanlib/pid_dialogs.py" line="2383" />
        <source>CONTINUOUS CONTROL</source>
        <translation>持续控制</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4402" />
        <location filename="../artisanlib/pid_dialogs.py" line="4399" />
        <location filename="../artisanlib/pid_dialogs.py" line="4393" />
        <location filename="../artisanlib/pid_dialogs.py" line="4390" />
        <location filename="../artisanlib/pid_dialogs.py" line="4387" />
        <location filename="../artisanlib/pid_dialogs.py" line="4381" />
        <location filename="../artisanlib/pid_dialogs.py" line="4378" />
        <location filename="../artisanlib/pid_dialogs.py" line="4375" />
        <location filename="../artisanlib/pid_dialogs.py" line="4369" />
        <location filename="../artisanlib/pid_dialogs.py" line="4366" />
        <location filename="../artisanlib/pid_dialogs.py" line="4363" />
        <location filename="../artisanlib/pid_dialogs.py" line="4357" />
        <location filename="../artisanlib/pid_dialogs.py" line="4354" />
        <location filename="../artisanlib/pid_dialogs.py" line="4342" />
        <location filename="../artisanlib/pid_dialogs.py" line="4330" />
        <location filename="../artisanlib/pid_dialogs.py" line="4318" />
        <location filename="../artisanlib/pid_dialogs.py" line="2475" />
        <location filename="../artisanlib/pid_dialogs.py" line="2472" />
        <location filename="../artisanlib/pid_dialogs.py" line="2466" />
        <location filename="../artisanlib/pid_dialogs.py" line="2463" />
        <location filename="../artisanlib/pid_dialogs.py" line="2460" />
        <location filename="../artisanlib/pid_dialogs.py" line="2454" />
        <location filename="../artisanlib/pid_dialogs.py" line="2451" />
        <location filename="../artisanlib/pid_dialogs.py" line="2448" />
        <location filename="../artisanlib/pid_dialogs.py" line="2442" />
        <location filename="../artisanlib/pid_dialogs.py" line="2439" />
        <location filename="../artisanlib/pid_dialogs.py" line="2436" />
        <location filename="../artisanlib/pid_dialogs.py" line="2430" />
        <location filename="../artisanlib/pid_dialogs.py" line="2427" />
        <location filename="../artisanlib/pid_dialogs.py" line="2415" />
        <location filename="../artisanlib/pid_dialogs.py" line="2403" />
        <location filename="../artisanlib/pid_dialogs.py" line="2391" />
        <source>ON</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4401" />
        <location filename="../artisanlib/pid_dialogs.py" line="4400" />
        <location filename="../artisanlib/pid_dialogs.py" line="4395" />
        <location filename="../artisanlib/pid_dialogs.py" line="4394" />
        <location filename="../artisanlib/pid_dialogs.py" line="4388" />
        <location filename="../artisanlib/pid_dialogs.py" line="4382" />
        <location filename="../artisanlib/pid_dialogs.py" line="4377" />
        <location filename="../artisanlib/pid_dialogs.py" line="4371" />
        <location filename="../artisanlib/pid_dialogs.py" line="4353" />
        <location filename="../artisanlib/pid_dialogs.py" line="4352" />
        <location filename="../artisanlib/pid_dialogs.py" line="4347" />
        <location filename="../artisanlib/pid_dialogs.py" line="4346" />
        <location filename="../artisanlib/pid_dialogs.py" line="4340" />
        <location filename="../artisanlib/pid_dialogs.py" line="4334" />
        <location filename="../artisanlib/pid_dialogs.py" line="4329" />
        <location filename="../artisanlib/pid_dialogs.py" line="4323" />
        <location filename="../artisanlib/pid_dialogs.py" line="2474" />
        <location filename="../artisanlib/pid_dialogs.py" line="2473" />
        <location filename="../artisanlib/pid_dialogs.py" line="2468" />
        <location filename="../artisanlib/pid_dialogs.py" line="2467" />
        <location filename="../artisanlib/pid_dialogs.py" line="2461" />
        <location filename="../artisanlib/pid_dialogs.py" line="2455" />
        <location filename="../artisanlib/pid_dialogs.py" line="2450" />
        <location filename="../artisanlib/pid_dialogs.py" line="2444" />
        <location filename="../artisanlib/pid_dialogs.py" line="2426" />
        <location filename="../artisanlib/pid_dialogs.py" line="2425" />
        <location filename="../artisanlib/pid_dialogs.py" line="2420" />
        <location filename="../artisanlib/pid_dialogs.py" line="2419" />
        <location filename="../artisanlib/pid_dialogs.py" line="2413" />
        <location filename="../artisanlib/pid_dialogs.py" line="2407" />
        <location filename="../artisanlib/pid_dialogs.py" line="2402" />
        <location filename="../artisanlib/pid_dialogs.py" line="2396" />
        <source>STANDBY MODE</source>
        <translation>待机模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2478" />
        <source>The rampsoak-mode tells how to start and end the ramp/soak</source>
        <translation>缓升恒温-模式告知如何开始和结束 缓升恒温</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2479" />
        <source>Your rampsoak mode in this pid is:</source>
        <translation>你的缓升恒温模式在这个pid里是:</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2480" />
        <source>Mode = {0}</source>
        <translation>模式 = {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2482" />
        <source>Start to run from PV value: {0}</source>
        <translation>从PV值: {0}开始运行</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2483" />
        <source>End output status at the end of ramp/soak: {0}</source>
        <translation>缓升/恒温 结束时的最终输出状态: {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2484" />
        <source>Output status while ramp/soak operation set to OFF: {0}</source>
        <translation>当 缓升/恒温 操作设置为关闭时的输出状态: {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2485" />
        <source>
Repeat Operation at the end: {0}</source>
        <translation>
结束时重复操作: {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2487" />
        <source>Recommended Mode = 0</source>
        <translation>推荐模式 = 0</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2488" />
        <source>If you need to change it, change it now and come back later</source>
        <translation>如果你需要改变它，现在就改变它稍后再返回</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2489" />
        <source>Use the Parameter Loader Software by Fuji if you need to

</source>
        <translation>如果需要，请使用Fuji的参数加载软件

</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2490" />
        <source>Continue?</source>
        <translation>继续?</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4581" />
        <location filename="../artisanlib/pid_dialogs.py" line="4418" />
        <location filename="../artisanlib/pid_dialogs.py" line="2491" />
        <source>Ramp Soak start-end mode</source>
        <translation>缓升恒温 开始-结束模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3385" />
        <source>Load PID Settings</source>
        <translation>载入PID设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3464" />
        <source>Error writing PID RS value {0}</source>
        <translation>写入 PID RS 值 {0} 时出错</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3474" />
        <source>Save PID Settings</source>
        <translation>保存PID设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3682" />
        <source>Current sv = {0}. Change now to sv = {1}?</source>
        <translation>目前sv = {0}. 现在更改到sv = {1}?</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3765" />
        <location filename="../artisanlib/pid_dialogs.py" line="3683" />
        <source>Change svN</source>
        <translation>更改svN</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3764" />
        <source>Current pid = {0}. Change now to pid ={1}?</source>
        <translation>目前 pid = {0}. 现在更改到 pid ={1}?</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3804" />
        <source>Phidget Temperature Sensor IR attached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3807" />
        <source>Phidget Temperature Sensor 1-input attached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3810" />
        <source>Phidget Isolated Thermocouple 1-input attached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3816" />
        <source>Phidget VINT RTD 1-input attached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3828" />
        <source>Phidget Temperature Sensor IR detached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3830" />
        <source>Phidget Temperature Sensor 1-input detached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3832" />
        <source>Phidget Isolated Thermocouple 1-input detached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="3834" />
        <source>Phidget VINT RTD 1-input detached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="4121" />
        <source>Phidget Temperature Sensor 4-input attached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="4132" />
        <source>Phidget Temperature Sensor 4-input detached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="4431" />
        <source>Phidget 1046 attached</source>
        <translation>附Phidget 1046</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="4433" />
        <source>Phidget DAQ1500 attached</source>
        <translation>附Phidget DAQ1500</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="4445" />
        <source>Phidget 1046 detached</source>
        <translation>Phidget 1046分离</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="4447" />
        <source>Phidget DAQ1500 detached</source>
        <translation>Phidget DAQ1500分离</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6126" />
        <source>Phidget IO 2/2/2 attached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6128" />
        <source>Phidget IO 6/6/6 attached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6130" />
        <source>Phidget IO 8/8/8 attached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6132" />
        <source>Phidget DAQ1000 attached</source>
        <translation>附有 Phidg​​et DAQ1000</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6134" />
        <source>Phidget DAQ1200 attached</source>
        <translation>已连接 Phidg​​et DAQ1200</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6136" />
        <source>Phidget DAQ1300 attached</source>
        <translation>已连接 Phidg​​et DAQ1300</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6138" />
        <source>Phidget DAQ1301 attached</source>
        <translation>已连接 Phidg​​et DAQ1301</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6140" />
        <source>Phidget DAQ1400 attached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6142" />
        <source>Phidget VCP1000 attached</source>
        <translation>Phidget VCP1000 已连接</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6144" />
        <source>Phidget VCP1001 attached</source>
        <translation>Phidget VCP1001 已连接</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6146" />
        <source>Phidget VCP1002 attached</source>
        <translation>Phidget VCP1002 已连接</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6148" />
        <source>Phidget IO attached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6160" />
        <source>Phidget IO 2/2/2 detached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6162" />
        <source>Phidget IO 6/6/6 detached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6164" />
        <source>Phidget IO 8/8/8 detached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6166" />
        <source>Phidget DAQ1000 detached</source>
        <translation>Phidg​​et DAQ1000 已分离</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6168" />
        <source>Phidget DAQ1200 detached</source>
        <translation>Phidg​​et DAQ1200 分离式</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6170" />
        <source>Phidget DAQ1300 detached</source>
        <translation>Phidg​​et DAQ1300 分离式</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6172" />
        <source>Phidget DAQ1301 detached</source>
        <translation>Phidg​​et DAQ1301 分离式</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6174" />
        <source>Phidget DAQ1400 detached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6176" />
        <source>Phidget VCP1000 detached</source>
        <translation>Phidget VCP1000 分离的</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6178" />
        <source>Phidget VCP1001 detached</source>
        <translation>Phidget VCP1001 分离的</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6180" />
        <source>Phidget VCP1002 detached</source>
        <translation>Phidget VCP1002 分离的</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6182" />
        <source>Phidget IO detached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6485" />
        <source>Yocto Thermocouple attached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6487" />
        <source>Yocto IR attached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6544" />
        <source>Yocto PT100 attached</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6645" />
        <location filename="../artisanlib/comm.py" line="6583" />
        <source>Yocto Sensor attached</source>
        <translation>附有 Yocto 传感器</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6589" />
        <source>Yocto Watt Power attached</source>
        <translation>附有 Yocto Watt Power</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6595" />
        <source>Yocto Watt Energy attached</source>
        <translation>附有 Yocto Watt Energy</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6612" />
        <source>Yocto Watt Voltage attached</source>
        <translation>附有 Yocto Watt 电压</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6629" />
        <source>Yocto Watt Current attached</source>
        <translation>附有 Yocto 瓦特电流</translation>
    </message>
    <message>
        <location filename="../artisanlib/comm.py" line="6914" />
        <source>TC4 initialized</source>
        <translation>TC4 已初始化</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="206" />
        <source>Autosave ON. Prefix: {0}</source>
        <translation>打开自动保存. 前缀为: {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="211" />
        <source>Autosave OFF. Prefix: {0}</source>
        <translation>自动保存关闭. 前缀: {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24768" />
        <location filename="../artisanlib/main.py" line="14510" />
        <location filename="../artisanlib/sampling.py" line="132" />
        <location filename="../artisanlib/autosave.py" line="229" />
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="230" />
        <source>Autosave turned ON, but filepath empty!

ATTENTION: Recorded data will get cleared without confirmation</source>
        <translation>自动保存已开启，但文件路径为空

注意：记录的数据将在未经确认的情况下被清除</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1956" />
        <source>Load Palettes</source>
        <translation>载入调色板</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="652" />
        <location filename="../artisanlib/events.py" line="2948" />
        <source>Event Button table copied to clipboard</source>
        <translation>事件按钮表已复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="3724" />
        <source>Event configuration saved</source>
        <translation>事件配置已保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="3738" />
        <source>Found empty event type box</source>
        <translation>找到空的事件类型标记</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1755" />
        <source>Serial Port Settings: {0}, {1}, {2}, {3}, {4}, {5}</source>
        <translation>串行端口设置: {0}, {1}, {2}, {3}, {4}, {5}</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="282" />
        <location filename="../artisanlib/roast_properties.py" line="4649" />
        <location filename="../artisanlib/roast_properties.py" line="3748" />
        <location filename="../artisanlib/roast_properties.py" line="2721" />
        <location filename="../artisanlib/background.py" line="1133" />
        <location filename="../artisanlib/background.py" line="572" />
        <source>Data table copied to clipboard</source>
        <translation>数据表已复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="610" />
        <source>Playback Events set ON</source>
        <translation>回放事件设置为打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="674" />
        <source>Playback DROP set ON</source>
        <translation>回放排豆 设置为开</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="695" />
        <source>Playback Aid set ON at {0} secs</source>
        <translation>在{0}秒后设置打开回放辅助设备</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12373" />
        <location filename="../artisanlib/background.py" line="860" />
        <source>Load Background</source>
        <translation>载入背景曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="14061" />
        <location filename="../artisanlib/background.py" line="863" />
        <source>Reading background profile...</source>
        <translation>读取背景曲线配置...</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="4707" />
        <location filename="../artisanlib/background.py" line="1138" />
        <source>Event table copied to clipboard</source>
        <translation>事件表已复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="3884" />
        <source>The 0% value must be less than the 100% value.</source>
        <translation>0％的值必须小于100％的值。</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="4787" />
        <location filename="../artisanlib/roast_properties.py" line="4783" />
        <source>Alarms from events #{0} created</source>
        <translation>已创建来自事件#{0}的警报</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="4864" />
        <location filename="../artisanlib/roast_properties.py" line="4790" />
        <source>No events found</source>
        <translation>没有找到事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="4830" />
        <source>Event #{0} added</source>
        <translation>事件 #{0} 已添加</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="4833" />
        <source>No profile found</source>
        <translation>没有找到曲线配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="4849" />
        <source> Events #{0} deleted</source>
        <translation>事件 #{0} 已删除</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="4852" />
        <source> Event #{0} deleted</source>
        <translation> 事件 #{0} 已删除</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="5706" />
        <source>Roast properties updated but profile not saved to disk</source>
        <translation>烘焙属性已更新但曲线配置并未保存到硬盘</translation>
    </message>
    <message>
        <location filename="../artisanlib/phases.py" line="363" />
        <source>Phases changed to {0} default: {1}</source>
        <translation>阶段更改为 {0} 默认: {1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/modbusport.py" line="267" />
        <source>MODBUS disconnected</source>
        <translation>MODBUS 断开</translation>
    </message>
    <message>
        <location filename="../artisanlib/modbusport.py" line="365" />
        <source>Connected via MODBUS</source>
        <translation>已连接到通信协议</translation>
    </message>
    <message>
        <location filename="../artisanlib/designer.py" line="327" />
        <source>Not enough time points for an ET curviness of {0}. Set curviness to {1}</source>
        <translation>ET曲线{0}没有足够的时间点.设置曲线为{1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/designer.py" line="636" />
        <location filename="../artisanlib/designer.py" line="356" />
        <location filename="../artisanlib/designer.py" line="351" />
        <location filename="../artisanlib/designer.py" line="335" />
        <location filename="../artisanlib/designer.py" line="328" />
        <source>Designer Config</source>
        <translation>曲线设计器配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/designer.py" line="334" />
        <source>Not enough time points for an BT curviness of {0}. Set curviness to {1}</source>
        <translation>BT曲线{0}没有足够的时间点.设置曲线为{1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/designer.py" line="350" />
        <source>Incorrect time format. Please recheck {0} time</source>
        <translation>时间格式不正确。请重新检查{0}时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/designer.py" line="635" />
        <location filename="../artisanlib/designer.py" line="355" />
        <source>Times need to be in ascending order. Please recheck {0} time</source>
        <translation>时间需要按升序排列。请重新检查{0}时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/designer.py" line="591" />
        <source>Designer has been reset</source>
        <translation>曲线设计器已重置</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="667" />
        <location filename="../artisanlib/pid_control.py" line="653" />
        <source>RS ON</source>
        <translation>打开RS</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="670" />
        <location filename="../artisanlib/pid_control.py" line="656" />
        <source>RS OFF</source>
        <translation>关闭RS</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="672" />
        <location filename="../artisanlib/pid_control.py" line="658" />
        <source>RS on HOLD</source>
        <translation>锁定RS</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="763" />
        <source>PXG/PXF sv#{0} set to {1}</source>
        <translation>PXG/PXF sv#{0} 设置 {1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="792" />
        <source>PXR sv set to {0}</source>
        <translation>PXR sv设置为{0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="841" />
        <source>SV{0} changed from {1} to {2})</source>
        <translation>SV{0} 从{1} 更改为 {2})</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="851" />
        <source>Unable to set sv{0}</source>
        <translation>无法设置sv{0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="863" />
        <source>SV changed from {0} to {1}</source>
        <translation>SV从{0}更改为{1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="873" />
        <source>Unable to set sv</source>
        <translation>无法设置sv</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="875" />
        <source>Unable to set new sv</source>
        <translation>无法设置新sv</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="1505" />
        <source>PID turned on</source>
        <translation>打开PID</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="1530" />
        <source>PID OFF</source>
        <translation>PID关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="1556" />
        <source>PID turned off</source>
        <translation>关闭PID</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="1632" />
        <source>Ramp/Soak pattern finished</source>
        <translation>缓升/恒温 程式结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="1913" />
        <location filename="../artisanlib/pid_control.py" line="1901" />
        <location filename="../artisanlib/pid_control.py" line="1880" />
        <location filename="../artisanlib/pid_control.py" line="1874" />
        <source>p-i-d values updated</source>
        <translation>p-i-d 数值已更新</translation>
    </message>
    <message>
        <location filename="../artisanlib/sampling.py" line="37" />
        <source>Sampling</source>
        <translation>采样</translation>
    </message>
    <message>
        <location filename="../artisanlib/sampling.py" line="133" />
        <source>A tight sampling interval might lead to instability on some machines. We suggest a minimum of 1s.</source>
        <translation>紧密的采样间隔可能会导致某些机器不稳定。我们建议至少为 1s。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27492" />
        <location filename="../artisanlib/curves.py" line="1762" />
        <source>Incompatible variables found in %s</source>
        <translation>在 %s 中发现不兼容的变量</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27494" />
        <location filename="../artisanlib/curves.py" line="1764" />
        <source>Assignment problem</source>
        <translation>任务分配问题</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1799" />
        <source>New Extra Device: virtual: y1(x) =[{}]; y2(x)=[{}]</source>
        <translation>新的额外设备：虚拟：y1（x）=[{}]；y2（x）=[{}]</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="2301" />
        <source>Interpolation failed: no profile available</source>
        <translation>插值失败: 没有发现有效的曲线配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="2311" />
        <source>Sound turned ON</source>
        <translation>打开声音</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="2315" />
        <source>Sound turned OFF</source>
        <translation>关闭声音</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="758" />
        <source>Statistics configuration saved</source>
        <translation>统计配置已保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/s7port.py" line="230" />
        <source>S7 connected</source>
        <translation>S7 已连接</translation>
    </message>
    <message>
        <location filename="../artisanlib/s7port.py" line="250" />
        <source>S7 Connected</source>
        <translation>S7 已连接</translation>
    </message>
    <message>
        <location filename="../artisanlib/s7port.py" line="256" />
        <source>S7 connection failed</source>
        <translation>S7 连接失败</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5958" />
        <location filename="../artisanlib/dialogs.py" line="522" />
        <source>Port Configuration</source>
        <translation>端口配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/dialogs.py" line="525" />
        <source>Comm Port</source>
        <translation>通信端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12378" />
        <location filename="../artisanlib/alarms.py" line="634" />
        <source>Load Alarms</source>
        <translation>载入警报</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="676" />
        <source>Error loading alarm file</source>
        <translation>载入警报文件错误</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="681" />
        <source>Save Alarms</source>
        <translation>保存警报</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="1152" />
        <source>Alarm table copied to clipboard</source>
        <translation>警报表已复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="385" />
        <location filename="../artisanlib/main.py" line="367" />
        <source>URL open profile: {0}</source>
        <translation>网址打开曲线配置: {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26013" />
        <location filename="../artisanlib/main.py" line="421" />
        <source>Import Cropster XLS</source>
        <translation>导入 Cropster XLS</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26043" />
        <location filename="../artisanlib/main.py" line="425" />
        <source>Import Giesen CSV</source>
        <translation>导入 Giesen CSV</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26019" />
        <location filename="../artisanlib/main.py" line="429" />
        <source>Import Stronghold XLSX</source>
        <translation>导入 Stronghold XLSX</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="1032" />
        <source>follow on</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="1034" />
        <source>follow off</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="21846" />
        <location filename="../artisanlib/main.py" line="21807" />
        <location filename="../artisanlib/main.py" line="2399" />
        <source>Save Statistics</source>
        <translation>保存统计</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4227" />
        <source>Welcome to version {0} of Artisan!</source>
        <translation>欢迎使用Artisan的{0}版本!</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4228" />
        <source>This is a one time message to inform you about a change in Artisan.</source>
        <translation>这是一条一次性消息，通知您有关Artisan的更改.</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4229" />
        <source>If you never run older versions of Artisan you can skip this message, the change does not affect you.</source>
        <translation>如果未使用过旧版本的Artisan，则可以跳过此消息，这些更改不会影响你.</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4230" />
        <source>Artisan preserves all your configuration settings when you exit so they will automatically be available the next time you start Artisan.</source>
        <translation>退出时Artisan会保留所有配置设置，以便下次启动Artisan时它们将自动恢复。.</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4231" />
        <source>Beginning with release v2.0, settings will no longer be automatically shared at start-up with versions before v2.0.</source>
        <translation>从版本v2.0开始，在启动时将不再自动与v2.0之前的版本共享设置。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4232" />
        <source>Do not worry. Since this is the first time you opened this new version Artisan has already loaded your last used settings.</source>
        <translation>别担心。由于这是第一次打开此新版本，Artisan已加载上次使用的设置。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4233" />
        <source>To share settings between this version and Artisan versions before v2.0 use 'Help&gt;Save Settings' and 'Help&gt;Load Settings'.</source>
        <translation>若要在此版本和Artisan v2.0之前的版本之间共享设置,请使用'帮助&gt;保存设置'和'帮助&gt;载入设置'.</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4234" />
        <source>Enjoy using Artisan, The Artisan Team</source>
        <translation>希望你用的开心，Artisan团队</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4235" />
        <source>One time message about loading settings at start-up</source>
        <translation>关于启动时载入设置的一次性消息</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4239" />
        <source>Welcome to the ArtisanViewer!</source>
        <translation>欢迎来到ArtisanViewer!</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4240" />
        <source>This is a one time message to introduce you to the ArtisanViewer.</source>
        <translation>这是一次向您介绍ArtisanViewer的消息。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4241" />
        <source>The ArtisanViewer opens whenever a copy of Artisan is already running.</source>
        <translation>只要已有Artisan副本运行，ArtisanViewer便会打开。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4242" />
        <source>ArtisanViewer will preserve all your configuration settings when you exit so they will automatically be available the next time you start ArtisanViewer.</source>
        <translation>ArtisanViewer会在您退出时保留所有配置设置，以便下次启动ArtisanViewer时将自动可用。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4243" />
        <source>Caution, the only way to share settings between Artisan and ArtisanViewer is to explicitly save and load them using 'Help&gt;Save Settings' and 'Help&gt;Load Settings'.</source>
        <translation>注意，在Artisan和ArtisanViewer之间共享设置的唯一方法是使用“帮助&gt;保存设置”和“帮助&gt;加载设置”显式保存和加载它们。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4244" />
        <source>Enjoy using ArtisanViewer,</source>
        <translation>享受使用ArtisanViewer的乐趣，</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4245" />
        <source>The Artisan Team</source>
        <translation>Artisan团队</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4246" />
        <source>One time message about ArtisanViewer</source>
        <translation>关于ArtisanViewer的一次消息</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5076" />
        <source>Artisan is free to use!

To keep it free and current please support us with your donation and subscribe to artisan.plus to suppress this dialog!</source>
        <translation>Artisan 可以免费使用！

为了保持它的免费和最新，请通过您的捐赠支持我们并订阅 artisan.plus 以抑制此对话框！</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5842" />
        <source>Configure for&lt;br&gt;{0}?&lt;br&gt;&lt;br&gt;Some of your settings will be modified!&lt;br&gt;&lt;br&gt;Before proceeding it is best to save your current settings and reset Artisan&lt;br&gt;(first menu {1} &gt;&gt; {2} then {4} &gt;&gt; {3})</source>
        <translation>配置&lt;br&gt;{0}？&lt;br&gt;&lt;br&gt;您的某些设置将被修改！&lt;br&gt;&lt;br&gt;在继续之前，最好保存当前设置并重置 Artisan&lt;br&gt;（第一个菜单 {1} &gt;&gt; {2} 然后 {4} &gt;&gt; {3})</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5843" />
        <source>Adjust Settings</source>
        <translation>调整设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5878" />
        <source>Ambient</source>
        <translation>环境</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5879" />
        <source>Elevation (MASL)</source>
        <translation>海拔(MASL)</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="8127" />
        <location filename="../artisanlib/main.py" line="6081" />
        <location filename="../artisanlib/main.py" line="5887" />
        <source>Action canceled</source>
        <translation>动作已取消</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6005" />
        <location filename="../artisanlib/main.py" line="5984" />
        <location filename="../artisanlib/main.py" line="5944" />
        <location filename="../artisanlib/main.py" line="5933" />
        <location filename="../artisanlib/main.py" line="5922" />
        <location filename="../artisanlib/main.py" line="5911" />
        <location filename="../artisanlib/main.py" line="5900" />
        <source>Machine</source>
        <translation>机器</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5945" />
        <location filename="../artisanlib/main.py" line="5934" />
        <location filename="../artisanlib/main.py" line="5923" />
        <location filename="../artisanlib/main.py" line="5912" />
        <location filename="../artisanlib/main.py" line="5901" />
        <source>Network name or IP address</source>
        <translation>网络名称或IP地址</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="4270" />
        <location filename="../artisanlib/main.py" line="5978" />
        <source>Bluetootooth access denied</source>
        <translation>蓝牙访问被拒绝</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5985" />
        <source>Machine Capacity (kg)</source>
        <translation>机器容量 (kg)</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6058" />
        <source>Energy loads configured for {0} {1}kg</source>
        <translation>针对 {0} {1}kg 的能源负荷配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6059" />
        <source>Artisan configured for {0}</source>
        <translation>为{0}配置的Artisan</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25086" />
        <location filename="../artisanlib/main.py" line="6115" />
        <source>Load theme {0}?</source>
        <translation>载入主题 {0}?</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25087" />
        <location filename="../artisanlib/main.py" line="6116" />
        <source>Adjust Theme Related Settings</source>
        <translation>调整主题相关设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25093" />
        <location filename="../artisanlib/main.py" line="6122" />
        <source>Loaded theme {0}</source>
        <translation>主题 {0} 已载入</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="6314" />
        <source>Detected a color pair that may be hard to see: </source>
        <translation>监测到颜色组合难以区分: </translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27666" />
        <location filename="../artisanlib/main.py" line="27623" />
        <location filename="../artisanlib/main.py" line="7019" />
        <source>Simulator started @{}x</source>
        <translation>模拟器已开始 @{}x</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7030" />
        <source>super on</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="7033" />
        <source>super off</source>
        <translation>super aus</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="9391" />
        <source>Failed to toggle ({})</source>
        <translation>切换失败（{}）</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="9412" />
        <source>Pulse out of range (%d)</source>
        <translation>脉冲超出范围 (%d)</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="9639" />
        <source>IO Command {}] unknown</source>
        <translation>IO 命令 {}] 未知</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10160" />
        <source>Alarms on</source>
        <translation>警报打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10163" />
        <source>Alarms off</source>
        <translation>警报关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10172" />
        <source>autoCHARGE on</source>
        <translation>自动投豆打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10175" />
        <source>autoCHARGE off</source>
        <translation>自动投豆关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10184" />
        <source>autoDROP on</source>
        <translation>自动排豆打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10187" />
        <source>autoDROP off</source>
        <translation>自动排豆关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24782" />
        <location filename="../artisanlib/main.py" line="10235" />
        <location filename="../artisanlib/main.py" line="10213" />
        <source>PID set to OFF</source>
        <translation>PID 设置为OFF</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24786" />
        <location filename="../artisanlib/main.py" line="10232" />
        <location filename="../artisanlib/main.py" line="10222" />
        <source>PID set to ON</source>
        <translation>PID设置为ON</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10260" />
        <location filename="../artisanlib/main.py" line="10248" />
        <source>PID mode manual</source>
        <translation>PID手动模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10263" />
        <location filename="../artisanlib/main.py" line="10252" />
        <source>PID mode Ramp/Soak</source>
        <translation>PID模式 缓升/恒温</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10266" />
        <location filename="../artisanlib/main.py" line="10256" />
        <source>PID mode background</source>
        <translation>PID 背景曲线模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10276" />
        <source>playback off</source>
        <translation>回放关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10280" />
        <source>playback by time</source>
        <translation>按时间回放</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10284" />
        <source>playback by BT</source>
        <translation>按BT回放</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10288" />
        <source>playback by ET</source>
        <translation>按ET回放</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10292" />
        <source>playback by time/BT</source>
        <translation>按时间/BT播放</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10296" />
        <source>playback by time/ET</source>
        <translation>按时间/ET播放</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10308" />
        <source>playback DROP off</source>
        <translation>播放中断</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10312" />
        <source>playback DROP by time</source>
        <translation>播放按时间 DROP</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10316" />
        <source>playback DROP by BT</source>
        <translation>通过 BT 播放 DROP</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10320" />
        <source>playback DROP by ET</source>
        <translation>播放 ET 的 DROP</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10384" />
        <source>Notifications on</source>
        <translation>通知于</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10387" />
        <source>Notifications off</source>
        <translation>关闭通知</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12445" />
        <location filename="../artisanlib/main.py" line="12442" />
        <location filename="../artisanlib/main.py" line="12428" />
        <location filename="../artisanlib/main.py" line="12425" />
        <location filename="../artisanlib/main.py" line="10808" />
        <location filename="../artisanlib/main.py" line="10805" />
        <source>PID Lookahead: {0}</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10816" />
        <source>Replay Lookahead: {0}</source>
        <translation>重播前瞻：{0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10834" />
        <source>Keep ON enabled</source>
        <translation>保持启用状态</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="10837" />
        <source>Keep ON disable</source>
        <translation>保持开启禁用</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="11537" />
        <source>Do you want to reset all settings?&lt;br&gt; ArtisanViewer has to be restarted!</source>
        <translation>你想要重置所有设置吗?&lt;br&gt; ArtisanViewer将被重启!</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="11539" />
        <source>Do you want to reset all settings?&lt;br&gt; Artisan has to be restarted!</source>
        <translation>你确认想要重置所有设置吗?&lt;br&gt; Artisan将会重启!</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="11554" />
        <location filename="../artisanlib/main.py" line="11545" />
        <source>Factory Reset</source>
        <translation>恢复出厂设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12344" />
        <source>Auto Axis Graph Mode: Roast</source>
        <translation>自动轴图模式：烘焙</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12346" />
        <source>Auto Axis Graph Mode: BBP+Roast</source>
        <translation>自动轴图模式：BBP+Roast</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12348" />
        <source>Auto Axis Graph Mode: BBP</source>
        <translation>自动轴图模式：BBP</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12354" />
        <source>Auto Axis Graph Mode is off</source>
        <translation>自动轴图模式已关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12409" />
        <location filename="../artisanlib/main.py" line="12393" />
        <source>PID Mode: Ramp/Soak</source>
        <translation>PID模式: 缓升/恒温</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12411" />
        <location filename="../artisanlib/main.py" line="12398" />
        <source>PID Mode: Background</source>
        <translation>PID 模式: 背景曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12407" />
        <location filename="../artisanlib/main.py" line="12402" />
        <source>PID Mode: Manual</source>
        <translation>PID 模式: 手动</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12553" />
        <source>Exit Designer?</source>
        <translation>退出曲线设计器?</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12554" />
        <source>Designer Mode ON</source>
        <translation>打开曲线设计模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12641" />
        <source>LCD cursor on profile data</source>
        <translation>配置文件数据上的 LCD 光标</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12644" />
        <source>LCD cursor on template data</source>
        <translation>模板数据上的 LCD 光标</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12647" />
        <source>LCD cursor OFF</source>
        <translation>LCD 光标关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12856" />
        <source>Keyboard moves turned ON</source>
        <translation>已打开键盘移动</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="12864" />
        <source>Keyboard moves turned OFF</source>
        <translation>已关闭键盘移动</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13195" />
        <source>Profile {0} saved in: {1}</source>
        <translation>配置 {0} 已保存到: {1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13199" />
        <source>Autosave path does not exist. Autosave failed.</source>
        <translation>自动保存路径不存在.自动保存失败.</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13336" />
        <source>Event #{0}:  {1} has been updated</source>
        <translation>事件 #{0}:  {1} 已经更新</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13414" />
        <source>Select</source>
        <translation>选择</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13441" />
        <location filename="../artisanlib/main.py" line="13429" />
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13443" />
        <source>URL</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13461" />
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13479" />
        <source>Select Directory</source>
        <translation>选择目录</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13517" />
        <source>NEW ROAST canceled: incomplete profile lacking CHARGE and DROP found</source>
        <translation>新烘焙已取消: 发现不完整的曲线配置缺少投豆和排豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13522" />
        <source>NEW ROAST canceled: incomplete profile lacking DROP found</source>
        <translation>新烘焙已取消: 发现不完整的曲线配置缺少排豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13538" />
        <source>New roast has started</source>
        <translation>新一轮烘焙开始了</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27669" />
        <location filename="../artisanlib/main.py" line="14344" />
        <location filename="../artisanlib/main.py" line="13574" />
        <source>Invalid artisan format</source>
        <translation>无效Artisan格式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13670" />
        <source>{0}  loaded </source>
        <translation>{0}已载入 </translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13918" />
        <source>No profile data.  ET/BT not recalculated</source>
        <translation>没有配置数据.ET/BT未重新计算</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="13921" />
        <source>Problem with the profile data.  ET/BT not recalculated</source>
        <translation>配置数据中发现问题.ET/BT未重新计算</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="14338" />
        <source>Background {0} loaded successfully {1}</source>
        <translation>背景曲线 {0} 已成功载入 {1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="14479" />
        <source>Artisan JSON file saved successfully</source>
        <translation>Artisan JSON 文件保存成功</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="14510" />
        <source>The Probat Shop Pilot Software expects files named &lt;Name&gt;_&lt;Index&gt;.xml like in Test_0.xml on import</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="14740" />
        <location filename="../artisanlib/main.py" line="14720" />
        <source>Artisan JSON file loaded successfully</source>
        <translation>Artisan JSON 文件加载成功</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="14755" />
        <source>RoastLogger file loaded successfully</source>
        <translation>RoastLogger 文件加载成功</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="15060" />
        <source>Artisan CSV file saved successfully</source>
        <translation>Artisan CSV 文件已成功保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="15673" />
        <source>To fully load this profile the extra device configuration needs to be modified.

Overwrite your extra device definitions using the values from the profile?

It is advisable to save your current settings beforehand via menu Help &gt;&gt; Save Settings.</source>
        <translation>要完全加载此配置文件,需要修改额外的设备配置.

使用配置文件中的值覆盖额外的设备定义?

建议先保存当前设置（菜单 帮助, &gt;&gt; 保存设置).</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="15677" />
        <source>Found a different set of extra devices</source>
        <translation>发现额外设备的一个不同设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17210" />
        <source>Save Profile</source>
        <translation>保存曲线配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17230" />
        <source>Profile saved</source>
        <translation>配置已保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25143" />
        <location filename="../artisanlib/main.py" line="25073" />
        <location filename="../artisanlib/main.py" line="25005" />
        <location filename="../artisanlib/main.py" line="24931" />
        <location filename="../artisanlib/main.py" line="17711" />
        <location filename="../artisanlib/main.py" line="17274" />
        <location filename="../artisanlib/main.py" line="17258" />
        <location filename="../artisanlib/main.py" line="17256" />
        <source>Cancelled</source>
        <translation>已取消</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17272" />
        <source>Readings exported</source>
        <translation>已导出读数</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17282" />
        <source>Export Excel</source>
        <translation>导出 Excel</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17287" />
        <source>Export CSV</source>
        <translation>导出CSV</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17292" />
        <source>Export JSON</source>
        <translation>导出JSON</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17297" />
        <source>Export RoastLogger</source>
        <translation>导出烘焙记录</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17302" />
        <source>Export Probat Pilot</source>
        <translation>导出 Probat Pilot</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17667" />
        <location filename="../artisanlib/main.py" line="17614" />
        <location filename="../artisanlib/main.py" line="17572" />
        <location filename="../artisanlib/main.py" line="17509" />
        <location filename="../artisanlib/main.py" line="17429" />
        <location filename="../artisanlib/main.py" line="17382" />
        <source>Converting...</source>
        <translation>转换...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17689" />
        <location filename="../artisanlib/main.py" line="17636" />
        <location filename="../artisanlib/main.py" line="17594" />
        <location filename="../artisanlib/main.py" line="17541" />
        <location filename="../artisanlib/main.py" line="17451" />
        <location filename="../artisanlib/main.py" line="17408" />
        <location filename="../artisanlib/main.py" line="17406" />
        <source>Target file {0} exists. {1} not converted.</source>
        <translation>目标文件 {0} 存在.{1} 不转换</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17709" />
        <source>Readings imported</source>
        <translation>已导入读数</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17739" />
        <source>Import Artisan URL</source>
        <translation>导入 Artisan URL</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17746" />
        <source>Import CSV</source>
        <translation>导入CSV</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17751" />
        <source>Import JSON</source>
        <translation>导入JSON</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17756" />
        <source>Import RoastLogger</source>
        <translation>导入烘焙记录</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17900" />
        <source>Your batch counter is currently turned off. Turn it on and set it to {} from the settings file to be imported?</source>
        <translation>您的批次计数器目前已关闭。请将其打开，并从要导入的设置文件中将其设置为 {}？</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17902" />
        <source>Your batch counter is set to {}. Turn it off as in the settings file to be imported?</source>
        <translation>您的批次计数器设置为 {}。要像要导入的设置文件一样将其关闭吗？</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17904" />
        <source>Overwrite your current batch counter {} by {} from the settings file to be imported?</source>
        <translation>是否使用要导入的设置文件中的 {} 覆盖您当前的批次计数器 {}？</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17905" />
        <source>Batch Counter</source>
        <translation>批次计数器</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="17908" />
        <source>Load Settings canceled</source>
        <translation>已取消载入设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="21851" />
        <location filename="../artisanlib/main.py" line="21812" />
        <source>Statistics Saved</source>
        <translation>统计已保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="21834" />
        <source>No statistics found</source>
        <translation>没有找到统计</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22030" />
        <source>Excel Production Report exported to {0}</source>
        <translation>Excel生产报告{0}已导出</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22828" />
        <source>Ranking Report</source>
        <translation>排名报告</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="22829" />
        <source>Ranking graphs are only generated up to {0} profiles</source>
        <translation>排名图最多只能生成{0}个配置文件</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23038" />
        <source>Profile missing DRY event</source>
        <translation>配置文件缺少 DRY 事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23053" />
        <source>Profile missing phase events</source>
        <translation>配置缺少阶段事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23337" />
        <source>CSV Ranking Report exported to {0}</source>
        <translation>CSV排名报告已导出到{0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="23405" />
        <source>Excel Ranking Report exported to {0}</source>
        <translation>Excel 排名报告{0} 已导出</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24745" />
        <source>Hottop control turned off</source>
        <translation>Hottop 控制已关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24764" />
        <source>Hottop control turned on</source>
        <translation>Hottop 控制已打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24768" />
        <source>To control a Hottop you need to activate the super user mode via a right click on the timer LCD first!</source>
        <translation>要控制Hottop先需要右键点击计时器LCD,激活超级用户模式!</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25045" />
        <location filename="../artisanlib/main.py" line="24975" />
        <source>Settings not found</source>
        <translation>没有找到设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24985" />
        <source>artisan-settings</source>
        <translation>artisan设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24986" />
        <source>Save Settings</source>
        <translation>保存设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="24990" />
        <source>Settings saved</source>
        <translation>设置已保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25052" />
        <source>artisan-theme</source>
        <translation>artisan主题</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25053" />
        <source>Save Theme</source>
        <translation>保存主题</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25056" />
        <source>Theme saved</source>
        <translation>主题已保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25084" />
        <source>Load Theme</source>
        <translation>载入主题</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25110" />
        <source>Theme loaded</source>
        <translation>主题已载入</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25314" />
        <source>Background profile removed</source>
        <translation>删除背景资料</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25457" />
        <source>Alarm Config</source>
        <translation>警报配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25458" />
        <source>Alarms are not available for device None</source>
        <translation>警报不适用于未连接设备</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25475" />
        <source>Switching the language needs a restart. Restart now?</source>
        <translation>切换语言需要重启.现在就重启吗?</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25477" />
        <source>Restart</source>
        <translation>重启</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25521" />
        <source>Import K202 CSV</source>
        <translation>导入K202 CSV</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25571" />
        <source>K202 file loaded successfully</source>
        <translation>K202文件已成功载入</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25587" />
        <source>Import K204 CSV</source>
        <translation>导入K204 CSV</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25651" />
        <source>K204 file loaded successfully</source>
        <translation>K204文件已成功载入</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25681" />
        <source>Import Probat Recipe</source>
        <translation>导入 Probat Pilot</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25865" />
        <source>Probat Pilot data imported successfully</source>
        <translation>Probat Pilot数据已导入成功</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25875" />
        <source>Import Probat Pilot failed</source>
        <translation>导入Probat Pilot失败</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25997" />
        <location filename="../artisanlib/main.py" line="25951" />
        <source>{0} imported</source>
        <translation>{0} 已导入</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="25954" />
        <source>an error occurred on importing {0}</source>
        <translation>导入 {0} 时出错</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26025" />
        <source>Import RoastLog URL</source>
        <translation>导入RoastLog网址</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26037" />
        <source>Import HiBean JSON</source>
        <translation>导入 HiBean JSON</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26049" />
        <source>Import Petroncini CSV</source>
        <translation>导入Petroncini CSV</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26055" />
        <source>Import IKAWA URL</source>
        <translation>导入 IKAWA 网址</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26061" />
        <source>Import IKAWA CSV</source>
        <translation>导入 IKAWA CSV</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26067" />
        <source>Import Kaleido CSV</source>
        <translation>导入 Kaleido CSV</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26073" />
        <source>Import Loring CSV</source>
        <translation>导入 Loring CSV</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26079" />
        <source>Import ROEST CSV</source>
        <translation>导入 ROEST CSV</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26085" />
        <source>Import Rubasse CSV</source>
        <translation>导入 Rubasse CSV</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26092" />
        <source>Import HH506RA CSV</source>
        <translation>导入HH506RA CSV</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26141" />
        <source>HH506RA file loaded successfully</source>
        <translation>HH506RA文件已成功载入</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26221" />
        <source>Save Graph as</source>
        <translation>保存图表为</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26282" />
        <source>{0}  size({1},{2}) saved</source>
        <translation>{0}  尺寸({1},{2}) 已保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26293" />
        <source>Save Graph as PDF</source>
        <translation>保存图表为PDF格式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26295" />
        <source>Save Graph as SVG</source>
        <translation>保存图表为SVG格式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26334" />
        <source>{0} saved</source>
        <translation>{0}已保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26395" />
        <source>Wheel {0} loaded</source>
        <translation>风味轮 {0} 已载入</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26398" />
        <source>Invalid Wheel graph format</source>
        <translation>无效的风味轮格式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26755" />
        <source>Buttons copied to Palette #</source>
        <translation>复制到调色板的按钮 #</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26818" />
        <source>Palette #%i restored</source>
        <translation>调色板 #%i 已恢复</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26823" />
        <source>Palette #%i empty</source>
        <translation>调色板 #%i 为空</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26848" />
        <source>Save Palettes</source>
        <translation>保存调色板</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26852" />
        <source>Palettes saved</source>
        <translation>调色板已保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26989" />
        <source>Palettes loaded</source>
        <translation>已载入调色板</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26992" />
        <source>Invalid palettes file format</source>
        <translation>无效的调色板文件格式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27031" />
        <source>Alarms loaded</source>
        <translation>已载入警报</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27105" />
        <source>Fitting curves...</source>
        <translation>拟合曲线中...</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27362" />
        <source>Warning: The start of the analysis interval of interest is earlier than the start of curve fitting.
Correct this on the Config&gt;Curves&gt;Analyze tab.</source>
        <translation>警告：相关分析区间的起始时间早于曲线拟合的起始时间。
请在 “配置&gt; 曲线 &gt; 分析” 选项卡上更正此问题。</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27364" />
        <source>Analysis earlier than Curve fit</source>
        <translation>在曲线拟合前分析</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27633" />
        <source>Simulator stopped</source>
        <translation>模拟器已停止</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="27956" />
        <source>debug logging ON</source>
        <translation>调试记录打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/batches.py" line="55" />
        <source>Next batch: counter+1</source>
        <translation>下一批次: 计数器 + 1</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3037" />
        <source>Device table copied to clipboard</source>
        <translation>设备表已复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3252" />
        <source>Overwrite existing ET and BT values?</source>
        <translation>覆盖现有的 ET 和 BT 值？</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3266" />
        <location filename="../artisanlib/devices.py" line="3254" />
        <source>Caution - About to overwrite profile data</source>
        <translation>注意-关于将覆盖配置文件数据的信息</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3264" />
        <source>At least one Virtual Extra Device depends on ET or BT.  Do you want to update all the Virtual Extra Devices after ET and BT are updated?</source>
        <translation>至少一个虚拟额外设备取决于ET或BT。您是否要在ET和BT更新后更新所有Virtual Extra设备？</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3281" />
        <source>Symbolic values updated.</source>
        <translation>符号值已更新。</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3283" />
        <source>Symbolic values were not updated.</source>
        <translation>符号值未更新。</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3285" />
        <source>Nothing here to process.</source>
        <translation>这里没有要处理的东西。</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3464" />
        <source>Device not set</source>
        <translation>设备没有设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3751" />
        <location filename="../artisanlib/devices.py" line="3736" />
        <location filename="../artisanlib/devices.py" line="3559" />
        <location filename="../artisanlib/devices.py" line="3554" />
        <source>Device set to {0}. Now, check Serial Port settings</source>
        <translation>设备设置为{0}.请先检查串行端口设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="4352" />
        <location filename="../artisanlib/devices.py" line="4343" />
        <location filename="../artisanlib/devices.py" line="4193" />
        <location filename="../artisanlib/devices.py" line="4135" />
        <location filename="../artisanlib/devices.py" line="4090" />
        <location filename="../artisanlib/devices.py" line="4078" />
        <location filename="../artisanlib/devices.py" line="3998" />
        <location filename="../artisanlib/devices.py" line="3955" />
        <location filename="../artisanlib/devices.py" line="3913" />
        <location filename="../artisanlib/devices.py" line="3903" />
        <location filename="../artisanlib/devices.py" line="3891" />
        <location filename="../artisanlib/devices.py" line="3879" />
        <location filename="../artisanlib/devices.py" line="3824" />
        <location filename="../artisanlib/devices.py" line="3715" />
        <location filename="../artisanlib/devices.py" line="3625" />
        <location filename="../artisanlib/devices.py" line="3598" />
        <location filename="../artisanlib/devices.py" line="3589" />
        <location filename="../artisanlib/devices.py" line="3580" />
        <location filename="../artisanlib/devices.py" line="3570" />
        <source>Device set to {0}. Now, choose serial port</source>
        <translation>设备设置为 {0}.请先选择串行端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3607" />
        <source>Device set to CENTER 305, which is equivalent to CENTER 306. Now, choose serial port</source>
        <translation>设备设置为CENTER 305, 与CENTER 306相同.请先选择串行端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="4441" />
        <location filename="../artisanlib/devices.py" line="3661" />
        <location filename="../artisanlib/devices.py" line="3616" />
        <source>Device set to {0}, which is equivalent to CENTER 309. Now, choose serial port</source>
        <translation>设备设置为{0},与CENTER 309相同.请先选择串行端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3688" />
        <location filename="../artisanlib/devices.py" line="3679" />
        <location filename="../artisanlib/devices.py" line="3652" />
        <location filename="../artisanlib/devices.py" line="3643" />
        <location filename="../artisanlib/devices.py" line="3634" />
        <source>Device set to {0}, which is equivalent to CENTER 303. Now, choose serial port</source>
        <translation>设备设置为{0},与CENTER 303相同.请先选择串行端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3670" />
        <source>Device set to {0}, which is equivalent to CENTER 306. Now, choose serial port</source>
        <translation>设备设置为{0},与CENTER 306相同.请先选择串行端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3697" />
        <source>Device set to {0}, which is equivalent to Omega HH506RA. Now, choose serial port</source>
        <translation>设备设置为{0},与Omega HH506RA相同.请先选择串行端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3794" />
        <location filename="../artisanlib/devices.py" line="3706" />
        <source>Device set to {0}, which is equivalent to Omega HH806AU. Now, choose serial port</source>
        <translation>设备设置为{0},与Omega HH806AU相同.请先选择串行端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="4411" />
        <location filename="../artisanlib/devices.py" line="4404" />
        <location filename="../artisanlib/devices.py" line="4398" />
        <location filename="../artisanlib/devices.py" line="4386" />
        <location filename="../artisanlib/devices.py" line="4380" />
        <location filename="../artisanlib/devices.py" line="4371" />
        <location filename="../artisanlib/devices.py" line="4357" />
        <location filename="../artisanlib/devices.py" line="4318" />
        <location filename="../artisanlib/devices.py" line="4310" />
        <location filename="../artisanlib/devices.py" line="4302" />
        <location filename="../artisanlib/devices.py" line="4285" />
        <location filename="../artisanlib/devices.py" line="4267" />
        <location filename="../artisanlib/devices.py" line="4252" />
        <location filename="../artisanlib/devices.py" line="4246" />
        <location filename="../artisanlib/devices.py" line="4234" />
        <location filename="../artisanlib/devices.py" line="4228" />
        <location filename="../artisanlib/devices.py" line="4222" />
        <location filename="../artisanlib/devices.py" line="4216" />
        <location filename="../artisanlib/devices.py" line="4210" />
        <location filename="../artisanlib/devices.py" line="4204" />
        <location filename="../artisanlib/devices.py" line="4182" />
        <location filename="../artisanlib/devices.py" line="4176" />
        <location filename="../artisanlib/devices.py" line="4170" />
        <location filename="../artisanlib/devices.py" line="4164" />
        <location filename="../artisanlib/devices.py" line="4158" />
        <location filename="../artisanlib/devices.py" line="4152" />
        <location filename="../artisanlib/devices.py" line="4117" />
        <location filename="../artisanlib/devices.py" line="4108" />
        <location filename="../artisanlib/devices.py" line="4104" />
        <location filename="../artisanlib/devices.py" line="4100" />
        <location filename="../artisanlib/devices.py" line="4069" />
        <location filename="../artisanlib/devices.py" line="4063" />
        <location filename="../artisanlib/devices.py" line="4057" />
        <location filename="../artisanlib/devices.py" line="4051" />
        <location filename="../artisanlib/devices.py" line="4045" />
        <location filename="../artisanlib/devices.py" line="4039" />
        <location filename="../artisanlib/devices.py" line="4033" />
        <location filename="../artisanlib/devices.py" line="4021" />
        <location filename="../artisanlib/devices.py" line="4006" />
        <location filename="../artisanlib/devices.py" line="3981" />
        <location filename="../artisanlib/devices.py" line="3977" />
        <location filename="../artisanlib/devices.py" line="3964" />
        <location filename="../artisanlib/devices.py" line="3960" />
        <location filename="../artisanlib/devices.py" line="3935" />
        <location filename="../artisanlib/devices.py" line="3931" />
        <location filename="../artisanlib/devices.py" line="3927" />
        <location filename="../artisanlib/devices.py" line="3917" />
        <location filename="../artisanlib/devices.py" line="3870" />
        <location filename="../artisanlib/devices.py" line="3858" />
        <location filename="../artisanlib/devices.py" line="3849" />
        <location filename="../artisanlib/devices.py" line="3846" />
        <location filename="../artisanlib/devices.py" line="3843" />
        <location filename="../artisanlib/devices.py" line="3828" />
        <location filename="../artisanlib/devices.py" line="3812" />
        <location filename="../artisanlib/devices.py" line="3803" />
        <location filename="../artisanlib/devices.py" line="3719" />
        <source>Device set to {0}</source>
        <translation>设备设置为{0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3724" />
        <source>Device set to {0}{1}</source>
        <translation>设备设置为{0}{1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3776" />
        <source>Device set to {0}. Now, choose Modbus serial port or IP address</source>
        <translation>设备设置为 {0}.请选择通讯协议串行端口或IP地址</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="3785" />
        <source>Device set to {0}, which is equivalent to CENTER 302. Now, choose serial port</source>
        <translation>设备设置为{0},与CENTER 302相同.请先选择串行端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="2746" />
        <source>set y-coordinate to {}</source>
        <translation>将 y 坐标设置为 {}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="3234" />
        <source>seconds before FCs</source>
        <translation>秒在第一次爆裂前</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="3237" />
        <source>seconds after FCs</source>
        <translation>秒在第一次爆裂后</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="4652" />
        <source>Alarm notice</source>
        <translation>警报通知</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="6381" />
        <source>Alarm is calling: {0}</source>
        <translation>警报正在响: {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="6383" />
        <source>Calling alarm failed on {0}</source>
        <translation>调用警报失败: {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="6398" />
        <source>Alarm trigger button error, description '{0}' not a number</source>
        <translation>报警触发按钮错误, 类型 '{0}' 不是一个数字</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="6426" />
        <source>Alarm trigger slider error, description '{0}' not a valid number [0-100]</source>
        <translation>报警触发滑动条错误, 类型 '{0}' 不是一个有效数字[0-100]</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="6509" />
        <source>Alarm trigger SV slider error, description '{0}' not a valid number</source>
        <translation>警报触发 SV 滑动条错误, 说明 '{0}' 不是一个有效数字</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="6527" />
        <source>Alarm {0} triggered</source>
        <translation>警报 {0} 触发</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="8110" />
        <source>Save profile?</source>
        <translation>保存个人信息？</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="8119" />
        <source>Profile unsaved</source>
        <translation>配置未保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="8278" />
        <source>Scope has been reset</source>
        <translation>记录仪已重置</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12624" />
        <source>Load Image File</source>
        <translation>载入图像文件</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12631" />
        <source>Loaded watermark image {0}</source>
        <translation>载入水印图像{0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="12642" />
        <source>Unable to load watermark image {0}</source>
        <translation>无法加载水印图像 {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="13349" />
        <source>Convert profile data to Fahrenheit?</source>
        <translation>转换配置数据为华氏度?</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="13462" />
        <location filename="../artisanlib/canvas.py" line="13410" />
        <location filename="../artisanlib/canvas.py" line="13400" />
        <location filename="../artisanlib/canvas.py" line="13350" />
        <source>Convert Profile Temperature</source>
        <translation>转换配置温度单位</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="13397" />
        <source>Profile changed to Fahrenheit</source>
        <translation>配置转换为华氏度</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="13401" />
        <source>Unable to comply. You already are in Fahrenheit</source>
        <translation>无法操作.你目前正在使用华氏度</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="13464" />
        <location filename="../artisanlib/canvas.py" line="13402" />
        <source>Profile not changed</source>
        <translation>配置没有被改变</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="13409" />
        <source>Convert profile data to Celsius?</source>
        <translation>转换配置数据为摄氏度?</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="13459" />
        <source>Profile changed to Celsius</source>
        <translation>配置转换为摄氏度</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="13463" />
        <source>Unable to comply. You already are in Celsius</source>
        <translation>无法操作.你目前正在使用摄氏度</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="13471" />
        <source>Convert Profile Scale</source>
        <translation>转换配置范围</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="13472" />
        <source>No profile data found</source>
        <translation>没有找到配置数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="13499" />
        <location filename="../artisanlib/canvas.py" line="13483" />
        <source>Colors set to defaults</source>
        <translation>恢复默认颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="13487" />
        <source>Colors set to Default Theme</source>
        <translation>颜色设置为主题默认</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="13503" />
        <source>Colors set to grey</source>
        <translation>颜色设置为灰色</translation>
    </message>
    <message>
        <location filename="../artisanlib/cup_profile.py" line="258" />
        <location filename="../artisanlib/canvas.py" line="13764" />
        <source>Background does not match number of labels</source>
        <translation>背景曲线不符合标签编号</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="13999" />
        <source>Phidget service discovery started...</source>
        <translation>Phidg​​et 服务发现开始...</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="14255" />
        <source>scanning for device</source>
        <translation>扫描设备</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="14287" />
        <source>Scope monitoring...</source>
        <translation>记录监测中...</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="14453" />
        <source>Scope stopped</source>
        <translation>记录停止</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="14745" />
        <source>Humidity: {}%</source>
        <translation>湿度: {}%</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="14753" />
        <source>Temperature: {}{}</source>
        <translation>温度: {}{}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="14759" />
        <source>Pressure: {}hPa</source>
        <translation>气压: {}hPa</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15074" />
        <source>Scope recording...</source>
        <translation>记录仪记录中...</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15176" />
        <source>Scope recording stopped</source>
        <translation>记录仪记录已停止</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15315" />
        <source>Not enough data collected yet. Try again in a few seconds</source>
        <translation>还没有收集到足够的数据.几秒钟后再试一次</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15375" />
        <source>CHARGE: Scope is not recording</source>
        <translation>投豆：记录仪未在录制中</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15400" />
        <source>Roast time starts now 00:00 BT = {0}</source>
        <translation>烘焙计时现在开始 00:00 BT = {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15434" />
        <source>[TP] recorded at {0} BT = {1}</source>
        <translation>[TP] 记录于 {0} BT = {1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15518" />
        <source>DRY END: Scope is not recording</source>
        <translation>脱水结束：记录仪未在录制中</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15554" />
        <source>[DRY END] recorded at {0} BT = {1}</source>
        <translation>[脱水结束] 记录于 {0} BT = {1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15631" />
        <source>FC START: Scope is not recording</source>
        <translation>第一次爆裂：记录仪未在录制中</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15669" />
        <source>[FC START] recorded at {0} BT = {1}</source>
        <translation>[第一次爆裂] 记录于 {0} BT = {1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15737" />
        <source>FC END: Scope is not recording</source>
        <translation>一爆结束：记录仪未在录制中</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15779" />
        <source>[FC END] recorded at {0} BT = {1}</source>
        <translation>[一爆结束] 记录于 {0} BT = {1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15847" />
        <source>SC START: Scope is not recording</source>
        <translation>第二次爆裂：记录仪未在录制中</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15895" />
        <source>[SC START] recorded at {0} BT = {1}</source>
        <translation>[第二次爆裂] 记录于 {0} BT = {1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15963" />
        <source>SC END: Scope is not recording</source>
        <translation>二爆结束：记录仪未在录制中</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="16010" />
        <source>[SC END] recorded at {0} BT = {1}</source>
        <translation>[二爆结束] 记录于 {0} BT = {1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="16144" />
        <source>DROP: Scope is not recording</source>
        <translation>排豆：记录仪未在录制中</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="16197" />
        <source>Roast ended at {0} BT = {1}</source>
        <translation>烘焙结束于 {0} BT = {1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="16277" />
        <source>COOL: Scope is not recording</source>
        <translation>冷却：记录仪未在录制中</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="16326" />
        <source>[COOL END] recorded at {0} BT = {1}</source>
        <translation>[冷却结束] 记录于 {0} BT = {1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="16721" />
        <location filename="../artisanlib/canvas.py" line="16671" />
        <source>Event # {0} recorded at BT = {1}{2} Time = {3}</source>
        <translation>事件 # {0} 记录于 BT = {1}{2} 时间 = {3}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="16691" />
        <source>Timer is OFF</source>
        <translation>计时器已关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="18169" />
        <source>Unable to move background</source>
        <translation>无法移动背景曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="18221" />
        <source>No finished profile found</source>
        <translation>没有发现已完成的曲线配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="18238" />
        <source>Polynomial coefficients (Horner form):</source>
        <translation>多项式系数 (来自Horner):</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="18240" />
        <source>Knots:</source>
        <translation>节点：</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="18242" />
        <source>Residual:</source>
        <translation>剩余：</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="18244" />
        <source>Roots:</source>
        <translation>根源：</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="18247" />
        <source>Profile information</source>
        <translation>配置信息</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="18741" />
        <source>Save Points</source>
        <translation>保存点</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="18750" />
        <source>Points saved</source>
        <translation>点已保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="18760" />
        <source>Load Points</source>
        <translation>载入点</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="18772" />
        <source>Points loaded</source>
        <translation>点已载入</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="18850" />
        <source>Designer Init</source>
        <translation>初始化曲线设计器</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="18851" />
        <source>Unable to start designer.
Profile missing [CHARGE] or [DROP]</source>
        <translation>无法开始曲线设计.曲线配置缺少[投豆]或[排豆]</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="19792" />
        <source>New profile created</source>
        <translation>新的曲线配置已创建</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="20012" />
        <source> added to cupping notes</source>
        <translation> 已添加到杯测记录</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="20023" />
        <source> added to roasting notes</source>
        <translation> 已添加到烘焙记录</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="20289" />
        <source>Mouse Cross ON: move mouse around</source>
        <translation>Mouse Cross ON：移动鼠标</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="20334" />
        <source>Mouse cross OFF</source>
        <translation>鼠标交叉关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="955" />
        <location filename="../artisanlib/colors.py" line="847" />
        <source>Color of {0} set to {1}</source>
        <translation>{0}的颜色设置为{1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="856" />
        <source>Config LCD colors</source>
        <translation>配置 LCD 颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="857" />
        <source>LCD digits color and background color cannot be the same.</source>
        <translation>LCD 数字颜色和背景颜色不能相同。</translation>
    </message>
    <message>
        <location filename="../artisanlib/cup_profile.py" line="254" />
        <source>Background profile not found</source>
        <translation>没有发现背景曲线配置</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1523" />
        <source>Register the currently loaded roast profile&lt;br&gt;in the selected entry.&lt;br&gt;This will overwrite some roast properties.</source>
        <translation>在选定的条目中注册当前加载的烘焙配置文件&lt;br&gt;。&lt;br&gt;这将覆盖一些烘焙属性。</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1537" />
        <location filename="../plus/schedule.py" line="1528" />
        <source>Register Roast</source>
        <translation>批次 + 正式录入归档</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2481" />
        <source>Scheduler started</source>
        <translation>调度程序已启动</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2792" />
        <source>Roasts will not adjust the schedule&lt;br&gt;while the schedule window is closed</source>
        <translation>当计划窗口关闭时，烘焙不会调整计划</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2806" />
        <location filename="../plus/schedule.py" line="2797" />
        <source>Close Scheduler</source>
        <translation>关闭调度程序</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2864" />
        <source>Scheduler stopped</source>
        <translation>调度程序已停止</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="3578" />
        <location filename="../plus/schedule.py" line="3170" />
        <source>Updating completed roast properties failed</source>
        <translation>更新已完成烘焙的属性失败</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="3750" />
        <location filename="../plus/schedule.py" line="3289" />
        <source>1 batch</source>
        <translation>1 单批次烘焙任务</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="3765" />
        <location filename="../plus/schedule.py" line="3756" />
        <location filename="../plus/schedule.py" line="3297" />
        <location filename="../plus/schedule.py" line="3291" />
        <source>{} batches</source>
        <translation>{} 多批次烘焙任务</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="3644" />
        <source>Fetching completed roast properties failed</source>
        <translation>获取已完成的烘焙属性失败</translation>
    </message>
    <message>
        <source>Recomended Mode = 0</source>
        <translation type="vanished">推荐模式 = 0</translation>
    </message>
    <message>
        <source>Empty path or box unchecked in Autosave</source>
        <translation type="vanished">自动保存时是空路径或未选中复选框</translation>
    </message>
    <message>
        <source>{0} has been saved. New roast has started</source>
        <translation type="vanished">{0}已被保存.新的烘焙已经开始</translation>
    </message>
    <message>
        <source>Import RoastPATH URL</source>
        <translation type="vanished">导入RoastPATH网址</translation>
    </message>
    <message>
        <source>Designer Start</source>
        <translation type="vanished">开始曲线设计</translation>
    </message>
    <message>
        <source>Importing a profile in to Designer will decimate all data except the main [points].
Continue?</source>
        <translation type="vanished">导入一个配置到曲线设计器将会删除除主要[点]外的所有数据. 继续?</translation>
    </message>
    <message>
        <source>CHARGE</source>
        <translation type="vanished">投豆</translation>
    </message>
    <message>
        <source>DRY END</source>
        <translation type="vanished">脱水结束</translation>
    </message>
    <message>
        <source>FC START</source>
        <translation type="vanished">第一次爆裂</translation>
    </message>
    <message>
        <source>FC END</source>
        <translation type="vanished">一爆结束</translation>
    </message>
    <message>
        <source>SC START</source>
        <translation type="vanished">第二次爆裂</translation>
    </message>
    <message>
        <source>SC END</source>
        <translation type="vanished">二爆结束</translation>
    </message>
    <message>
        <source>DROP</source>
        <translation type="vanished">排豆</translation>
    </message>
    <message>
        <source>[ CHARGE ]</source>
        <translation type="vanished">[ 投豆 ]</translation>
    </message>
    <message>
        <source>[ DRY END ]</source>
        <translation type="vanished">[ 脱水结束 ]</translation>
    </message>
    <message>
        <source>[ FC START ]</source>
        <translation type="vanished">[ 第一次爆裂 ]</translation>
    </message>
    <message>
        <source>[ FC END ]</source>
        <translation type="vanished">[ 一爆结束 ]</translation>
    </message>
    <message>
        <source>[ SC START ]</source>
        <translation type="vanished">[ 第二次爆裂 ]</translation>
    </message>
    <message>
        <source>[ SC END ]</source>
        <translation type="vanished">[ 二爆结束 ]</translation>
    </message>
    <message>
        <source>[ DROP ]</source>
        <translation type="vanished">[ 排豆 ]</translation>
    </message>
    <message>
        <source>[ COOL ]</source>
        <translation type="vanished">[ 凉爽的 ]</translation>
    </message>
    <message>
        <source>Bluetooth scale cannot be connected while permission for Artisan to access Bluetooth is denied</source>
        <translation type="vanished">无法连接蓝牙秤，Artisan 访问蓝牙的权限被拒绝</translation>
    </message>
    <message>
        <source>Bluetooth access denied</source>
        <translation type="vanished">蓝牙访问被拒绝</translation>
    </message>
</context><context>
    <name>Plus</name>
    <message>
        <location filename="../artisanlib/main.py" line="1208" />
        <source>debug logging ON</source>
        <translation>调试记录打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="1209" />
        <source>debug logging OFF</source>
        <translation>调试记录关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="1222" />
        <source>1 day left</source>
        <translation>仅剩1天</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="1224" />
        <source>{} days left</source>
        <translation>还剩{}天</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="1226" />
        <source>Paid until</source>
        <translation>付费至</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="1253" />
        <source>Please visit our {0}shop{1} to extend your subscription</source>
        <translation>请访问我们的{0}商店{1}以扩展您的订阅</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="1266" />
        <source>Do you want to extend your subscription?</source>
        <translation>你想延长你的订阅吗？</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="1267" />
        <source>Your subscription ends on</source>
        <translation>您的订阅结束于</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="1267" />
        <source>Your subscription ended on</source>
        <translation>您的订阅结束于</translation>
    </message>
    <message>
        <location filename="../plus/queue.py" line="141" />
        <source>Roast successfully uploaded to {}</source>
        <translation>烘焙已成功上传至{}</translation>
    </message>
    <message>
        <location filename="../plus/queue.py" line="453" />
        <source>Queuing roast for upload to {}</source>
        <translation>排队等待上传烘焙到{}</translation>
    </message>
    <message>
        <location filename="../plus/sync.py" line="729" />
        <source>Updated data received from artisan.plus</source>
        <translation>来自artisan.plus的更新数据已接收</translation>
    </message>
    <message>
        <location filename="../plus/controller.py" line="220" />
        <source>Keyring error: Ensure that gnome-keyring is installed.</source>
        <translation>密钥环错误: 确认gnome-keyring已安装.</translation>
    </message>
    <message>
        <location filename="../plus/controller.py" line="234" />
        <source>Login aborted</source>
        <translation>登入已终止</translation>
    </message>
    <message>
        <location filename="../plus/controller.py" line="243" />
        <source>authentified</source>
        <translation>已认证</translation>
    </message>
    <message>
        <location filename="../plus/controller.py" line="248" />
        <source>Connected to artisan.plus</source>
        <translation>已连接到artisan.plus</translation>
    </message>
    <message>
        <location filename="../plus/controller.py" line="364" />
        <location filename="../plus/controller.py" line="289" />
        <location filename="../plus/controller.py" line="266" />
        <source>artisan.plus turned off</source>
        <translation>artisan.plus关闭</translation>
    </message>
    <message>
        <location filename="../plus/controller.py" line="273" />
        <source>Authentication failed</source>
        <translation>认证失败</translation>
    </message>
    <message>
        <location filename="../plus/controller.py" line="298" />
        <source>Couldn't connect to artisan.plus</source>
        <translation>无法连接到 artisan.plus</translation>
    </message>
    <message>
        <location filename="../plus/controller.py" line="323" />
        <source>Disconnect artisan.plus?</source>
        <translation>断开artisan.plus连接？</translation>
    </message>
    <message>
        <location filename="../plus/controller.py" line="373" />
        <source>artisan.plus connection lost. Reconnecting automatically...</source>
        <translation>artisan.plus 连接已断开。正在自动重新连接……</translation>
    </message>
    <message>
        <location filename="../plus/controller.py" line="377" />
        <source>artisan.plus disconnected</source>
        <translation>已断开artisan.plus连接</translation>
    </message>
    <message>
        <location filename="../plus/controller.py" line="410" />
        <source>artisan.plus reconnected</source>
        <translation>artisan.plus 重新连接</translation>
    </message>
    <message>
        <location filename="../plus/stock.py" line="470" />
        <source>bag</source>
        <translation>袋</translation>
    </message>
    <message>
        <location filename="../plus/stock.py" line="471" />
        <source>box</source>
        <translation>盒</translation>
    </message>
    <message>
        <location filename="../plus/stock.py" line="472" />
        <source>barrel</source>
        <translation>桶</translation>
    </message>
    <message>
        <location filename="../plus/stock.py" line="475" />
        <source>bags</source>
        <translation>袋</translation>
    </message>
    <message>
        <location filename="../plus/stock.py" line="476" />
        <source>boxes</source>
        <translation>盒</translation>
    </message>
    <message>
        <location filename="../plus/stock.py" line="477" />
        <source>barrels</source>
        <translation>桶</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1339" />
        <source>Yesterday</source>
        <translation>昨天</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1959" />
        <location filename="../plus/schedule.py" line="1414" />
        <source>Today</source>
        <translation>今天</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1416" />
        <source>Tomorrow</source>
        <translation>明天</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1428" />
        <source>by anybody</source>
        <translation>任何人</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1430" />
        <location filename="../plus/schedule.py" line="1429" />
        <source>by</source>
        <translation>经过</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1432" />
        <source>on</source>
        <translation>在</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1438" />
        <source>prepared</source>
        <translation>项已准备好</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1439" />
        <source>({} of {} done{})</source>
        <translation>({} 项中 {} 项已完成)</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1955" />
        <source>Visible</source>
        <translation>可见的</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1957" />
        <source>List only visible items</source>
        <translation>仅列出可见项目</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1962" />
        <source>List only items scheduled for today</source>
        <translation>仅列出今天安排的项目</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="1975" />
        <source>Filters</source>
        <translation>筛选器</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2251" />
        <source>No completed roasts</source>
        <translation>没有完成的烘焙</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2294" />
        <source>Schedule Updated!</source>
        <translation>烘焙时间表已更新！</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2389" />
        <source>Login to {} to receive your roast schedule</source>
        <translation>登录{}以接收您的烘焙时间表</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="3349" />
        <source>List only items scheduled for the current user {}</source>
        <translation>仅列出为当前用户安排的项目{}</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="3357" />
        <source>List only items scheduled for the current machine {}</source>
        <translation>仅列出当前机器计划的项目 {}</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="3989" />
        <source>Schedule empty!{}Plan your schedule on {}</source>
        <translation>日程表为空！{}计划您的日程表 {}</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="3997" />
        <source>Nothing scheduled for you today!{}Deactivate filters to see all items.</source>
        <translation>今天您没有安排！{}停用过滤器以查看所有项目。</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="4049" />
        <source>nothing to weight</source>
        <translation>无需称重</translation>
    </message>
    <message>
        <location filename="../plus/login.py" line="59" />
        <source>Register</source>
        <translation>注册</translation>
    </message>
    <message>
        <location filename="../plus/login.py" line="63" />
        <source>Reset Password</source>
        <translation>重设密码</translation>
    </message>
    <message>
        <location filename="../plus/login.py" line="107" />
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="../plus/login.py" line="112" />
        <source>Email</source>
        <translation>电邮</translation>
    </message>
    <message>
        <location filename="../plus/login.py" line="130" />
        <source>Remember</source>
        <translation>记住</translation>
    </message>
    <message>
        <location filename="../plus/login.py" line="137" />
        <source>Server URL</source>
        <translation type="unfinished" />
    </message>
</context><context>
    <name>Radio Button</name>
    <message>
        <location filename="../artisanlib/devices.py" line="122" />
        <source>Meter</source>
        <translation>仪表</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="123" />
        <source>PID</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="124" />
        <source>TC4</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="125" />
        <source>Prog</source>
        <translation />
    </message>
</context><context>
    <name>Scope Annotation</name>
    <message>
        <location filename="../artisanlib/canvas.py" line="15425" />
        <location filename="../artisanlib/canvas.py" line="8961" />
        <location filename="../artisanlib/canvas.py" line="8949" />
        <source>TP {0}</source>
        <translation>回温点 {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15502" />
        <location filename="../artisanlib/canvas.py" line="15469" />
        <location filename="../artisanlib/canvas.py" line="8975" />
        <source>DE {0}</source>
        <translation>脱水结束 {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15617" />
        <location filename="../artisanlib/canvas.py" line="15584" />
        <location filename="../artisanlib/canvas.py" line="8990" />
        <source>FCs {0}</source>
        <translation>第一次爆裂 {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15725" />
        <location filename="../artisanlib/canvas.py" line="15695" />
        <location filename="../artisanlib/canvas.py" line="9004" />
        <source>FCe {0}</source>
        <translation>一爆结束 {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15835" />
        <location filename="../artisanlib/canvas.py" line="15806" />
        <location filename="../artisanlib/canvas.py" line="9026" />
        <source>SCs {0}</source>
        <translation>第二次爆裂 {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15951" />
        <location filename="../artisanlib/canvas.py" line="15922" />
        <location filename="../artisanlib/canvas.py" line="9040" />
        <source>SCe {0}</source>
        <translation>二爆结束 {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="16084" />
        <location filename="../artisanlib/canvas.py" line="16042" />
        <location filename="../artisanlib/canvas.py" line="13019" />
        <location filename="../artisanlib/canvas.py" line="9074" />
        <source>DROP {0}</source>
        <translation>排豆 {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="16265" />
        <location filename="../artisanlib/canvas.py" line="16234" />
        <source>CE {0}</source>
        <translation>冷却结束 {0}</translation>
    </message>
    <message>
        <source>CHARGE</source>
        <translation type="vanished">投豆</translation>
    </message>
</context><context>
    <name>Scope Title</name>
    <message>
        <location filename="../plus/schedule.py" line="2972" />
        <location filename="../artisanlib/canvas.py" line="9425" />
        <location filename="../artisanlib/canvas.py" line="8328" />
        <location filename="../artisanlib/canvas.py" line="1453" />
        <location filename="../artisanlib/main.py" line="15889" />
        <location filename="../artisanlib/main.py" line="12905" />
        <location filename="../artisanlib/roast_properties.py" line="2543" />
        <location filename="../artisanlib/roast_properties.py" line="2513" />
        <location filename="../artisanlib/roast_properties.py" line="2168" />
        <location filename="../artisanlib/roast_properties.py" line="2155" />
        <source>Roaster Scope</source>
        <translation>烘焙记录仪</translation>
    </message>
</context><context>
    <name>StatusBar</name>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1763" />
        <source>Decimal position successfully set to 1</source>
        <translation>小数位置成功设置为1</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1766" />
        <source>Problem setting decimal position</source>
        <translation>设置小数点时出现问题</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1820" />
        <source>Thermocouple type successfully set</source>
        <translation>热电偶类型设置成功</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="1823" />
        <source>Problem setting thermocouple type</source>
        <translation>设置热电偶类型时出现问题</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2742" />
        <location filename="../artisanlib/pid_dialogs.py" line="1920" />
        <source>Ready</source>
        <translation>准备</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4569" />
        <location filename="../artisanlib/pid_dialogs.py" line="2280" />
        <source>setting autotune...</source>
        <translation>设置自动调节...</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4598" />
        <location filename="../artisanlib/pid_dialogs.py" line="2292" />
        <source>Autotune successfully turned OFF</source>
        <translation>自动调节已成功关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4601" />
        <location filename="../artisanlib/pid_dialogs.py" line="2295" />
        <source>Autotune successfully turned ON</source>
        <translation>自动调节已成功打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4526" />
        <location filename="../artisanlib/pid_dialogs.py" line="2313" />
        <source>wait...</source>
        <translation>等待...</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2317" />
        <source>PID OFF</source>
        <translation>PID关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="1477" />
        <location filename="../artisanlib/pid_dialogs.py" line="2319" />
        <source>PID ON</source>
        <translation>PID打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2347" />
        <location filename="../artisanlib/pid_dialogs.py" line="2337" />
        <source>SV successfully set to {0}</source>
        <translation>SV成功设置为 {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2358" />
        <source>Empty SV box</source>
        <translation>空SV标记</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2368" />
        <source>Unable to read SV</source>
        <translation>无法读取SV</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4440" />
        <location filename="../artisanlib/pid_dialogs.py" line="2511" />
        <source>Ramp/Soak operation cancelled</source>
        <translation>缓升/恒温 操作已取消</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4443" />
        <location filename="../artisanlib/pid_dialogs.py" line="2514" />
        <source>No RX data</source>
        <translation>无RX数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4461" />
        <location filename="../artisanlib/pid_dialogs.py" line="4444" />
        <location filename="../artisanlib/pid_dialogs.py" line="2537" />
        <location filename="../artisanlib/pid_dialogs.py" line="2515" />
        <source>RS ON</source>
        <translation>RS打开</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4449" />
        <location filename="../artisanlib/pid_dialogs.py" line="2525" />
        <source>Need to change pattern mode...</source>
        <translation>需要改变模式...</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4452" />
        <location filename="../artisanlib/pid_dialogs.py" line="2528" />
        <source>Pattern has been changed. Wait 5 secs.</source>
        <translation>模式已改变.等5秒钟.</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4454" />
        <location filename="../artisanlib/pid_dialogs.py" line="2530" />
        <source>Pattern could not be changed</source>
        <translation>模式没有被改变</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4483" />
        <location filename="../artisanlib/pid_dialogs.py" line="2554" />
        <source>RampSoak could not be changed</source>
        <translation>缓升恒温 无法改变</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4486" />
        <location filename="../artisanlib/pid_dialogs.py" line="2561" />
        <source>RS OFF</source>
        <translation>RS关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4545" />
        <location filename="../artisanlib/pid_dialogs.py" line="2568" />
        <source>Reading Ramp/Soak {0} ...</source>
        <translation>读取缓升/恒温 {0} ...</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4550" />
        <location filename="../artisanlib/pid_dialogs.py" line="2573" />
        <source>problem reading Ramp/Soak</source>
        <translation>读取缓升/恒温 出现问题</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4553" />
        <location filename="../artisanlib/pid_dialogs.py" line="2576" />
        <source>Finished reading Ramp/Soak val.</source>
        <translation>已完成读取 缓升/恒温.</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2625" />
        <source>Finished reading pid values</source>
        <translation>读取PID值已完成</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4745" />
        <location filename="../artisanlib/pid_dialogs.py" line="2724" />
        <source>Ramp/Soak successfully written</source>
        <translation>缓升/恒温 成功写入</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3531" />
        <source>Time Units successfully set to MM:SS</source>
        <translation>时间模式成功设置为MM:SS</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3534" />
        <source>Problem setting time units</source>
        <translation>设置时间模式时出现问题</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3699" />
        <source>SV{0} set to {1}</source>
        <translation>SV{0}设置为{1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3703" />
        <source>Problem setting SV</source>
        <translation>设置 SV 时出现问题</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3705" />
        <source>Cancelled svN change</source>
        <translation>已取消svN更改</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3723" />
        <source>PID already using sv{0}</source>
        <translation>PID正在使用sv{0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3726" />
        <source>setNsv(): bad response</source>
        <translation>setNsv():错误响应</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3780" />
        <source>pid changed to {0}</source>
        <translation>pid更改为{0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3783" />
        <source>setNpid(): bad confirmation</source>
        <translation>setNpid(): 错误确认</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3787" />
        <source>Cancelled pid change</source>
        <translation>已取消PID更改</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3812" />
        <source>PID was already using pid {0}</source>
        <translation>PID 正在使用 pid {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3815" />
        <source>setNpid(): Unable to set pid {0} </source>
        <translation>setNpid(): 无法设置pid {0} </translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3936" />
        <location filename="../artisanlib/pid_dialogs.py" line="3929" />
        <location filename="../artisanlib/pid_dialogs.py" line="3922" />
        <location filename="../artisanlib/pid_dialogs.py" line="3915" />
        <location filename="../artisanlib/pid_dialogs.py" line="3908" />
        <location filename="../artisanlib/pid_dialogs.py" line="3901" />
        <location filename="../artisanlib/pid_dialogs.py" line="3894" />
        <source>SV{0} successfully set to {1}</source>
        <translation>SV{0} 成功设置为{1}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3947" />
        <source>setsv(): Unable to set SV</source>
        <translation>setsv(): 无法设置SV</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="359" />
        <location filename="../artisanlib/pid_control.py" line="314" />
        <location filename="../artisanlib/pid_dialogs.py" line="4082" />
        <location filename="../artisanlib/pid_dialogs.py" line="4074" />
        <location filename="../artisanlib/pid_dialogs.py" line="4066" />
        <location filename="../artisanlib/pid_dialogs.py" line="4058" />
        <location filename="../artisanlib/pid_dialogs.py" line="4050" />
        <location filename="../artisanlib/pid_dialogs.py" line="4042" />
        <location filename="../artisanlib/pid_dialogs.py" line="4034" />
        <source>pid #{0} successfully set to ({1},{2},{3})</source>
        <translation>pid #{0} 成功设置为 ({1},{2},{3})</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="366" />
        <location filename="../artisanlib/pid_control.py" line="321" />
        <location filename="../artisanlib/pid_dialogs.py" line="4090" />
        <source>pid command failed. Bad data at pid{0} (8,8,8): ({1},{2},{3}) </source>
        <translation>pid 指令失败. 错误数据位于 pid{0} (8,8,8): ({1},{2},{3}) </translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4105" />
        <source>sending commands for p{0} i{1} d{2}</source>
        <translation>发送指令到p{0} i{1} d{2}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4193" />
        <source>getallpid(): Unable to read pid values</source>
        <translation>getallpid(): 无法读取PID值</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4221" />
        <source>PID is using pid = {0}</source>
        <translation>PID正在使用pid = {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4224" />
        <source>getallpid(): Unable to read current sv</source>
        <translation>getallpid(): 无法读取目前的SV</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4302" />
        <source>PID is using SV = {0}</source>
        <translation>PID 正在使用 SV = {0}</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4530" />
        <source>PID set to OFF</source>
        <translation>PID 设置为OFF</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4532" />
        <source>PID set to ON</source>
        <translation>PID设置为ON</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4535" />
        <source>Unable</source>
        <translation>不行</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4536" />
        <source>No data received</source>
        <translation>没有接收到数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4580" />
        <source>Current pid = {0}. Proceed with autotune command?</source>
        <translation>目前pid = {0}. 继续自动调节指令?</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4584" />
        <source>Autotune cancelled</source>
        <translation>自动调节已取消</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4603" />
        <source>UNABLE to set Autotune</source>
        <translation>无法设置自动调节</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4666" />
        <source>SV</source>
        <translation>SV</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4667" />
        <source>Ramp (MM:SS)</source>
        <translation>缓升 (MM:SS)</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4668" />
        <source>Soak (MM:SS)</source>
        <translation>恒温 (MM:SS)</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4762" />
        <source>Work in Progress</source>
        <translation>工作正在进行中</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4798" />
        <source>SV =</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="613" />
        <source>Playback Events set OFF</source>
        <translation>回放事件设置为关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="677" />
        <source>Playback DROP set OFF</source>
        <translation>回放排豆 设置为关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="698" />
        <source>Playback Aid set OFF</source>
        <translation>回放辅助设备设置为关闭</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="455" />
        <source>{0} successfully sent to pid</source>
        <translation>{0} 成功发送到pid</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_control.py" line="464" />
        <source>setpid(): There was a problem setting {0}</source>
        <translation>setpid(): 设置时出现问题 {0}</translation>
    </message>
    <message>
        <source>{0} successfully sent to pid </source>
        <translation type="vanished">{0} 成功发送到pid </translation>
    </message>
</context><context>
    <name>Tab</name>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3335" />
        <location filename="../artisanlib/pid_dialogs.py" line="2182" />
        <location filename="../artisanlib/pid_dialogs.py" line="948" />
        <source>PID</source>
        <translation>PID</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="951" />
        <source>Ramp/Soak</source>
        <translation>缓升/恒温</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3329" />
        <location filename="../artisanlib/pid_dialogs.py" line="2168" />
        <location filename="../artisanlib/pid_dialogs.py" line="1061" />
        <source>RS</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3332" />
        <location filename="../artisanlib/pid_dialogs.py" line="2171" />
        <source>SV</source>
        <translation>SV</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="3338" />
        <location filename="../artisanlib/pid_dialogs.py" line="2185" />
        <source>Set RS</source>
        <translation>设置RS</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1508" />
        <location filename="../artisanlib/pid_dialogs.py" line="3341" />
        <location filename="../artisanlib/pid_dialogs.py" line="2188" />
        <source>Extra</source>
        <translation>额外</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="4779" />
        <source>General</source>
        <translation>常规</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="508" />
        <location filename="../artisanlib/events.py" line="1739" />
        <source>Config</source>
        <translation>配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1746" />
        <source>Buttons</source>
        <translation>控制按钮</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1752" />
        <source>Sliders</source>
        <translation>控制滑块</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1758" />
        <source>Quantifiers</source>
        <translation>范围</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1765" />
        <source>Palettes</source>
        <translation>调色板</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1772" />
        <source>Style</source>
        <translation>风格</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1776" />
        <source>Annotations</source>
        <translation>备注</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1959" />
        <location filename="../artisanlib/ports.py" line="1505" />
        <source>ET/BT</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1511" />
        <source>Modbus</source>
        <translation>通信协议</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1514" />
        <source>S7</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1517" />
        <source>WebSocket</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1660" />
        <location filename="../artisanlib/background.py" line="512" />
        <source>Events</source>
        <translation>事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1664" />
        <location filename="../artisanlib/background.py" line="516" />
        <source>Data</source>
        <translation>数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1653" />
        <source>Roast</source>
        <translation>烘焙</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1656" />
        <source>Notes</source>
        <translation>笔记</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1667" />
        <source>Energy</source>
        <translation>能源</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1670" />
        <source>Setup</source>
        <translation>设定</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2898" />
        <source>Details</source>
        <translation>详细</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2899" />
        <source>Loads</source>
        <translation>载入</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2900" />
        <source>Protocol</source>
        <translation>规范</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="554" />
        <location filename="../artisanlib/curves.py" line="1252" />
        <source>Graph</source>
        <translation>图形</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1413" />
        <source>RoR</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1419" />
        <source>Filters</source>
        <translation>筛选器</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1425" />
        <source>Plotter</source>
        <translation>绘图仪</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1431" />
        <source>Math</source>
        <translation>计算</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1437" />
        <source>Analyze</source>
        <translation>分析</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1443" />
        <source>UI</source>
        <translation>界面</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="563" />
        <source>Statistics</source>
        <translation>统计</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="230" />
        <source>Alarm Table</source>
        <translation>警报表</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="239" />
        <source>Alarm Sets</source>
        <translation>警报设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="4581" />
        <location filename="../artisanlib/main.py" line="4574" />
        <source>Scale</source>
        <translation>电子秤</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1962" />
        <source>Extra Devices</source>
        <translation>额外设备</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1965" />
        <source>Symb ET/BT</source>
        <translation>标记 ET/BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1974" />
        <source>Ambient</source>
        <translation>环境</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1977" />
        <source>Networks</source>
        <translation>网络</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1983" />
        <source>Batch Manager</source>
        <translation>批次管理器</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="551" />
        <source>Curves</source>
        <translation>曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="557" />
        <source>LCDs</source>
        <translation>LCDs</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2328" />
        <source>To-Do</source>
        <translation>去做</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2329" />
        <source>Completed</source>
        <translation>完全的</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">颜色</translation>
    </message>
</context><context>
    <name>Table</name>
    <message>
        <location filename="../artisanlib/cup_profile.py" line="220" />
        <location filename="../artisanlib/events.py" line="2727" />
        <location filename="../artisanlib/wheels.py" line="201" />
        <source>Label</source>
        <translation>标签</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="202" />
        <source>Parent</source>
        <translation>上层</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="203" />
        <source>Width</source>
        <translation>宽度</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="2734" />
        <location filename="../artisanlib/wheels.py" line="422" />
        <location filename="../artisanlib/wheels.py" line="204" />
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="205" />
        <source>Opaqueness</source>
        <translation>不透明度</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="414" />
        <source>Delete Wheel</source>
        <translation>删除轮</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="415" />
        <source>Edit Labels</source>
        <translation>编辑标签</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="416" />
        <source>Update Labels</source>
        <translation>更新标签</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="417" />
        <source>Properties</source>
        <translation>属性</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="418" />
        <source>Radius</source>
        <translation>半径</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="419" />
        <source>Starting angle</source>
        <translation>起始角度</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="420" />
        <source>Projection</source>
        <translation>预测</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="263" />
        <location filename="../artisanlib/wheels.py" line="421" />
        <source>Text Size</source>
        <translation>字体大小</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="423" />
        <source>Color Pattern</source>
        <translation>色彩图案</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2648" />
        <location filename="../artisanlib/pid_dialogs.py" line="972" />
        <location filename="../artisanlib/pid_dialogs.py" line="818" />
        <source>SV</source>
        <translation>SV</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="973" />
        <location filename="../artisanlib/pid_dialogs.py" line="819" />
        <source>Ramp</source>
        <translation>缓升</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="974" />
        <location filename="../artisanlib/pid_dialogs.py" line="820" />
        <source>Soak</source>
        <translation>恒温</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="1001" />
        <location filename="../artisanlib/events.py" line="2731" />
        <location filename="../artisanlib/pid_dialogs.py" line="975" />
        <location filename="../artisanlib/pid_dialogs.py" line="821" />
        <source>Action</source>
        <translation>动作</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="1002" />
        <location filename="../artisanlib/pid_dialogs.py" line="976" />
        <location filename="../artisanlib/pid_dialogs.py" line="822" />
        <source>Beep</source>
        <translation>提示音</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="1003" />
        <location filename="../artisanlib/roast_properties.py" line="4529" />
        <location filename="../artisanlib/background.py" line="905" />
        <location filename="../artisanlib/events.py" line="3925" />
        <location filename="../artisanlib/events.py" line="2728" />
        <location filename="../artisanlib/pid_dialogs.py" line="977" />
        <location filename="../artisanlib/pid_dialogs.py" line="823" />
        <source>Description</source>
        <translation>说明</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2649" />
        <source>Ramp HH:MM</source>
        <translation>缓升 HH:MM</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="2650" />
        <source>Soak HH:MM</source>
        <translation>恒温 HH:MM</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="4530" />
        <location filename="../artisanlib/background.py" line="906" />
        <location filename="../artisanlib/events.py" line="3927" />
        <location filename="../artisanlib/events.py" line="2729" />
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <location filename="../artisanlib/cup_profile.py" line="221" />
        <location filename="../artisanlib/alarms.py" line="1000" />
        <location filename="../artisanlib/roast_properties.py" line="4531" />
        <location filename="../artisanlib/background.py" line="907" />
        <location filename="../artisanlib/events.py" line="3933" />
        <location filename="../artisanlib/events.py" line="2730" />
        <source>Value</source>
        <translation>数值</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="2732" />
        <source>Documentation</source>
        <translation>文档</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="2733" />
        <source>Visibility</source>
        <translation>可见性</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="2735" />
        <source>Text Color</source>
        <translation>文字颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2704" />
        <location filename="../artisanlib/ports.py" line="1593" />
        <source>Device</source>
        <translation>设备</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1594" />
        <source>Comm Port</source>
        <translation>通信端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1595" />
        <source>Baud Rate</source>
        <translation>传输速率</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1596" />
        <source>Byte Size</source>
        <translation>字节大小</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1597" />
        <source>Parity</source>
        <translation>校验</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1598" />
        <source>Stopbits</source>
        <translation>停止位</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1599" />
        <source>Timeout</source>
        <translation>超时</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="189" />
        <location filename="../artisanlib/alarms.py" line="997" />
        <location filename="../artisanlib/curves.py" line="128" />
        <location filename="../artisanlib/roast_properties.py" line="4526" />
        <location filename="../artisanlib/roast_properties.py" line="4369" />
        <location filename="../artisanlib/background.py" line="990" />
        <location filename="../artisanlib/background.py" line="902" />
        <source>Time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="4431" />
        <location filename="../artisanlib/background.py" line="1085" />
        <source>#{0} {1}{2}</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2909" />
        <source>Power</source>
        <translation>火力</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2912" />
        <source>Duration</source>
        <translation>时长</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2918" />
        <source>CO2</source>
        <translation>二氧化碳</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2921" />
        <source>Load</source>
        <translation>载入</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="998" />
        <location filename="../artisanlib/roast_properties.py" line="2924" />
        <source>Source</source>
        <translation>来源</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2927" />
        <source>Kind</source>
        <translation>类型</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="127" />
        <source>t</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="129" />
        <source>P1</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="130" />
        <source>P2</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="131" />
        <source>P3</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="132" />
        <source>P4</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="133" />
        <source>P5</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="134" />
        <source>P6</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="135" />
        <source>P7</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="136" />
        <source>P8</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="137" />
        <source>P9</source>
        <translation />
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="187" />
        <location filename="../artisanlib/statistics.py" line="226" />
        <location filename="../artisanlib/statistics.py" line="225" />
        <location filename="../artisanlib/statistics.py" line="224" />
        <source>Phases</source>
        <translation>阶段</translation>
    </message>
    <message>
        <location filename="../artisanlib/dialogs.py" line="742" />
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="../artisanlib/dialogs.py" line="743" />
        <source>Weight</source>
        <translation>重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="992" />
        <source>Nr</source>
        <translation>编号</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="993" />
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="994" />
        <source>If Alarm</source>
        <translation>If Alarm（依赖触发）</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="995" />
        <source>But Not</source>
        <translation>But Not（排除触发）</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="996" />
        <source>From</source>
        <translation>来自</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="999" />
        <source>Condition</source>
        <translation>条件</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2705" />
        <source>Color 1</source>
        <translation>颜色1</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2706" />
        <source>Color 2</source>
        <translation>颜色2</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2707" />
        <source>Label 1</source>
        <translation>标签1</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2708" />
        <source>Label 2</source>
        <translation>标签2</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2709" />
        <source>y1(x)</source>
        <translation>y1(x)</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2710" />
        <source>y2(x)</source>
        <translation>y2(x)</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2711" />
        <source>LCD 1</source>
        <translation>LCD 1</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2712" />
        <source>LCD 2</source>
        <translation>LCD 2</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2713" />
        <source>Curve 1</source>
        <translation>曲线1</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2714" />
        <source>Curve 2</source>
        <translation>曲线2</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2717" />
        <source>Fill 1</source>
        <translation>填充1</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2718" />
        <source>Fill 2</source>
        <translation>填充2</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="191" />
        <source>BT</source>
        <translation>BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="1202" />
        <location filename="../artisanlib/transposer.py" line="1131" />
        <location filename="../artisanlib/transposer.py" line="1030" />
        <source>Profile</source>
        <translation>配置</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="1203" />
        <location filename="../artisanlib/transposer.py" line="1132" />
        <location filename="../artisanlib/transposer.py" line="1031" />
        <source>Target</source>
        <translation>目标</translation>
    </message>
    <message>
        <location filename="../artisanlib/transposer.py" line="1204" />
        <location filename="../artisanlib/transposer.py" line="1133" />
        <location filename="../artisanlib/transposer.py" line="1032" />
        <source>Result</source>
        <translation>结果</translation>
    </message>
    <message>
        <source>CHARGE</source>
        <translation type="vanished">投豆</translation>
    </message>
    <message>
        <source>DRY END</source>
        <translation type="vanished">脱水结束</translation>
    </message>
    <message>
        <source>FC START</source>
        <translation type="vanished">第一次爆裂</translation>
    </message>
    <message>
        <source>FC END</source>
        <translation type="vanished">一爆结束</translation>
    </message>
    <message>
        <source>SC START</source>
        <translation type="vanished">第二次爆裂</translation>
    </message>
    <message>
        <source>SC END</source>
        <translation type="vanished">二爆结束</translation>
    </message>
    <message>
        <source>DROP</source>
        <translation type="vanished">排豆</translation>
    </message>
    <message>
        <source>COOL</source>
        <translation type="vanished">冷却</translation>
    </message>
</context><context>
    <name>Textbox</name>
    <message>
        <location filename="../artisanlib/canvas.py" line="606" />
        <location filename="../artisanlib/canvas.py" line="596" />
        <location filename="../artisanlib/canvas.py" line="587" />
        <location filename="../artisanlib/canvas.py" line="580" />
        <location filename="../artisanlib/canvas.py" line="572" />
        <location filename="../artisanlib/canvas.py" line="569" />
        <location filename="../artisanlib/canvas.py" line="548" />
        <location filename="../artisanlib/canvas.py" line="536" />
        <location filename="../artisanlib/canvas.py" line="525" />
        <location filename="../artisanlib/canvas.py" line="509" />
        <source>Acidity</source>
        <translation>酸质</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="605" />
        <location filename="../artisanlib/canvas.py" line="583" />
        <location filename="../artisanlib/canvas.py" line="575" />
        <location filename="../artisanlib/canvas.py" line="567" />
        <location filename="../artisanlib/canvas.py" line="550" />
        <location filename="../artisanlib/canvas.py" line="535" />
        <location filename="../artisanlib/canvas.py" line="524" />
        <location filename="../artisanlib/canvas.py" line="510" />
        <source>Aftertaste</source>
        <translation>余韵</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="555" />
        <location filename="../artisanlib/canvas.py" line="541" />
        <location filename="../artisanlib/canvas.py" line="529" />
        <location filename="../artisanlib/canvas.py" line="511" />
        <source>Clean Cup</source>
        <translation>干净杯</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="512" />
        <source>Head</source>
        <translation>前段</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="594" />
        <location filename="../artisanlib/canvas.py" line="563" />
        <location filename="../artisanlib/canvas.py" line="513" />
        <source>Fragrance</source>
        <translation>干香</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="609" />
        <location filename="../artisanlib/canvas.py" line="608" />
        <location filename="../artisanlib/canvas.py" line="586" />
        <location filename="../artisanlib/canvas.py" line="556" />
        <location filename="../artisanlib/canvas.py" line="542" />
        <location filename="../artisanlib/canvas.py" line="530" />
        <location filename="../artisanlib/canvas.py" line="514" />
        <source>Sweetness</source>
        <translation>甜感</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="603" />
        <location filename="../artisanlib/canvas.py" line="579" />
        <location filename="../artisanlib/canvas.py" line="564" />
        <location filename="../artisanlib/canvas.py" line="546" />
        <location filename="../artisanlib/canvas.py" line="515" />
        <source>Aroma</source>
        <translation>湿香</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="611" />
        <location filename="../artisanlib/canvas.py" line="610" />
        <location filename="../artisanlib/canvas.py" line="601" />
        <location filename="../artisanlib/canvas.py" line="584" />
        <location filename="../artisanlib/canvas.py" line="576" />
        <location filename="../artisanlib/canvas.py" line="540" />
        <location filename="../artisanlib/canvas.py" line="528" />
        <location filename="../artisanlib/canvas.py" line="516" />
        <source>Balance</source>
        <translation>平衡</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="607" />
        <location filename="../artisanlib/canvas.py" line="595" />
        <location filename="../artisanlib/canvas.py" line="588" />
        <location filename="../artisanlib/canvas.py" line="574" />
        <location filename="../artisanlib/canvas.py" line="568" />
        <location filename="../artisanlib/canvas.py" line="558" />
        <location filename="../artisanlib/canvas.py" line="549" />
        <location filename="../artisanlib/canvas.py" line="538" />
        <location filename="../artisanlib/canvas.py" line="526" />
        <location filename="../artisanlib/canvas.py" line="517" />
        <source>Body</source>
        <translation>醇厚度</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="571" />
        <location filename="../artisanlib/canvas.py" line="533" />
        <location filename="../artisanlib/canvas.py" line="522" />
        <source>Fragrance-Aroma</source>
        <translation>干香-湿香</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="573" />
        <location filename="../artisanlib/canvas.py" line="559" />
        <location filename="../artisanlib/canvas.py" line="547" />
        <location filename="../artisanlib/canvas.py" line="534" />
        <location filename="../artisanlib/canvas.py" line="523" />
        <source>Flavor</source>
        <translation>风味</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="553" />
        <location filename="../artisanlib/canvas.py" line="539" />
        <location filename="../artisanlib/canvas.py" line="527" />
        <source>Uniformity</source>
        <translation>一致性</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="612" />
        <location filename="../artisanlib/canvas.py" line="543" />
        <location filename="../artisanlib/canvas.py" line="531" />
        <source>Overall</source>
        <translation>总评</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="537" />
        <source>Intensity</source>
        <translation>强度</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="545" />
        <source>Fragance</source>
        <translation>干香</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="552" />
        <source>Dry Fragrance</source>
        <translation>干香</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="554" />
        <source>Complexity</source>
        <translation>复杂性</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="589" />
        <location filename="../artisanlib/canvas.py" line="557" />
        <source>Finish</source>
        <translation>结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="560" />
        <source>Brightness</source>
        <translation>明亮感</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="561" />
        <source>Wet Aroma</source>
        <translation>湿香</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="565" />
        <source>Taste</source>
        <translation>味道</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="566" />
        <source>Nose</source>
        <translation>嗅觉</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="581" />
        <source>Mouthfeel</source>
        <translation>口感</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="604" />
        <location filename="../artisanlib/canvas.py" line="582" />
        <source>Flavour</source>
        <translation>风味</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="591" />
        <source>Roast Color</source>
        <translation>烘焙色值</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="592" />
        <source>Crema Texture</source>
        <translation>油脂质地</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="593" />
        <source>Crema Volume</source>
        <translation>油脂量</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="597" />
        <source>Bitterness</source>
        <translation>苦度</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="598" />
        <source>Defects</source>
        <translation>瑕疵</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="599" />
        <source>Aroma Intensity</source>
        <translation>湿香强度</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="600" />
        <source>Aroma Persistence</source>
        <translation>芳香恃久度</translation>
    </message>
</context><context>
    <name>Toolbar</name>
    <message>
        <location filename="../artisanlib/main.py" line="742" />
        <source>Home</source>
        <translation>家</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="743" />
        <source>Back</source>
        <translation>后退</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="744" />
        <source>Forward</source>
        <translation>向前</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="746" />
        <source>Pan</source>
        <translation>移动</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="747" />
        <source>Zoom</source>
        <translation>缩放</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="936" />
        <location filename="../artisanlib/main.py" line="832" />
        <source>Lines</source>
        <translation>线</translation>
    </message>
</context><context>
    <name>Tooltip</name>
    <message>
        <location filename="../artisanlib/axis.py" line="86" />
        <source>100% event values in step mode are aligned with the given y-axis value or the lowest phases limit if left empty</source>
        <translation>步骤模式下的100%事件值与给定的y轴值或最低相位限制（如果留空）对齐</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="158" />
        <source>Time axis max on start of a recording</source>
        <translation>记录开始时的时间轴最大值</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="167" />
        <source>Time axis min on start of a recording</source>
        <translation>记录开始时的时间轴最小值</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="172" />
        <source>Automatically extend the timeline as needed</source>
        <translation>根据需要自动延长时间线</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="177" />
        <source>Do not set time axis min and max from profile on load</source>
        <translation>在载入配置时不设置时间轴最小值和最大值</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="182" />
        <source>Automatically set time axis min and max from profile CHARGE/DROP events</source>
        <translation>根据配置文件的投豆/排豆事件自动设置时间轴的最小值和最大值</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="194" />
        <source>Coverage of auto time axis mode</source>
        <translation>自动时间轴模式覆盖</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="269" />
        <location filename="../artisanlib/axis.py" line="267" />
        <location filename="../artisanlib/axis.py" line="259" />
        <location filename="../artisanlib/axis.py" line="257" />
        <location filename="../artisanlib/axis.py" line="210" />
        <location filename="../artisanlib/axis.py" line="208" />
        <source>Distance of major tick labels</source>
        <translation>主要刻度标签的距离</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="239" />
        <source>Show time grid</source>
        <translation>显示时间坐标方格</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="243" />
        <source>Show temperature grid</source>
        <translation>显示温度坐标方格</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="248" />
        <source>Split graph: temperatures/RoR/events on top, control variables (%) below, phases strip at bottom</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="253" />
        <source>Show duration and percentage in each phase segment on the phases strip</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="282" />
        <source>Automatically set delta axis max from DeltaET</source>
        <translation>从DeltaET自动设置轴差最大值</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="283" />
        <source>Automatically set delta axis max from DeltaBT</source>
        <translation>从DeltaBT自动设置轴差最大值</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="329" />
        <source>Reset axis settings to their defaults</source>
        <translation>将轴设置重置为其默认值</translation>
    </message>
    <message>
        <location filename="../artisanlib/axis.py" line="333" />
        <source>Take axis settings from profile on load</source>
        <translation>在加载时从配置文件中获取轴设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/cup_profile.py" line="115" />
        <location filename="../artisanlib/wheels.py" line="65" />
        <source>Aspect Ratio</source>
        <translation>纵横比</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="72" />
        <source>Increase size of text in all the graph</source>
        <translation>增加所有图形的文字尺寸</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="75" />
        <source>Decrease size of text in all the graph</source>
        <translation>减少所有图形的文字尺寸</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="79" />
        <source>Decorative edge between wheels</source>
        <translation>轮子之间的装饰边</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="85" />
        <source>Line thickness</source>
        <translation>线条粗细</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="90" />
        <source>Line color</source>
        <translation>线的颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="93" />
        <source>Text color</source>
        <translation>文字颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="97" />
        <source>Apply color pattern to whole graph</source>
        <translation>将颜色模式运用至全图</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="103" />
        <source>Add new wheel</source>
        <translation>添加新轮图</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="106" />
        <source>Rotate graph 1 degree counter clockwise</source>
        <translation>逆时针旋转图形1度</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="109" />
        <source>Rotate graph 1 degree clockwise</source>
        <translation>顺时针旋转图形1度</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="116" />
        <source>Save graph to a text file.wg</source>
        <translation>保存图形为一个文本文件.wg</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="851" />
        <location filename="../artisanlib/wheels.py" line="120" />
        <source>Save image using current graph size to a png format</source>
        <translation>使用目前图形尺寸保存为PNG格式图片</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="127" />
        <source>open wheel graph file</source>
        <translation>打开风味轮文件</translation>
    </message>
    <message>
        <location filename="../artisanlib/wheels.py" line="132" />
        <source>Sets Wheel graph to view mode</source>
        <translation>设定轮图为查看模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="163" />
        <source>Activates p-i-d gain scheduling</source>
        <translation>激活PID增益调度</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="166" />
        <source>Scheduling by process value input temperature</source>
        <translation>通过过程值输入温度进行增益调度</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="169" />
        <source>Scheduling by set value target temperature</source>
        <translation>通过目标温度进行增益调度</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="171" />
        <source>Scheduling based on linear regression of two points</source>
        <translation>基于两点线性映射的增益调度</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="174" />
        <source>Scheduling based on quadratic regression of three points</source>
        <translation>基于三点二次映射的增益调度</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="244" />
        <source>Source for SV slider synchronization in manual mode</source>
        <translation>手动模式下 SV 滑块同步的来源</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="264" />
        <source>PID input signal</source>
        <translation>PID输入信号</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="327" />
        <source>Slider to be set by the positive PID duty signal</source>
        <translation>滑块由正 PID 占空比信号设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="335" />
        <source>Slider to be set by the negative PID duty signal</source>
        <translation>滑块由负 PID 占空比信号设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="345" />
        <source>Activate range limit for positive PID output slider</source>
        <translation>激活正 PID 输出滑块的范围限制</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="350" />
        <source>Activate range limit for negative PID output slider</source>
        <translation>激活负 PID 输出滑块的范围限制</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="357" />
        <source>Positive output slider value at 0% duty</source>
        <translation>0% 占空比时的正输出滑块值</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="364" />
        <source>Positive output slider value at 100% duty</source>
        <translation>100% 占空比时的正输出滑块值</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="375" />
        <source>Negative output slider value at 0% duty</source>
        <translation>0% 占空比时的负输出滑块值</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="382" />
        <source>Negative output slider value at -100% duty</source>
        <translation>-100% 占空比时的负输出滑块值</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="407" />
        <source>If active, positive duties set negative outputs and negative ones the positive outputs</source>
        <translation>如果处于活动状态，则正职责设置负输出，负职责设置正输出</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="436" />
        <source>Manual set value (SV)</source>
        <translation>手动设定值（SV）</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="445" />
        <source>In background follow mode the set value (SV) is taken
from the selected source signal with a positive time offset
specified by the lookahead</source>
        <translation>在后台跟随模式下，采用设定值（SV）
来自具有正时间偏移的所选源信号
由前瞻指定</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="463" />
        <source>PID mode, taking the target value from the manual set value (SV),
the specified Ramp/Soak pattern
or the selected source signal of the background profiles</source>
        <translation>PID模式，从手动设定值（SV）中取目标值，
指定的 Ramp/Soak 模式
或背景配置文件的选定源信号</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="468" />
        <source>Show the set value (SV) buttons for manual input of the PID target</source>
        <translation>显示用于手动输入 PID 目标的设定值 (SV) 按钮</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="472" />
        <source>Show the set value (SV) slider for manual input of the PID target</source>
        <translation>显示用于手动输入 PID 目标的设定值 (SV) 滑块</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="479" />
        <source>Lower limit of the set value (SV) slider</source>
        <translation>设定值（SV）滑块下限</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="488" />
        <source>Upper limit of the set value (SV) slider</source>
        <translation>设定值（SV）滑块的上限</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="560" />
        <source>Filter on SV in background follow mode</source>
        <translation>SV 滤波仅跟随背景曲线模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="583" />
        <source>Smooth the final output signal and suppress abrupt changes in the P/I term</source>
        <translation>平滑最终输出信号并抑制比例 / 积分项的突变</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="597" />
        <source>Duty signal step size</source>
        <translation>占空比信号步长</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="608" />
        <source>With just a positive output active, the PID duty ranges from 0% to 100%.
With just a negative output it ranges from -100% to 0%.
With both outputs active the range is -100% to 100%.
This range can be clamped by setting tighter minimum and maximum  limits.</source>
        <translation>仅当正输出有效时，PID 占空比范围为 0% 至 100%。
仅负输出时，其范围为 -100% 至 0%。
当两个输出均处于活动状态时，范围为 -100% 至 100%。
可以通过设置更严格的最小和最大限制来限制该范围。</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="632" />
        <source>Proportional setvalue weight</source>
        <translation>偏向按误差比例</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="642" />
        <source>Derivative setvalue weight</source>
        <translation>偏向误差导数</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="655" />
        <source>Proportional on Error</source>
        <translation>按误差比例(PoE)</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="657" />
        <source>Proportional on Measurement</source>
        <translation>按比例测量(PoM）</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="660" />
        <source>Derivative on Error</source>
        <translation>误差导数（DoE）</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="662" />
        <source>Derivative on Measurement (preventing the derivative kick)</source>
        <translation>测量导数（DoM）</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="701" />
        <source>Integral limit factor</source>
        <translation>积分限制因子</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="709" />
        <source>Derivative limit</source>
        <translation>导数极限</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="731" />
        <location filename="../artisanlib/pid_dialogs.py" line="721" />
        <source>Integral reset on target (SP) changes exceeding the limit</source>
        <translation>目标 (SP) 变化超过限制时积分重置</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="728" />
        <source>Integral Windup Prevention</source>
        <translation>积分饱和预防</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="760" />
        <source>Automatically turn the PID ON on CHARGE</source>
        <translation>充电时自动打开 PID</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="764" />
        <source>Automatically turn the PID OFF on DROP</source>
        <translation>自动关闭 PID DROP</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="769" />
        <source>Generated an event mark on each output slider change
initiated by the PID</source>
        <translation>在每个输出滑块更改上生成事件标记
由PID发起</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="774" />
        <source>Load kp, ki, kd, PID Input, P on Error/Input and Lookahead settings from background profile</source>
        <translation>从背景配置文件中加载 kp、ki、kd、PID 输入、P 错误/输入和前瞻设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="926" />
        <source>Turn PID ON</source>
        <translation>打开 PID</translation>
    </message>
    <message>
        <location filename="../artisanlib/pid_dialogs.py" line="931" />
        <source>Turn PID OFF</source>
        <translation>关闭 PID</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="46" />
        <source>Automatic generated name</source>
        <translation>自动创建名称</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="59" />
        <source>ON/OFF of automatic saving when pressing keyboard letter [a]</source>
        <translation>打开/关闭 按下键盘字母[a]自动保存</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="64" />
        <source>Add auto saved file names to the recent files list</source>
        <translation>将自动保存的文件名添加到最近的文件列表中</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="69" />
        <source>Save image alongside .alog profiles</source>
        <translation>在.alog配置文件旁保存图像</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="99" />
        <source>Sets the directory to store batch profiles when using the letter [a]</source>
        <translation>当使用字母[a]时为存储批次配置文件设置目录</translation>
    </message>
    <message>
        <location filename="../artisanlib/autosave.py" line="105" />
        <source>Sets the directory to store the save also files</source>
        <translation>设置存储文件的目录</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="216" />
        <location filename="../artisanlib/events.py" line="209" />
        <location filename="../artisanlib/events.py" line="202" />
        <location filename="../artisanlib/events.py" line="195" />
        <source>Definition string for special event annotation</source>
        <translation>特殊事件的释义字符串</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="281" />
        <source>Display a button that registers events during the roast</source>
        <translation>显示一个在烘焙过程中注册事件的按钮</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="286" />
        <source>Display roast events time and temperature on {} curve</source>
        <comment>Display roast events time and temperature on BT curve</comment>
        <translation>在 {} 曲线上显示烘焙事件时间和温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="291" />
        <source>Show event type 5 flags anchored on {}, when un-ticked they anchor to the greater of {} or {}</source>
        <comment>Show event type 5 flags anchored on BT, when un-ticked they anchor to the greater of ET or BT</comment>
        <translation>显示锚定在 {} 上的事件类型 5 标志，未勾选时它们锚定到 {} 或 {} 中的较大者</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="298" />
        <source>Custom events are drawn using the temperature scale</source>
        <translation>自定义事件将通过温度刻度来对齐</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="302" />
        <source>Custom event descriptions are shown instead of type/value tags</source>
        <translation>显示自定义事件描述而不是类型/值标签</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="311" />
        <source>Length of text in event marks</source>
        <translation>事件标记中的文本长度</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="326" />
        <source>Choose display style of custom events</source>
        <translation>选择自定义事件的显示样式</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="340" />
        <source>Event display on roast axis: classic annotations by value, or Roest markers (vertical lines + labels)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="358" />
        <source>Roest markers are required in Roast-like layout mode</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="374" />
        <location filename="../artisanlib/events.py" line="373" />
        <location filename="../artisanlib/events.py" line="372" />
        <location filename="../artisanlib/events.py" line="371" />
        <location filename="../artisanlib/events.py" line="370" />
        <source>Tick to display events of type {}</source>
        <comment>Tick to display events of type 1</comment>
        <translation>勾选以显示类型为 {} 的事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="398" />
        <location filename="../artisanlib/events.py" line="397" />
        <location filename="../artisanlib/events.py" line="396" />
        <location filename="../artisanlib/events.py" line="395" />
        <location filename="../artisanlib/events.py" line="394" />
        <source>Event type label</source>
        <translation>事件类型标签</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="574" />
        <source>Auto detection of {}</source>
        <comment>Auto detection of CHARGE</comment>
        <translation>自动检测 {}</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="580" />
        <source>Countdown timer that sets {} after {}</source>
        <comment>Countdown timer that sets CHARGE after START</comment>
        <translation>在 {} 之后设置 {} 的倒计时器</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="591" />
        <source>Countdown seconds from {} to {}</source>
        <comment>Countdown seconds from START to CHARGE</comment>
        <translation>从 {} 到 {} 的倒计时秒数</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="602" />
        <source>Auto detection of {}</source>
        <comment>Auto detection of DROP</comment>
        <translation>自动检测 {}</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="621" />
        <location filename="../artisanlib/events.py" line="611" />
        <source>Detection sensitivity</source>
        <translation>检测灵敏度</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="624" />
        <source>Show marker at the turning point</source>
        <translation>在转折点显示标记</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="629" />
        <source>Show marker at Maximum {} between {} and {}</source>
        <comment>Show marker at Maximum ET between TP and DROP</comment>
        <translation>在 {} 和 {} 之间的最大 {} 处显示标记</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="637" />
        <source>During roast display a vertical line at the current time</source>
        <translation>烘焙期间显示当前时间的垂直线</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="673" />
        <source>Invert color of last button pressed</source>
        <translation>反转按下的最后一个按钮的颜色</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="677" />
        <source>Show custom event button specification as button tooltip</source>
        <translation>将自定义事件按钮规范显示为按钮工具提示</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="267" />
        <location filename="../artisanlib/alarms.py" line="96" />
        <location filename="../artisanlib/statistics.py" line="301" />
        <location filename="../artisanlib/statistics.py" line="281" />
        <location filename="../artisanlib/curves.py" line="74" />
        <location filename="../artisanlib/roast_properties.py" line="2906" />
        <location filename="../artisanlib/roast_properties.py" line="824" />
        <location filename="../artisanlib/roast_properties.py" line="814" />
        <location filename="../artisanlib/background.py" line="190" />
        <location filename="../artisanlib/background.py" line="180" />
        <location filename="../artisanlib/events.py" line="689" />
        <source>Copy table to clipboard, OPTION or ALT click for tabular text</source>
        <translation>复制表到剪贴板，OPTION或ALT单击可显示表文本</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="693" />
        <source>Add new extra Event button</source>
        <translation>添加新的额外事件按钮</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="698" />
        <source>Delete the last extra Event button</source>
        <translation>删除最后一个额外事件按钮</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="117" />
        <location filename="../artisanlib/ports.py" line="780" />
        <location filename="../artisanlib/events.py" line="711" />
        <source>Show help</source>
        <translation>显示帮助</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="750" />
        <source>Backup all palettes to a text file</source>
        <translation>保存所有调色板为一个文本文件</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="751" />
        <source>Restore all palettes from a text file</source>
        <translation>从一个文本文档中恢复所有调色板</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="777" />
        <source>Triggered quantifier fires slider action</source>
        <translation>触发量词触发滑块动作</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="780" />
        <source>No processing delay if source delivers the set value (SV) instead of the process value (PV)</source>
        <translation>如果源提供了设定值（SV）而不是过程值（PV），则没有处理延迟</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="822" />
        <location filename="../artisanlib/events.py" line="817" />
        <location filename="../artisanlib/events.py" line="812" />
        <location filename="../artisanlib/events.py" line="807" />
        <source>Action Type</source>
        <translation>动作类型</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="925" />
        <source>Applies the Bernoulli's gas law to the values computed
by applying the given factor and offset to the slider value
assuming that the gas pressure and not the gas flow is controlled.
To reduce heat (or gas flow) by 50% the gas pressure
has to be reduced by 4 times.</source>
        <translation>将伯努利气体定律应用于计算值
通过将给定的因子和偏移量应用于滑块值
假设控制的是气体压力而不是气体流量。
为了将热量（或气体流量）降低 50%，气体压力
必须降低 4 倍。</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1075" />
        <location filename="../artisanlib/events.py" line="1069" />
        <location filename="../artisanlib/events.py" line="1063" />
        <location filename="../artisanlib/events.py" line="1057" />
        <location filename="../artisanlib/events.py" line="960" />
        <location filename="../artisanlib/events.py" line="955" />
        <location filename="../artisanlib/events.py" line="950" />
        <location filename="../artisanlib/events.py" line="945" />
        <source>Step Size</source>
        <translation>一步的大小</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="965" />
        <source>Slider values interpreted as temperatures</source>
        <translation>把滑块值作为温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="983" />
        <source>Unit to be added to generated event descriptions</source>
        <translation>添加到生成的事件说明中的单位</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1003" />
        <source>Move slider under focus using the up/down cursor keys</source>
        <translation>使用上/下光标键将滑块移动到焦点下</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1006" />
        <source>Group Slider 1 with Slider 4 and Slider 2 with Slider 3</source>
        <translation>组滑块 1 与滑块 4 以及滑块 2 与滑块 3</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1098" />
        <location filename="../artisanlib/events.py" line="1093" />
        <location filename="../artisanlib/events.py" line="1088" />
        <location filename="../artisanlib/events.py" line="1083" />
        <source>fire slider action</source>
        <translation>火滑块动作</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1118" />
        <location filename="../artisanlib/events.py" line="1113" />
        <location filename="../artisanlib/events.py" line="1108" />
        <location filename="../artisanlib/events.py" line="1103" />
        <source>If source is a Set Value quantification gets never blocked</source>
        <translation>如果源是设置值量化永远不会被阻止</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1378" />
        <location filename="../artisanlib/events.py" line="1368" />
        <location filename="../artisanlib/events.py" line="1358" />
        <location filename="../artisanlib/events.py" line="1348" />
        <location filename="../artisanlib/events.py" line="1338" />
        <location filename="../artisanlib/events.py" line="1328" />
        <location filename="../artisanlib/events.py" line="1317" />
        <location filename="../artisanlib/events.py" line="1308" />
        <source>Display the button during roast</source>
        <translation>烘焙期间显示按钮</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1434" />
        <location filename="../artisanlib/events.py" line="1426" />
        <location filename="../artisanlib/events.py" line="1395" />
        <location filename="../artisanlib/events.py" line="1388" />
        <location filename="../artisanlib/events.py" line="1380" />
        <location filename="../artisanlib/events.py" line="1370" />
        <location filename="../artisanlib/events.py" line="1360" />
        <location filename="../artisanlib/events.py" line="1350" />
        <location filename="../artisanlib/events.py" line="1340" />
        <location filename="../artisanlib/events.py" line="1330" />
        <location filename="../artisanlib/events.py" line="1320" />
        <location filename="../artisanlib/events.py" line="1310" />
        <source>Action type to fire when the button is clicked</source>
        <translation>单击按钮时触发的操作类型</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1439" />
        <location filename="../artisanlib/events.py" line="1431" />
        <location filename="../artisanlib/events.py" line="1400" />
        <location filename="../artisanlib/events.py" line="1393" />
        <location filename="../artisanlib/events.py" line="1385" />
        <location filename="../artisanlib/events.py" line="1375" />
        <location filename="../artisanlib/events.py" line="1365" />
        <location filename="../artisanlib/events.py" line="1355" />
        <location filename="../artisanlib/events.py" line="1345" />
        <location filename="../artisanlib/events.py" line="1335" />
        <location filename="../artisanlib/events.py" line="1325" />
        <location filename="../artisanlib/events.py" line="1315" />
        <source>Event action command</source>
        <translation>事件动作命令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1403" />
        <source>Sampling action type</source>
        <translation>采样动作类型</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1411" />
        <source>Sampling action command</source>
        <translation>采样动作指令</translation>
    </message>
    <message>
        <location filename="../artisanlib/events.py" line="1413" />
        <source>Run the sampling action synchronously ({}) every sampling interval or select a repating time interval to run it asynchronously while sampling</source>
        <translation>每个采样间隔同步运行采样操作 ({})，或选择重复时间间隔以在采样时异步运行采样操作</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1136" />
        <location filename="../artisanlib/ports.py" line="671" />
        <source>OFF Action String</source>
        <translation>关闭动作</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="1139" />
        <location filename="../artisanlib/ports.py" line="674" />
        <source>ON Action String</source>
        <translation>打开动作</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="706" />
        <location filename="../artisanlib/ports.py" line="701" />
        <source>Extra delay after connect in seconds before sending requests (needed by Arduino devices restarting on connect)</source>
        <translation>连接后发送请求前的额外延迟（Arduino 设备在连接时重新启动所需）</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="733" />
        <location filename="../artisanlib/ports.py" line="728" />
        <source>IP timeout in seconds, not larger than half of the sampling interval</source>
        <translation>IP超时时间，以秒为单位，不大于采样间隔的一半</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="759" />
        <source>Scan MODBUS</source>
        <translation>扫描通讯协议</translation>
    </message>
    <message>
        <location filename="../artisanlib/ports.py" line="947" />
        <source>Scan S7</source>
        <translation>扫描 S7</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="73" />
        <source>Move the background profile using the cursor keys</source>
        <translation>使用光标键移动背景配置文件</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="147" />
        <location filename="../artisanlib/background.py" line="138" />
        <source>For loaded backgrounds with extra devices only</source>
        <translation>仅为额外设备载入背景曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="233" />
        <source>Replays the selected backgrounds events by time, BT, or ET (before TP always by time at least until 2min into the roast)</source>
        <translation>按时间、BT 或 ET 重播选定的背景事件（在 TP 之前始终按时间至少持续到烘焙开始 2 分钟之前）</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="238" />
        <source>Replays the backgrounds DROP event by time, BT, or ET (but earlierst 4min into the roast)</source>
        <translation>按时间、BT 或 ET 重播背景 DROP 事件（但最早在烘焙后 4 分钟）</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="249" />
        <source>Clear background before loading a profile</source>
        <translation>加载配置文件前清除背景</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="254" />
        <source>Set batch size from background profile on load</source>
        <translation>在加载时根据后台配置文件设置批次大小</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="259" />
        <source>Always hide background on loading a profile</source>
        <translation>加载个人资料时始终隐藏背景</translation>
    </message>
    <message>
        <location filename="../artisanlib/background.py" line="406" />
        <source>On ramping the ramp value is taken with a positive time offset
specified by the lookahead</source>
        <translation>在斜坡控制阶段，斜坡值的获取会采用由前瞻（参数）指定的正向时间偏移。</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="772" />
        <source>Open roast properties dialog on CHARGE</source>
        <translation>打开CHARGE上的烘焙属性对话框</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="776" />
        <source>Open roast properties dialog on DROP</source>
        <translation>在DROP上打开烘焙属性对话框</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="863" />
        <source>Display the roast title while roasting</source>
        <translation>在烘焙时显示烘焙标题</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="894" />
        <location filename="../artisanlib/roast_properties.py" line="872" />
        <source>Right-click to edit</source>
        <translation>点击鼠标右键进入编辑模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="912" />
        <source>batch size</source>
        <translation>批量大小</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="918" />
        <source>weight of roasted coffee</source>
        <translation>烘焙后咖啡的重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="925" />
        <source>weight loss caused by roasting</source>
        <translation>烘焙导致的重量减轻</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="933" />
        <source>weight unit</source>
        <translation>重量单位</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="946" />
        <source>weight of defects sorted from roasted coffee or weight of roasted coffee after defects have been removed</source>
        <translation>烘焙后咖啡中分选出的瑕疵品的重量或去除瑕疵品后的烘焙后咖啡的重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="955" />
        <source>weight unit of defects</source>
        <translation>缺陷重量单位</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="957" />
        <source>weight loss caused by defects</source>
        <translation>缺陷导致的重量损失</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="959" />
        <source>toggle defects input mode</source>
        <translation>切换缺陷输入模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="971" />
        <source>batch volume</source>
        <translation>批量</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="977" />
        <source>volume of roasted coffee</source>
        <translation>烘焙后咖啡的体积</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="983" />
        <source>volume increase caused by roasting</source>
        <translation>烘焙后失重率</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="990" />
        <source>volume unit</source>
        <translation>体积单位</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1000" />
        <source>density unit</source>
        <translation>密度单位</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1002" />
        <source>batch density</source>
        <translation>批次密度</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1008" />
        <source>density of roasted coffee</source>
        <translation>烘焙后咖啡的密度</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1016" />
        <source>density loss caused by roasting</source>
        <translation>焙烧引起的密度损失</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1022" />
        <source>loss of organic matters caused by roasting</source>
        <translation>烘焙造成的有机物质损失</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1029" />
        <source>Volume calculator to determine coffee volume from sample weight measured in container of known volume</source>
        <translation>体积计算器可根据已知体积的容器中测量的样品重量来确定咖啡体积</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1040" />
        <source>Add roast properties to list of recent roasts</source>
        <translation>将烘焙属性添加到最近烘焙列表中</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1046" />
        <source>Remove roast properties from list of recent roasts</source>
        <translation>从最近烘焙列表中删除烘焙属性</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1053" />
        <source>smallest screen size</source>
        <translation>最小目数</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1061" />
        <source>largest screen size</source>
        <translation>最大目数</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1072" />
        <source>color measurement of whole roasted beans</source>
        <translation>整颗烘焙咖啡豆的颜色数值</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1079" />
        <source>color measurement of ground roasted beans</source>
        <translation>烘焙后磨碎咖啡豆的颜色数值</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1087" />
        <source>color scale</source>
        <translation>咖啡烘焙度专业测量仪器品牌</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1097" />
        <source>temperature of the green coffee</source>
        <translation>生咖啡豆的温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1108" />
        <source>moisture unit</source>
        <translation>湿度单位</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1116" />
        <location filename="../artisanlib/roast_properties.py" line="1110" />
        <source>batch moisture</source>
        <translation>批次水分</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1118" />
        <source>moisture of roasted coffee</source>
        <translation>咖啡烘焙后水分含量</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1124" />
        <source>moisture loss caused by roasting</source>
        <translation>烘焙导致的水分流失</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1136" />
        <source>ambient humidity</source>
        <translation>环境湿度</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1144" />
        <source>ambient air temperature</source>
        <translation>环境空气温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1153" />
        <source>ambient air pressure</source>
        <translation>环境气压</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1175" />
        <source>weight measured by connected scale</source>
        <translation>通过连接的电子秤称重</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1177" />
        <source>accumulated weight received from connected scale</source>
        <translation>从连接的秤接收到的累计重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1222" />
        <source>container selector</source>
        <translation>容器选择器</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1231" />
        <source>set scale weight as batch size</source>
        <translation>将秤重量设置为批次大小</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1242" />
        <source>set scale weight as weight of roasted coffee</source>
        <translation>将秤的重量设置为烘焙咖啡的重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1254" />
        <source>set scale weight as weight of defects or yield</source>
        <translation>将秤重量设置为缺陷或产量的重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1268" />
        <source>retreive ambient data from connected devices or calculate from selected profile curve</source>
        <translation>从连接的设备检索环境数据或从选定的曲线计算</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1371" />
        <location filename="../artisanlib/roast_properties.py" line="1363" />
        <source>Select beans from your inventory</source>
        <translation>选择存储位置</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1369" />
        <location filename="../artisanlib/roast_properties.py" line="1365" />
        <source>Select a storage location</source>
        <translation>选择存储位置</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1373" />
        <location filename="../artisanlib/roast_properties.py" line="1367" />
        <source>Select a blend from your inventory</source>
        <translation>从您的库存中选择一种混合</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1378" />
        <source>Define a custom blend</source>
        <translation>定义一种自定义混合</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="1419" />
        <source>Beans are listed as 'origin, name' if ticked, otherwise as 'name, origin'</source>
        <translation>如果勾选，则 Bean 会列为“产地，名称”，否则列为“名称，产地”</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2942" />
        <source>Load label for reference. If left blank the row label, 'A', 'B', 'C' or 'D' will be used in its place.</source>
        <translation>加载标签作为参考。如果留空，将使用行标签 “A”“B”“C” 或 “D” 来替代。</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2944" />
        <source>Power rating of the load</source>
        <translation>负载的额定功率</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2946" />
        <source>Unit of the load matching the power rating</source>
        <translation>负载单位与额定功率匹配</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2948" />
        <source>Energy source of the load</source>
        <translation>负载的能源来源</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2950" />
        <source>Data source for the load. Either a recorded event type or the internal PID duty signal.</source>
        <translation>负载的数据源。可以是记录的事件类型或内部PID占空比。</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2952" />
        <source>Ticked if readings are taken from a pressure gauge. Unticked for electric roasters and regular burner power output.</source>
        <translation>如果读数来自压力表，则勾选此项。对于电动烘焙机则不勾选。</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2954" />
        <source>Electric Energy Mix approximates the percentage of electricity that comes from renewable sources</source>
        <translation>电能结构近似表示来自可再生能源的电力比例</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="2956" />
        <source>Gas Energy Mix approximates the percentage of gas that comes from renewable sources</source>
        <translation>天然气能源结构大致反映了可再生能源在天然气中的占比</translation>
    </message>
    <message>
        <location filename="../artisanlib/roast_properties.py" line="4148" />
        <source>The maximum nominal batch size of the machine in kg</source>
        <translation>机器的最大标称批量（千克）</translation>
    </message>
    <message>
        <location filename="../artisanlib/phases.py" line="167" />
        <source>Display all information (time, percentage and temperature) of the last phase across all 3 phases LCDs in parallel</source>
        <translation>并行显示所有 3 个阶段的 LCD 中最后一个阶段的所有信息（时间、百分比和温度）</translation>
    </message>
    <message>
        <location filename="../artisanlib/logs.py" line="44" />
        <source>ON/OFF logs serial communication</source>
        <translation>打开/关闭 串行通信记录</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="344" />
        <source>RoR linear decay average filter size</source>
        <translation>RoR线性衰减平均滤波器尺寸</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="360" />
        <source>Use an optimal smoothing algorithm (only applicable offline, after recording)</source>
        <translation>使用最佳平滑算法（仅适用于记录后的离线数据）</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="366" />
        <source>Compute the rate-of-rise over the delta span interval by a linear polyfit</source>
        <translation>通过线性多边形计算增量跨度间隔内的上升率</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="371" />
        <source>Linear decay average filter, applied if not recording. Resulting signal is used for RoR computation.</source>
        <translation>线性衰减平均滤波器，非录制状态下生效。滤波后的信号将用于升温速率 (RoR) 计算。</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="381" />
        <source>Minimal-delay low-pass filter eliminating tiny spikes, applied if not recording</source>
        <translation>低延迟低通滤波器，用于消除微小尖峰，非录制状态下生效</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="387" />
        <source>Removes stair-step patterns caused by duplicate readings through interpolation</source>
        <translation>通过插值消除重复读数导致的阶梯状曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="405" />
        <source>Render curves before CHARGE and after DROP</source>
        <translation>在CHARGE之前和DROP之后渲染曲线</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="412" />
        <source>Applies interpolation to substitute missing data</source>
        <translation>应用插值法填补缺失数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="419" />
        <source>Removes large spikes</source>
        <translation>去除大的尖峰</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="425" />
        <source>Removes readings out of range</source>
        <translation>移除超出范围的读数</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="471" />
        <source>RoR computation interval</source>
        <translation>RoR 计算区间</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="620" />
        <source>Applies filters directly on the incoming data before it is recorded, thus filtered data is lost forever</source>
        <translation>在记录数据之前直接对其应用过滤器，因此过滤后的数据将永久丢失。</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="648" />
        <source>Hide RoR readings out of range</source>
        <translation>隐藏超出范围的 RoR 读数</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="841" />
        <source>Shows data table of plots</source>
        <translation>显示绘图数据表</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="930" />
        <source>linear: linear interpolation
cubic: 3rd order spline interpolation
nearest: y value of the nearest point</source>
        <translation>线性:线性插值
立方:最接近的三次样条
插值:最接近点的y值</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="972" />
        <source>Choose the start point of analysis interval of interest</source>
        <translation>选择感兴趣的分析间隔的起始点</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1004" />
        <source>Choose the start point of curve fitting</source>
        <translation>选择曲线拟合的起始点</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1725" />
        <source>Add P1 and P2 as ET and BT</source>
        <translation>添加P1和P2作为ET和BT</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1730" />
        <source>Add P1 and P2 as:

1 an Extra virtual device if a profile is loaded
2 or ET and BT if profile is not loaded
</source>
        <translation>添加P1和P2作为:

1 如果一个配置文件已载入一个额外虚拟设备
2 或者如果配置文件没有载入ET或BT
</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1733" />
        <source>No more Virtual Extra Devices available</source>
        <translation>无更多有效虚拟额外设备</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1738" />
        <location filename="../artisanlib/curves.py" line="1736" />
        <source>Not available during recording</source>
        <translation>记录期间不可用</translation>
    </message>
    <message>
        <location filename="../artisanlib/curves.py" line="1741" />
        <source>Set P1 as ET background B1
Set P2 as BT background B2
Note: Erases all existing background curves.</source>
        <translation>设置P1作为B1的ET背景曲线
设置P2为B2的BT背景曲线
注意:将会清除所有已存在的背景曲线.</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="54" />
        <source>Show phase times and percent</source>
        <translation>显示阶段时间和百分比</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="60" />
        <source>Show the Phases Bar</source>
        <translation>显示阶段栏</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="68" />
        <source>Show metrics below graph, right click on metrics to toggle</source>
        <translation>在图表下方显示指标，右键单击指标即可切换</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="74" />
        <source>Show RoR from begin to end of phase</source>
        <translation>从阶段开始到结束显示 RoR</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="82" />
        <source>Show delta temp from begin to end of phase</source>
        <translation>显示从阶段开始到结束的温度变化量</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="102" />
        <source>Set start of AUC, must tick "From Event"</source>
        <translation>设置AUC的开始，必须勾选“从事件”</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="111" />
        <source>Set start temp of AUC, must un-tick "From Event"</source>
        <translation>设置 AUC 的起始温度，必须取消勾选“来自事件”</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="121" />
        <source>When selected use From event to start AUC else use Base Temp</source>
        <translation>当选择使用从事件开始AUC时，否则使用基础温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="127" />
        <source>Set a target total AUC to display during roast</source>
        <translation>设置在烘焙过程中显示的目标总 AUC</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="132" />
        <source>Use background profile for AUC target</source>
        <translation>使用背景配置文件作为 AUC 目标</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="137" />
        <source>Show AUC Target guideline during roast</source>
        <translation>烘焙过程中显示 AUC 目标指导</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="140" />
        <source>Show AUC LCD during roast</source>
        <translation>烘焙期间显示 AUC LCD</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="144" />
        <source>Show AUC area on graph</source>
        <translation>在图表上显示 AUC 区域</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="248" />
        <source>Show Summary Statistics</source>
        <translation>显示摘要统计信息</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="256" />
        <source>Determines the width of the display box</source>
        <translation>确定显示框的宽度</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="266" />
        <source>Choose the font size
Font type is set in Config&gt;&gt; Curves&gt;&gt; UI tab</source>
        <translation>选择字体大小
字体类型在配置&gt;&gt;曲线&gt;&gt;UI 选项卡中设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="285" />
        <source>Add new Statistic</source>
        <translation>添加新统计数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="290" />
        <source>Delete the selected Statistic</source>
        <translation>删除选定的统计数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="295" />
        <source>Insert below the selected Statistic</source>
        <translation>在选定的统计数据下方插入</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="305" />
        <source>Set Statistics Summary to default settings</source>
        <translation>将“统计摘要”设置为默认设置</translation>
    </message>
    <message>
        <location filename="../artisanlib/statistics.py" line="589" />
        <source>Choose a statistic to display</source>
        <translation>选择要显示的统计数据</translation>
    </message>
    <message>
        <location filename="../artisanlib/dialogs.py" line="786" />
        <source>Legacy mode extracts only key points (CHARGE, DRY, FC, SC, DROP).
Unchecked: Fits a smooth spline to preserve curve shape.</source>
        <translation>传统模式仅提取关键 (CHARGE, DRY, FC, SC, DROP).
未选中：拟合平滑样条曲线以保持曲线形状。</translation>
    </message>
    <message>
        <location filename="../artisanlib/dialogs.py" line="798" />
        <source>Number of control points for spline fitting</source>
        <translation>样条拟合的控制点数量</translation>
    </message>
    <message>
        <location filename="../artisanlib/alarms.py" line="122" />
        <source>Clear alarms table</source>
        <translation>清除警报表</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="740" />
        <source>Connect to plus service</source>
        <translation>连接到plus服务</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="741" />
        <source>Subscription</source>
        <translation>订阅</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="742" />
        <source>Reset original view</source>
        <translation>重置原始视图</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="743" />
        <source>Back to  previous view</source>
        <translation>返回上一视图</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="744" />
        <source>Forward to next view</source>
        <translation>前进到下一个视图</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="746" />
        <source>Pan axes with left mouse, zoom with right</source>
        <translation>鼠标左键平移轴，右键缩放</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="747" />
        <source>Zoom to rectangle</source>
        <translation>缩放到矩形</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="834" />
        <source>Line styles</source>
        <translation>线条样式</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="14452" />
        <location filename="../artisanlib/main.py" line="3193" />
        <source>Start monitoring</source>
        <translation>开始监测</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3207" />
        <source>Start recording</source>
        <translation>开始记录</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3221" />
        <source>First Crack Start</source>
        <translation>第一次爆裂</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3225" />
        <source>First Crack End</source>
        <translation>一爆结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3229" />
        <source>Second Crack Start</source>
        <translation>第二次爆裂</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3233" />
        <source>Second Crack End</source>
        <translation>二爆结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3245" />
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3250" />
        <source>Charge</source>
        <translation>投豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3255" />
        <source>Drop</source>
        <translation>排豆</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3273" />
        <source>Event</source>
        <translation>事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3282" />
        <source>Increases the current SV value by 5</source>
        <translation>将当前SV值增加5</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3291" />
        <source>Increases the current SV value by 10</source>
        <translation>将当前SV值增加10</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3300" />
        <source>Increases the current SV value by 20</source>
        <translation>将当前SV值增加20</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3309" />
        <source>Decreases the current SV value by 20</source>
        <translation>将当前SV值减少20</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3318" />
        <source>Decreases the current SV value by 10</source>
        <translation>将当前SV值减少10</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3327" />
        <source>Decreases the current SV value by 5</source>
        <translation>将当前SV值减少5</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3334" />
        <source>Dry End</source>
        <translation>脱水结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3339" />
        <source>Cool End</source>
        <translation>冷却结束</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3389" />
        <source>Timer</source>
        <translation>计时器</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3390" />
        <source>ET Temperature</source>
        <translation>ET温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3391" />
        <source>BT Temperature</source>
        <translation>BT温度</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3392" />
        <source>ET/time (degrees/min)</source>
        <translation>ET/时间(度/分钟)</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3393" />
        <source>BT/time (degrees/min)</source>
        <translation>BT/时间(度/分钟)</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3394" />
        <source>Value of SV in PID</source>
        <translation>PID的SV值</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3395" />
        <source>PID power %</source>
        <translation>PID 火力%</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3505" />
        <source>Number of events found</source>
        <translation>发现事件编号</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3521" />
        <source>Type of event</source>
        <translation>事件类型</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3528" />
        <source>Value of event</source>
        <translation>事件数值</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3540" />
        <source>Updates the event</source>
        <translation>更新事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="3911" />
        <source>Phase LCDs: right-click to cycle through TIME, PERCENTAGE and TEMP MODE</source>
        <translation>阶段 LCDs: 右键点击循环切换时间/百分比/温度模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5346" />
        <source>Syncing with artisan.plus</source>
        <translation>同步artisan.plus</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5383" />
        <location filename="../artisanlib/main.py" line="5349" />
        <source>Disconnect artisan.plus</source>
        <translation>断开artisan.plus</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5352" />
        <source>Upload to artisan.plus</source>
        <translation>上传到artisan.plus</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="5386" />
        <source>Connect artisan.plus</source>
        <translation>连接artisan.plus</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="8003" />
        <source>Phase LCDs
Currently in ALL FINISHING MODE</source>
        <translation>阶段 LCDs
当前处于全部完成模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="8040" />
        <source>Phase LCDs: right-click to cycle through TIME, PERCENTAGE and TEMP MODE
Currently in TIME MODE</source>
        <translation>阶段 LCDs: 右键点击循环切换时间/百分比/温度模式
目前为时间模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="8058" />
        <source>Phase LCDs: right-click to cycle through TIME, PERCENTAGE and TEMP MODE
Currently in PERCENTAGE MODE</source>
        <translation>阶段 LCDs: 右键点击循环切换时间/百分比/温度模式
目前为百分比模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="8072" />
        <source>Phase LCDs: right-click to cycle through TIME, PERCENTAGE and TEMP MODE
Currently in TEMP MODE</source>
        <translation>阶段 LCDs: 右键点击循环切换时间/百分比/温度模式
目前为温度模式</translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26714" />
        <source>&lt;b&gt;Label&lt;/b&gt;= </source>
        <translation>&lt;b&gt;标签&lt;/b&gt;= </translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26715" />
        <source>&lt;b&gt;Description &lt;/b&gt;= </source>
        <translation>&lt;b&gt;说明&lt;/b&gt;= </translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26716" />
        <source>&lt;b&gt;Type &lt;/b&gt;= </source>
        <translation>&lt;b&gt;类型&lt;/b&gt;= </translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26718" />
        <source>&lt;b&gt;Value &lt;/b&gt;= </source>
        <translation>&lt;b&gt;数值&lt;/b&gt;= </translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26720" />
        <source>&lt;b&gt;Documentation &lt;/b&gt;= </source>
        <translation>&lt;b&gt;文档&lt;/b&gt;= </translation>
    </message>
    <message>
        <location filename="../artisanlib/main.py" line="26721" />
        <source>&lt;b&gt;Button# &lt;/b&gt;= </source>
        <translation>&lt;b&gt;按钮# &lt;/b&gt;= </translation>
    </message>
    <message>
        <location filename="../artisanlib/batches.py" line="37" />
        <source>Batch prefix</source>
        <translation>批次前缀</translation>
    </message>
    <message>
        <location filename="../artisanlib/batches.py" line="44" />
        <source>ON/OFF batch counter</source>
        <translation>打开/关闭 批次计数器</translation>
    </message>
    <message>
        <location filename="../artisanlib/batches.py" line="59" />
        <source>If ticked, the batch counter is never modified by loading a settings file</source>
        <translation>如果勾选，则载入设置时不会更改批次计数器</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="120" />
        <source>Enable PID control</source>
        <translation>启用 PID 控制</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="300" />
        <source>Recaclulates all Virtual Devices and updates their values in the profile</source>
        <translation>重新计算所有虚拟设备并更新烘焙配置文件</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="950" />
        <source>Phidget server password</source>
        <translation>Phidget 服务器密码</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1006" />
        <source>Network IP address or name of the remote VirtualHub</source>
        <translation>远程 VirtualHub 的网络 IP 地址或名称</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1226" />
        <location filename="../artisanlib/devices.py" line="1182" />
        <source>Receive {} event from machine</source>
        <translation>从机器接收 {} 事件</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1457" />
        <source>Recaclulates ET and BT and updates their values in the profile</source>
        <translation>在配置中更新重新计算的ET和BT值</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1657" />
        <location filename="../artisanlib/devices.py" line="1586" />
        <source>Choose the model of your scale</source>
        <translation>选择您的电子秤型号</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1662" />
        <location filename="../artisanlib/devices.py" line="1591" />
        <source>Choose your scale</source>
        <translation>选择您的电子秤</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1665" />
        <location filename="../artisanlib/devices.py" line="1594" />
        <source>Start scanning to discover your scale</source>
        <translation>开始扫描以发现您的电子秤</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1669" />
        <location filename="../artisanlib/devices.py" line="1598" />
        <source>Rename your scale</source>
        <translation>重命名您的电子秤</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1676" />
        <location filename="../artisanlib/devices.py" line="1605" />
        <source>Tare your scale</source>
        <translation>去皮秤</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1729" />
        <source>Start/stop the green coffee weighting task web display</source>
        <translation>开始/停止生咖啡称重任务网页显示</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1735" />
        <source>IP port of the green coffee weighting task web display</source>
        <translation>生咖啡加权任务网页显示的IP端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1771" />
        <source>Start/stop the roasted coffee weighting task web display</source>
        <translation>开始/停止烘焙咖啡称重任务网页显示</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1782" />
        <source>IP port of the roasted coffee weighting task web display</source>
        <translation>烘焙咖啡加权任务网页显示的IP端口</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1823" />
        <source>Weight of your green coffee container</source>
        <translation>生咖啡容器的重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1825" />
        <source>Identify your green coffee container and its weight. If a container is selected only that container is recognized. If no container is selected, all defined containers are recognized.</source>
        <translation>识别您的生咖啡容器及其重量。如果选择了一个容器，则仅识别该容器。如果未选择任何容器，则识别所有定义的容器。</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1858" />
        <source>The one-bucket mode assumes that the entire batch fits into a single bucket</source>
        <translation>单桶模式假设整个批次适合放入一个桶中</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1860" />
        <source>The two-bucket mode allows splitting a batch into two buckets for easier lifting</source>
        <translation>双桶模式允许将一批物料分成两个桶，以便于提升</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1887" />
        <source>Target accuracy expressed as a percentage of the batch size. If zero is selected, the check is disabled.</source>
        <translation>目标准确率以批次大小的百分比表示。如果选择零，则禁用该检查。</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1909" />
        <source>Weight of your roasted coffee container</source>
        <translation>烘焙咖啡容器的重量</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="1911" />
        <source>Identify your roasted coffee container and its weight. If no roasted container is selected, the weighing of roasted batches is disabled.</source>
        <translation>确定您的烘焙咖啡容器及其重量。如果未选择烘焙容器，则禁用烘焙批次的称重功能。</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2774" />
        <source>Example: 100 + 2*x</source>
        <translation>例如: 100 + 2*x</translation>
    </message>
    <message>
        <location filename="../artisanlib/devices.py" line="2775" />
        <source>Example: 100 + x</source>
        <translation>例如: 100 + x</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="14304" />
        <source>Stop monitoring</source>
        <translation>停止监测</translation>
    </message>
    <message>
        <location filename="../artisanlib/canvas.py" line="15080" />
        <source>Stop recording</source>
        <translation>停止记录</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="113" />
        <source>Background curve: 0=fully transparent, 10=fully opaque</source>
        <translation>背景曲线：0=完全透明，10=完全不透明</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="211" />
        <source>Legend background: 0=fully transparent, 10=fully opaque</source>
        <translation>图例背景：0=完全透明，10=完全不透明</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="273" />
        <source>Analysis mask: 0=fully transparent, 10=fully opaque</source>
        <translation>分析蒙版：0=完全透明，10=完全不透明</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="290" />
        <source>Statistics and Analysis background: 0=fully transparent, 10=fully opaque</source>
        <translation>统计分析背景：0=完全透明，10=完全不透明</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="363" />
        <source>Sets LCD colors to black and white</source>
        <translation>将 LCD 颜色设置为黑白</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="566" />
        <source>Loads the Default theme</source>
        <translation>加载默认主题</translation>
    </message>
    <message>
        <location filename="../artisanlib/colors.py" line="571" />
        <source>Sets button colors to grey scale and LCD colors to black and white</source>
        <translation>将按钮颜色设置为灰度，将 LCD 颜色设置为黑白</translation>
    </message>
    <message>
        <location filename="../plus/schedule.py" line="2262" />
        <source>Update schedule</source>
        <translation>更新时间表</translation>
    </message>
    <message>
        <source>Automatically extend the time axis by 3min on need</source>
        <translation type="vanished">根据需要自动延长时间轴3分钟</translation>
    </message>
    <message>
        <source>Applies the Bernoulli's gas law to the values computed
by applying the given factor and offset to the slider value
assuming that the gas pressureand not the gas flow is controlled.
To reduce heat (or gas flow) by 50% the gas pressure
has to be reduced by 4 times.</source>
        <translation type="vanished">将伯努利的瓦斯定律应用于计算出的值
通过将给定因子和偏移量应用于滑块值
假设控制气体压力而不是气体流量。
将热量（或气体流量）减少50％的气压
必须减少4倍。</translation>
    </message>
</context></TS>
